﻿using JLPTMockTestManagement.DAL.Entities;
using JLPTMockTestManagement.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.BLL.Services
{
    public class AccountService
    {
        //gui -- service -- repo -- context -- table
        private AccountRepo _repo = new();


        public Jlptaccount? Authenticate(string email, string pass)
        {
            return _repo.GetOne(email, pass);
        }
        public Jlptaccount? Authenticate(string email)
        {
            return _repo.GetOne(email);
        }
    }
}
