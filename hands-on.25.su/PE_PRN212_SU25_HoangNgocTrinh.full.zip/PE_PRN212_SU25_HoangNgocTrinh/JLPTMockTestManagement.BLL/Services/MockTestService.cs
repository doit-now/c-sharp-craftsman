﻿using JLPTMockTestManagement.DAL.Entities;
using JLPTMockTestManagement.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.BLL.Services
{
    public class MockTestService
    {
        //3-layer architect:
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST     2ND         3RD       .json lấy connection to db
        private MockTestRepo _repo = new(); //new luôn đc, vì ko ảnh hưởng dbcontext, dbcontext đc quản lí bởi từng hàm CRUD của repo, ta ko sợ!!!!

        //CÁC HÀM CRUD HERE! DÙNG BỞI GUI, CHÍNH HÀM NÀY THÌ LẠI TRIỆU GỌI REPO GIÚP, THẰNG TRUNG GIAN CHUYỀN BANH
        public List<MockTest> GetAllMockTests()
        {
            return _repo.GetAll();
        }

        //SERVICE GỌI 3 HÀM CUD 
        public void CreateMockTest(MockTest obj)
        {
            _repo.Create(obj);
        }

        public void UpdateMockTest(MockTest obj)
        {
            _repo.Update(obj);
        }

        public void DeleteMockTest(MockTest obj)
        {
            _repo.Delete(obj);
        }

        public List<MockTest> SearchByTitleOrSkill(string keyword)
        {
            return _repo.SearchByTitleOrSkill(keyword);
        } //có thể viết theo expression bodied

    }
}
