﻿using JLPTMockTestManagement.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.DAL.Repositories
{
    public class AccountRepo
    {
        //1 HÀM DUY NHẤT DÍNH ĐẾN TABLE ACCOUNT, CHỈ DÀNH CHO LOGIN
        //CÓ 2 CÁCH VIẾT HÀM LOGIN
        //WHERE EMAIL = ? AND PASS = ? -> CHỈ THÔNG BÁO CHUNG CHUNG: SAI 1 TRONG 2, VÀ KO ĐẾM ĐC SỐ LẦN SAI PASS

        //WHERE EMAIL = ? -> KO CÓ DÒNG NÀY -> THÔNG BÁO ACCOUNT KO TỒN TẠI
        //                -> CÓ 1 DÒNG, XÉT TIẾP PASS -> ĐÚNG PASS OK
        //                -> CÓ 1 DÒNG, XÉT TIẾP PASS -> SAI PASS THÔNG BÁO SAI PASS VÀ ĐẾM SỐ LẦN SAI PASS!!!
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE
        private Su25jlptmockTestDbContext _context; //ko new, new trong từng hàm

        public Jlptaccount? GetOne(string email, string pass)
        {
            _context = new();
            //_context.Jlptaccounts.Where(...).ToList(); //trả về List - dành cho search
            return _context.Jlptaccounts.FirstOrDefault(x => x.Email.ToLower() == email.ToLower() &&
                                                             x.Password == pass);

        }
        public Jlptaccount? GetOne(string email)
        {
            _context = new();
            //_context.Jlptaccounts.Where(...).ToList(); //trả về List - dành cho search
            return _context.Jlptaccounts.FirstOrDefault(x => x.Email.ToLower() == email.ToLower());

                //.bag
        }



    }
}
