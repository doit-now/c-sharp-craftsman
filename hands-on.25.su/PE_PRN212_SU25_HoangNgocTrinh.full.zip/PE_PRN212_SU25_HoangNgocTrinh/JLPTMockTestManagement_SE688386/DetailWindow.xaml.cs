﻿using JLPTMockTestManagement.BLL.Services;
using JLPTMockTestManagement.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Printing.IndexedProperties;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JLPTMockTestManagement_SE688386
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    public partial class DetailWindow : Window
    {

        //cần 1 prop để kiểm soát mode của màn hình này: Edit hay Create
        //EDIT MODE THÌ TA SẼ NHẬN 1 SELECTED MOCKTEST TỪ BÊN MÀN HÌNH MAIN
        //VÀ TA DÙNG BIẾN NÀY ĐỂ IF XEM MÀN HÌNH NÀY Ở MODE NÀO
        //VÌ CREATE THÌ BIẾN PROP NÀY == NULL

        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST      2ND         3RD

        //Màn hình này cần 2 Service
        //Service 1: Dùng cho đổ vào combobox -> CandateService
        //Service 2: Dùng để cho nút bấm Save hoạt động theo 2 mode: tạo mới hay update ứng với 2 câu SQL: insert into, hay update from 
        private CandidateService _candService = new(); //đổ vào combo 
        private MockTestService _testService = new();  //save màn hình xuống DB

        public MockTest EditedOne { get; set; } = null;
        public Jlptaccount LoggedInAccount { get; set; } = null;
        //ĐỂ CHẶN KO CHO STAFF EDIT MÀ CHỈ VIEW HOY
        //TA CÓ 2 CÁCH: LOCK CÁC Ô NHẬP
        //              DISABLE NÚT BẤM [SAVE], KO CHO SAVE
        //              CHỈ VIEW, SỬA THOẢI MÁI, KO SAVE ĐC

        public DetailWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillComboBox();
            if (EditedOne != null)
            {
                FillElements(); //edit nè bạn, đổ info cũ vào các ô nhập để sửa
                WindowModeLabel.Content = "Sửa Ngọc Trinh";
            }
            else
            {
                WindowModeLabel.Content = "Create Ngọc Trinh";
            }
        }

        //tách hàm nhỏ code cho đẹp, dễ bảo trì
        //hàm 1: Đổ vào ComboBox
        //hàm 2: Đổ vào các component/tag ở edit mode
        //gọi chung là hàm Helper, helper method, nó chỉ cần private
        private void FillComboBox()
        {
            CandidateIdComboBox.ItemsSource = _candService.GetAllCandidates();
            CandidateIdComboBox.DisplayMemberPath = "FullName";
            CandidateIdComboBox.SelectedValuePath = "CandidateId";
        }

        private void FillElements()
        {
            //đổ từ EditedOne vào từng ô nhập 
            TestIdTextBox.Text = EditedOne.TestId.ToString();
            TestIdTextBox.IsEnabled = false; //cấm edit key

            TestTitleTextBox.Text = EditedOne.TestTitle;
            SkillAreaTextBox.Text = EditedOne.SkillArea;
            ScoreTextBox.Text = EditedOne.Score.ToString();
            StartTimeTextBox.Text = EditedOne.StartTime.ToString("hh:mm");
            EndTimeTextBox.Text = EditedOne.EndTime.ToString("hh:mm");
            TakenDateDatePicker.Text = EditedOne.TakenDate.ToString();

            //2 cái time!!!
            //Category - Candiate
            //EditedOne.CandidateId; //số FK đấy gửi cho combo để jump đúng
            CandidateIdComboBox.SelectedValue = EditedOne.CandidateId.ToString(); //đưa đúng value ngầm thịt heo là sẽ nhảy đúng, nhảy đúng Category

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {

            if (LoggedInAccount != null && LoggedInAccount.Role == 3)
            {
                MessageBox.Show("Only admin and manager can update!", "Wrong permission", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }


            //1. phải check xem MODE NÀO, CREATE HAY EDIT? ĐỂ GỌI ĐÚNG SERVICE CREATE/UPDATE
            //1.1 MUỐN GỌI SERVICE THÌ CẦN CHUẦN BỊ SẴN OBJ MOCKTEST ĐC FILL NGƯỢC DATA TỪ MÀN HÌNH 

            //2. ĐỪNG QUÊN CHECK VALIDATION
            //3. F5 CÁI GRID KO LÀM Ở ĐÂY, MÀ BÊN MAIN TỰ LO SAU KHI ĐÓNG MÀN HÌNH NÀY
            //4. ĐÓNG MÀN HÌNH NÀY TRỞ VỀ MAIN

            //MockTest obj = new MockTest() { TestId = 1, TestTitle = TestIdTextBox.Text.Trim()};

            MockTest obj = new MockTest();
            //gọi hàm set riêng lẻ cho dễ đọc code
            //GHI CHÚ QUAN TRỌNG: XEM NGAY LÚC LÀM BÀI, KEY CỦA TABLE CHÍNH LÀ TỰ NHẬP HAY TỰ TĂNG
            //NẾU TỰ TĂNG (IDENTITY), THÌ DISABLE Ô NHẬP KEY TRONG CẢ 2 MODE EDIT VÀ CREATE, VÀ KO ĐC GÁN GIÁ TRỊ CHO OBJ KHI CREATE. CÒN UPDATE VẪN CẦN GÁN KEY ĐANG CÓ!!!!!!

            //KEY TỰ NHẬP, THÌ PHẢI GÁN GIÁ TRỊ LÚC TẠO OBJECT

            //key tự tăng thì code như sau:
            //if (EditedOne != null)
            //{
            //    obj.TestId = int.Parse(TestIdTextBox.Text);
            //}

            //CHẶN VALIDATION TRƯỚC KHI ĐẾN CODE DƯỚI!!!
            //CODE DƯỚI KO CẦN TRY CATCH
            //CHẾ 1 HÀM HELPER RIÊNG
            //if (CheckVar() == false)
            if (!CheckVar())
            {
                return;
            }

            //BÀI NÀY KEY KO TỰ TĂNG NÊN GÁN BÌNH THƯỜNG
            obj.TestId = int.Parse(TestIdTextBox.Text);

            obj.TestTitle = TestTitleTextBox.Text.Trim();
            obj.SkillArea = SkillAreaTextBox.Text.Trim();
            obj.Score = double.Parse(ScoreTextBox.Text); //exception!!!
            obj.StartTime = TimeOnly.Parse(StartTimeTextBox.Text); //exception
            obj.EndTime = TimeOnly.Parse(EndTimeTextBox.Text); //exception
            obj.TakenDate = DateTime.Parse(TakenDateDatePicker.Text);

            //FK QUAN TRỌNG CỰC KÌ
            obj.CandidateId = int.Parse(CandidateIdComboBox.SelectedValue.ToString()); //vì object thì ép kiểu
            
            if (EditedOne != null)
            {
                //edit mode
                _testService.UpdateMockTest(obj);
            }
            else
            {
                //new mode
                _testService.CreateMockTest(obj);
            }
            this.Close(); //đóng cửa sổ này
        }

        public bool CheckVar()
        {
            //check tỪng Ô nhẠp coi Ổn kO
            //mỠi cÁi sai sẼ return false dỌc ĐƯỜng
            if (string.IsNullOrWhiteSpace(TestIdTextBox.Text) || 
                string.IsNullOrWhiteSpace(TestTitleTextBox.Text) ||
                string.IsNullOrWhiteSpace(SkillAreaTextBox.Text) ||
                string.IsNullOrWhiteSpace(ScoreTextBox.Text) ||
                string.IsNullOrWhiteSpace(StartTimeTextBox.Text) ||
                string.IsNullOrWhiteSpace(EndTimeTextBox.Text) ||
                TakenDateDatePicker.SelectedDate == null ||
                CandidateIdComboBox.SelectedValue == null
                )
            {
                MessageBox.Show("All fields are required!", "Input required", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //bắt score số từ  0...180
            bool convertedStatus;
            double result;

            convertedStatus = double.TryParse(ScoreTextBox.Text, out result);
            if (!convertedStatus)
            {
                MessageBox.Show("Score must be a number 0...180!", "Wrong format", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (result < 0 || result > 180)
            {
                MessageBox.Show("Score must be a number 0...180!", "Wrong range", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            int length = TestTitleTextBox.Text.Trim().Length; //chiều dài của title

            if ( length < 5 || length > 150)
            {
                MessageBox.Show("Title must have from 5 to 150 characters!", "Wrong title", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            bool isValidTitle = Regex.IsMatch(TestTitleTextBox.Text, @"^(?:[A-Z0-9][a-z0-9]*)(?: [A-Z0-9][a-z0-9]*)*$");

            if (!isValidTitle)
            {
                MessageBox.Show("Title cannot contain special chars like ?#~!, each word...", "Wrong format", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //string validTitle = ProcessVietnameseString(TestTitleTextBox.Text);
            //if (validTitle == null)
            //{
            //    MessageBox.Show("Title cannot contain special chars like ?#~!", "Wrong format", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return false;
            //}
            ////ko cà chớn, thì chuỗi chuẩn rồi, mình đập ngược lại 
            //TestTitleTextBox.Text = validTitle;


            //giờ có đúng chuẩn hok
            TimeOnly startTime, endTime;
            convertedStatus = TimeOnly.TryParse(StartTimeTextBox.Text, out startTime);
            if (!convertedStatus)
            {
                MessageBox.Show("Start Time must be under format of HH:MM!", "Wrong format", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            convertedStatus = TimeOnly.TryParse(StartTimeTextBox.Text, out endTime);
            if (!convertedStatus)
            {
                MessageBox.Show("End Time must be under format of HH:MM!", "Wrong format", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //if ()
            //{
            //    MessageBox.Show("Start Time must be lower End Time!", "Wrong value", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return false;
            //}

          


            //tẤt cẢ ko sai thÌ return true!!!
            return true;
        }

        public string ProcessVietnameseString(string input)
        {
            // Kiểm tra ký tự đặc biệt: chỉ cho phép chữ cái Unicode, số và khoảng trắng
            if (Regex.IsMatch(input, @"[^\p{L}\p{N}\s]"))
            {
                MessageBox.Show("Chuỗi chứa ký tự đặc biệt không hợp lệ.", "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
                return null;
            }

            // Xóa khoảng trắng dư và viết hoa chữ cái đầu mỗi từ
            TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
            string cleaned = string.Join(" ",
                input.Trim()
                     .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
                     .Select(word => textInfo.ToTitleCase(word.ToLower()))
            );

            return cleaned;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
