﻿using JLPTMockTestManagement.BLL.Services;
using JLPTMockTestManagement.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JLPTMockTestManagement_SE688386
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        //GUI -- SERVICE ---
        private AccountService _service = new();


        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text; //GÕ GÌ LẤY CÁI ĐÓ
            string pass = PasswordTextBox.Text;

            //gọi service để lấy về 1 account
            //Jlptaccount? acc = _service.Authenticate(email, pass);

            Jlptaccount? acc = _service.Authenticate(email);
            if (acc == null)
            {
                MessageBox.Show("Email doesn't exist!", "Wrong email", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //email tồn tại check thử xem pass thế nào?
            if (acc.Password != pass)
            {
                MessageBox.Show("Wrong password!", "Wrong pass", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //gộp 2 if lại thành 1 if acc == null thông báo chung sai email or password!!!
            //CHECK TIẾP ROLE SAU KHI VƯỢT QUA EMAIL VÀ PASS
            if (acc.Role == 4)
            {
                MessageBox.Show("You have no permission", "Wrong permission", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //MỜI VÀO MAIN
            MainWindow main = new();
            this.Hide();

            main.LoggedInAccount = acc; //đã chuyển acc sang bên main
            //y chang chuyển selected sang detail

            main.Show();
        }
    }
}
