﻿using JLPTMockTestManagement.BLL.Services;
using JLPTMockTestManagement.DAL.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JLPTMockTestManagement_SE688386
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //3-layer architect:
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST     2ND         3RD       .json lấy connection to db
        private MockTestService _service = new();

        //thêm 1 prop Account để phân quyền
        //prop này đc truyền từ Login sang
        public Jlptaccount LoggedInAccount { get; set; }
        //bên Login phải .LoggedInAccount = acc vừa where xong!!!

        public MainWindow()
        {

            InitializeComponent();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //MockListDataGrid.ItemsSource = _service.GetAllMockTests();
            FillGrid();

        }

        //1 hàm helper đổ lưới đc dùng lại nhiều lần trong các nút bấm khác nhau
        //sửa lại private cho đúng chất helper
        public void FillGrid()
        {
            //xoá grid đang có và fill lại 
            MockListDataGrid.ItemsSource = null; //xoá
            MockListDataGrid.ItemsSource = _service.GetAllMockTests();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {

            if (LoggedInAccount.Role == 3)
            {
                MessageBox.Show("Only admin and manager can create!", "Wrong permission", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            DetailWindow detail = new(); 
            //ko gửi SelectedOne sang EditedOne 
            detail.ShowDialog();
            //có thể user bấm Cancel, thì ko cần F5 cái grid, Save thì mới F5
            
            FillGrid(); //ko care nhấn nút gì bên kia, chơi lầy lội!!!
            //TODO: VỀ SUY NGHĨ THÊM LỆNH IF ĐỂ F5
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            MockTest selectedOne = MockListDataGrid.SelectedItem as MockTest;

            if (selectedOne == null)
            {
                MessageBox.Show("Please select a row before editing", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //đã chọn rồi, đẩy em sang màn hình detail
            DetailWindow detail = new();
            detail.EditedOne = selectedOne;
            detail.LoggedInAccount = LoggedInAccount; //CHUYỂN ACC SANG DETAIL ĐỂ CẤM EDIT KHI STAFF 
            detail.ShowDialog();
            //f5 grid
            FillGrid();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (LoggedInAccount.Role == 2 || LoggedInAccount.Role == 3)
            {
                MessageBox.Show("Only admin can delete!", "Wrong permission", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }


            MockTest selectedOne = MockListDataGrid.SelectedItem as MockTest;

            if (selectedOne == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBoxResult answer = MessageBox.Show("Are you sure?", "Confirm?", MessageBoxButton.YesNo, MessageBoxImage.Question);
           
            if (answer == MessageBoxResult.No)
            {
                return;
            }

            //gọi _service xoá giúp
            _service.DeleteMockTest(selectedOne); //nhiều chàng trỏ 1 nàng
            //f5 grid
            FillGrid();

        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            List<MockTest> result = _service.SearchByTitleOrSkill(KeywordTextBox.Text);
            if (result.Count == 0)
            {
                MessageBox.Show("Not found!", "Notification", MessageBoxButton.OK, MessageBoxImage.Information);
                return; //giữ nguyên grid như cũ
            }
            //có kết quả search, fill grid lại, vì hàm fill chưa tốt nên ta gọi tay lại
            MockListDataGrid.ItemsSource = null; //xoá
            MockListDataGrid.ItemsSource = result; //gán thẳng từ _service.Search() đc luôn, thì khỏi cần thông báo!!!!!!!!!

        }

        private void QuitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}