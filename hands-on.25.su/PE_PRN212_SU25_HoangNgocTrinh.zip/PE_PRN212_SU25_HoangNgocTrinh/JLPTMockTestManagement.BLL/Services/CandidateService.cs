﻿using JLPTMockTestManagement.DAL.Entities;
using JLPTMockTestManagement.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.BLL.Services
{
    public class CandidateService
    {
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST      2ND         3RD
        private CandidateRepo _repo = new(); 

        //chỉ hàm duy nhất select * from Candidate
        public List<Candidate> GetAllCandidates()
        {
            return _repo.GetAll();
        }
    }
}
