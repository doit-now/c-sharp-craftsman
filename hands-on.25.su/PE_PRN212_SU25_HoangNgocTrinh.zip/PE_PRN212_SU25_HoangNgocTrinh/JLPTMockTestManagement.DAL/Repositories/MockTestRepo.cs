﻿using JLPTMockTestManagement.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.DAL.Repositories
{
    public class MockTestRepo
    {
        //3-layer architect:
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST     2ND         3RD       .json lấy connection to db
        //REPO SẼ CẦN DB CONTEXT GIÚP CRUD TABLE CHÍNH MOCKTEST
        private Su25jlptmockTestDbContext _context; //ko new, khi nào xài ở các hàm thì mới new!!!

        //CÁC HÀM CRUD TABLE MOCKTEST HERE!!! NHỚ NEW _context
        //trả về toàn bộ dữ liệu table chính!!!!! để show vào grid
        public List<MockTest> GetAll()
        {
            //_context = new Su25jlptmockTestDbContext();
            _context = new(); //vế trái có manh mối rồi
            return _context.MockTests.Include("Candidate").ToList();  //join trước, binding trên grid sau!!!
        }

        //CÁC HÀM CREATE, (R: READ, RETRIEVE) UPDATE, DELETE
        public void Create(MockTest obj)
        {
            _context = new();
            _context.MockTests.Add(obj);
            _context.SaveChanges(); //vip, cực kì quan trọng
        }
        //overload
        public void Create(int testId, string testTitle, string skillArea, double score)  //time
        {
            //gọi DbContext
            _context = new();
            _context.MockTests.Add(new MockTest() { TestId = testId, TestTitle = testTitle });
            _context.SaveChanges(); //vip, cực kì quan trọng
        }

        public void Update(MockTest obj)
        {
            _context = new();
            _context.MockTests.Update(obj);
            _context.SaveChanges();
        }

        public void Delete(MockTest obj)
        {
            _context = new();
            _context.MockTests.Remove(obj);
            _context.SaveChanges();
        }

    }
}
