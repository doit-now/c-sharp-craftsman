﻿using JLPTMockTestManagement.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLPTMockTestManagement.DAL.Repositories
{
    public class CandidateRepo
    {
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST      2ND         3RD
        private Su25jlptmockTestDbContext _context; //ko new, vào từng hàm mới new, chơi dao!!!
       

        public List<Candidate> GetAll()
        {
            //hàm này trả về full danh sách Category, với bài này thì là danh sách ứng viên, để dùng hiển thi trong ComboBox, chứ ko vào Grid, theo style treo đầu dê lấy thịt heo!
            //_context = new Su25jlptmockTestDbContext();
            _context = new();
            return _context.Candidates.ToList(); 
        }

    }
}
