﻿using JLPTMockTestManagement.BLL.Services;
using JLPTMockTestManagement.DAL.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JLPTMockTestManagement_SE688386
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //3-layer architect:
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST     2ND         3RD       .json lấy connection to db
        private MockTestService _service = new();

        public MainWindow()
        {

            InitializeComponent();

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //MockListDataGrid.ItemsSource = _service.GetAllMockTests();
            FillGrid();

        }

        //1 hàm helper đổ lưới đc dùng lại nhiều lần trong các nút bấm khác nhau
        //sửa lại private cho đúng chất helper
        public void FillGrid()
        {
            //xoá grid đang có và fill lại 
            MockListDataGrid.ItemsSource = null; //xoá
            MockListDataGrid.ItemsSource = _service.GetAllMockTests();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            DetailWindow detail = new(); 
            //ko gửi SelectedOne sang EditedOne 
            detail.ShowDialog();
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            MockTest selectedOne = MockListDataGrid.SelectedItem as MockTest;

            if (selectedOne == null)
            {
                MessageBox.Show("Please select a row before editing", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //đã chọn rồi, đẩy em sang màn hình detail
            DetailWindow detail = new();
            detail.EditedOne = selectedOne;
            detail.ShowDialog();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            MockTest selectedOne = MockListDataGrid.SelectedItem as MockTest;

            if (selectedOne == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBoxResult answer = MessageBox.Show("Are you sure?", "Confirm?", MessageBoxButton.YesNo, MessageBoxImage.Question);
           
            if (answer == MessageBoxResult.No)
            {
                return;
            }

            //gọi _service xoá giúp
            _service.DeleteMockTest(selectedOne); //nhiều chàng trỏ 1 nàng
            //f5 grid
            FillGrid();

        }
    }
}