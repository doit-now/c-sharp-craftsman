﻿using JLPTMockTestManagement.BLL.Services;
using JLPTMockTestManagement.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing.IndexedProperties;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace JLPTMockTestManagement_SE688386
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    public partial class DetailWindow : Window
    {

        //cần 1 prop để kiểm soát mode của màn hình này: Edit hay Create
        //EDIT MODE THÌ TA SẼ NHẬN 1 SELECTED MOCKTEST TỪ BÊN MÀN HÌNH MAIN
        //VÀ TA DÙNG BIẾN NÀY ĐỂ IF XEM MÀN HÌNH NÀY Ở MODE NÀO
        //VÌ CREATE THÌ BIẾN PROP NÀY == NULL

        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //1ST      2ND         3RD

        //Màn hình này cần 2 Service
        //Service 1: Dùng cho đổ vào combobox -> CandateService
        //Service 2: Dùng để cho nút bấm Save hoạt động theo 2 mode: tạo mới hay update ứng với 2 câu SQL: insert into, hay update from 
        private CandidateService _candService = new(); //đổ vào combo 
        private MockTestService _testService = new();  //save màn hình xuống DB

        public MockTest EditedOne { get; set; } = null;

        public DetailWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillComboBox();
            if (EditedOne != null)
            {
                FillElements(); //edit nè bạn, đổ info cũ vào các ô nhập để sửa
                WindowModeLabel.Content = "Sửa Ngọc Trinh";
            }
            else
            {
                WindowModeLabel.Content = "Create Ngọc Trinh";
            }
        }

        //tách hàm nhỏ code cho đẹp, dễ bảo trì
        //hàm 1: Đổ vào ComboBox
        //hàm 2: Đổ vào các component/tag ở edit mode
        //gọi chung là hàm Helper, helper method, nó chỉ cần private
        private void FillComboBox()
        {
            CandidateIdComboBox.ItemsSource = _candService.GetAllCandidates();
            CandidateIdComboBox.DisplayMemberPath = "FullName";
            CandidateIdComboBox.SelectedValuePath = "CandidateId";
        }

        private void FillElements()
        {
            //đổ từ EditedOne vào từng ô nhập 
            TestIdTextBox.Text = EditedOne.TestId.ToString();
            TestIdTextBox.IsEnabled = false; //cấm edit key

            TestTitleTextBox.Text = EditedOne.TestTitle;
            SkillAreaTextBox.Text = EditedOne.SkillArea;
            ScoreTextBox.Text = EditedOne.Score.ToString();
            //2 cái time!!!
            //Category - Candiate
            //EditedOne.CandidateId; //số FK đấy gửi cho combo để jump đúng
            CandidateIdComboBox.SelectedValue = EditedOne.CandidateId.ToString(); //đưa đúng value ngầm thịt heo là sẽ nhảy đúng, nhảy đúng Category

        }
    }
}
