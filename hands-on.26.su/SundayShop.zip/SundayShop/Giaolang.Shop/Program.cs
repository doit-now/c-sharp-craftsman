﻿using Giaolang.Shop.Entities;

namespace Giaolang.Shop
//~ package com.microsoft.sqlserver.
//đều có tên thương hiệu, chủ sở hữu sản phẩm
//dấu chấm chia tẩng thư mục quản lí cho gọn gàng


{
    internal class Program
    {
        static void Main(string[] args)
        {
            CreateFruits();
        }

        public static void CreateFruits()
        {
            //tạo trái Mãng Cầu, y chang bên Java. import thay bằng using
            //in thông tin qua ToString()
            Fruit cau = new Fruit(); //object tạo ra, tốn ram, nhưng vùng _ chứa giá trị default
            Console.WriteLine("CAU details: " + cau.ToString());

            Fruit sung = new Fruit("SS", "SUNG SƯỚNG", "SUNG LÀ TRÁI THỨ 2 TRONG MÂM NGŨ QUẢ", 5.0); //object tạo ra, tốn ram, vùng _ chứa giá trị ĐC FILL QUA CONSTRUCTOR

            Console.WriteLine("SUNG details: " + sung.ToString());

            //trái dừa
            Fruit dua = new Fruit("DD", "DỪA DỪA CX CX", "TRÁI DỪA LÀ...", 6.0);
            Console.WriteLine("DUA details: " + dua.ToString());

            //trái ĐU ĐỦ
            //tham số hàm, phải đưa đúng stt khai báo biến, data type
            //Fruit du = new Fruit(7.0, "DU", "ĐU ĐỦ", "TRÁI DỪA LÀ..."); //ERROR LIỀN

            Fruit du = new Fruit(price: 7.0, id: "DU", description: "TRÁI DỪA LÀ...", name: "ĐU ĐỦ");
            //named-argument: truyền tham số cho hàm ko theo thứ tự đc yêu cầu,
            //nhưng chỉ rõ biến nào của hàm nhận value nào, là okie
            //LỘN XỘN THỨ TỰ NHƯNG RÕ TÊN BIẾN THÌ OKIE

            Console.WriteLine("DU details: " + du.ToString());

            cau.SetId("MC");
            cau.SetDesc("MÃNG CẦU LÀ ĐẦU CÂU CHUYỆN...");
            cau.SetName("MÃNG CẦU");
            cau.SetPrice(4.0);

            Console.WriteLine("CAU details AFTER SETTING: " + cau.ToString());

        }
    }
}
