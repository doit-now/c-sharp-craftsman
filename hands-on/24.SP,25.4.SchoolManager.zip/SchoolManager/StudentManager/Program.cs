﻿using StudentManager.Entities;
using StudentManager.Services;
using System.Globalization;

namespace StudentManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //time for us to buy many Cabinets, each of them has a room - 300 spaces to store multiple students
            //for each DEpartment

            Cabinet seBox = new Cabinet(); //we have 300 spaces, _count = 0
            Cabinet bizBox = new Cabinet(); //we have 300 spaces, _count = 0
                                            //

            seBox.AddANewStudent("SE1", "An", "an@", 2002, 8.6);
            seBox.AddANewStudent("SE2", "Binh", "binh@", 2003, 6.8);

            bizBox.AddANewStudent("SS1", "Cuong", "cuong@", 2005, 5.5);
            bizBox.AddANewStudent("SS10", "Hoa", "hoa@", 2004, 6.6);

            Console.WriteLine("The Biz students");
            bizBox.PrintStudentList();

            Console.WriteLine("The SE students");
            seBox.PrintStudentList();

        }

        //to store multiple Students, we need mutiple variables
        //Student[]   
        //we need multiple new Student() //  () NOT []
        static void PlayWithObjectArray()
        {
            Student[] arr = new Student[5]; //[] not () 
                                            //because we declare variables
                                            //not create a Student object
                                            //at this time

            //for now we have 5 variables to store 5 Student in detailed
            arr[0] = new Student() {Id = "SE1", Name = "An", Email = "an@fpt.edu.vn", Yob = 2003, Gpa = 8.6 };

            arr[1] = new Student() { Id = "SE66", Name = "Binh", Email = "binh@fpt.edu.vn", Yob = 2006, Gpa = 6.6 };

            arr[2] = new Student() { Id = "SE55", Name = "Cuong", Email = "cuong@fpt.edu.vn", Yob = 2005, Gpa = 5.5 };

            arr[3] = new Student() { Id = "SE40", Name = "Duong", Email = "duong@fpt.edu.vn", Yob = 2004, Gpa = 4.0 };

            arr[4] = new Student() { Id = "SE70", Name = "Hoa", Email = "hoa@fpt.edu.vn", Yob = 2007, Gpa = 7.0 };

            //for now, print the student list
            Console.WriteLine(arr[0].ToString());
            Console.WriteLine(arr[1]); //pro guy never calls ToString() explicitly = gọi thầm tên em
            Console.WriteLine(arr[2]);
            Console.WriteLine(arr[3]);
            Console.WriteLine(arr[4]);

            //with array we use FOR TO SCAN THE WHOLE OF ARRAY
            Console.WriteLine("The student list printed by traditional for");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]); //call ToString() implicitly
            }                              //gọi thầm tên em ToString()
            
            Console.WriteLine("The student list printed by for each");
            foreach (Student x in arr) //x = arr[0]  x = arr[1] x = arr[2]
            {
                Console.WriteLine(x); //like for each in Math
                                      //giống toán tử với mọi trong Toán
            }
            foreach (var x in arr) //x = arr[0]  x = arr[1] x = arr[2]
            {
                Console.WriteLine(x); //like for each in Math
                                      //giống toán tử với mọi trong Toán
            }


        }

        //THE PROBLEM TO DO AT HOME 
        //1. SHOW THE STUDENT LIST BY NAME ASCENDING (A -> Z)
        //2. SHOW THE STUDENT LIST BY GPA DESCENDING (10 -> 0)
        //3. SHOW THE STUDENT LIST BY YOB DESCENDING (2010 -> 1990 E.G)
        //SORTING ALGORITHM 

        static void PlayWithValueTypeArray()
        {
            //i want store 10 numbers like 5 10 15 20 25 30 35 40 45 50
            //and compute the sum of them!!!!!!!!!!
            //how?
            //1st answer: we need 10 descrete/arbitrary variables: 10 biến lẻ
            int a1 = 5, a2 = 10, a3 = 15, a4 = 20, a5 = 25, b = 30, c = 35, d = 40, e = 45, f = 50;
            int sum = a1 + a2 + a3 + a4 + a5 + b + b + c + d + e + f;
            //NO A GOOD WAY, BECAUSE WE NEED SO MUCH EFFORT TO WRITE THE CODE
            //WRITE THE DIFFERENT NAME OF VARIABLES

            //2ND ANSWER: GOOD WAY BUT A LITTLE COMPLEX
            //USING ARRAY, COLLLECTION (LIST, ARRAYLIST...)
            
            int[] arr = new int[100];
            //we have 10 int variables like above!!!
            //10 int variables: arr[0]  arr[1] arr[2]  arr[3] arr[4]  arr[5]...
            //                   a1      a2       a2     b     c        d
            //assign the value
            arr[0] = 5;
            arr[1] = 10;
            arr[2] = 15;
            arr[3] = 20;
            arr[4] = 25;
            arr[5] = 30;
            //arr[6] = 35;

            //[index - the position in the array, the order of each variable
            // count from 0...]

            //print out
            //4 ways to print out: take each, for, for each, delegate
            //take each
            Console.WriteLine("The array of ten numbers");
            Console.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9}", arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8], arr[9]);

            Console.WriteLine($"{arr[0]} {arr[1]} {arr[2]}");

            //the rest of the array will take the default value
            //the variable is not assigned value will be set a default one!

            Console.WriteLine("The array of ten numbers (printed using for)");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
                //Console.Write($"{arr[i]} ");
            }

            Console.WriteLine("The array of ten numbers (printed using for each)");

            foreach (int x in arr)
            {
                Console.Write(x + " ");
            }





        }
        //Array is a collection of multiple variables with the same name, the same data type...

        //Array is the declaration of multiple variables at a same time, the same data type, the same name, and they are allocated next together in RAM
    
    }
}
