﻿using StudentManager.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Services
{
    internal class Cabinet
    {
        private Student[] _list = new Student[300];
        private int _count = 0; //to count how many object do we have in the array, we will for from 0 to this number instead of for to the end of the array
        //add a new Student, _count++ 
        //[_count] = new Student();
        //_count++;

        //we donot use Propery in this class 
        
        //public Student[] List {get; set;} property
        //public int Yob {get; set;}  //property also

        //.List = ???? another array to assign
        //.Yob = 2003; it is okie
        //.List  is an array, you should assign the value of an array step by step, value by value like
        //   List[0] = 
        //   List[1] = a student
        //   List[i] = a student
        //we buy an empty Cabinet ~ an empty array
        //and we add [i] one one by one!!! is a good way
        //CRUD METHOD:
        //CREATE A NEW STUDENT PROFILE, PUT IT INTO THE ARRAY AT POSITION [INDEX]
        //PRINT THE STUDENT LIST BY USING FOR...
        public void PrintStudentList()
        {
            Console.WriteLine("There is/are student(s) in the cabinet");
            //foreach (Student student in _list) { }
            //do not use foreach because the some time the cabinet is not full. We print out the existing profile instead.   
            //for (int i = 0; i < _list.Length; i++)
            //not exactly, you will see multiple empty info

            for (int i = 0; i < _count; i++)
            {
                Console.WriteLine(_list[i]);
            }                   //pro guy never calls ToString()
                                //explicitly

           
        }

        //CREATE METHOD, ADD NEW STUDENT PROFILE LIKE OPEN THE DOOR, PUT A PROFILE INTO THE CABINET
        public void AddANewStudent(string id, string name, string email, int yob, double gpa)
        {
            _list[_count] = new Student() {Id = id, Name = name, Email = email, Yob = yob, Gpa = gpa };
            _count++; //increase the position in the array to put in
        }             // tăng vị trí bỏ vào mảng

    }

}
//CHALENGE AT HOME
//CREATE SEPARATE PRINT() METHODS TO SORT THE STUDENT LIST BASED ON SOME CRITERIA: ASCENDING IN GPA,...
