﻿using StudentManagerV2MultipleConstructors.Entities;

namespace StudentManagerV2MultipleConstructors
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int xxx;
            //Console.WriteLine($"{xxx}");  //ĂN ĐÒN, LỖI NGAY LÚC GÕ DO LẤY RÁC TRONG RAM ĐỂ IN

            Student s1 = new("SE1", "AN", 2004, 8.6);
            
            Student s2 = new(gpa: 8.7, yob: 2004, name: "BINH", id: "SE2");  //named argument, đảo thứ tự biến của hàm 

            var s3 = new Student("SE3", "CƯỜNG"); //DEFAULT GPA, YOB

            Console.WriteLine("s3 details with default values inside");
            Console.WriteLine(s3); //gọi thầm tên em ToString()

            s3.SetYob(2005);
            s3.SetGpa(9.99);
            Console.WriteLine("s3 details after setting");
            Console.WriteLine(s3);


            //CÓ BAO NHIÊU CONSTRUCTOR CÓ BẤY NHIÊU CÁCH NEW
            //VÀ NHỚ LÀ GIÁ TRỊ DEFAULT NẾU KO ĐIỀN ĐỦ INFO (KO MANG RÁC NHƯ BIẾN LOCAL)

            //HÀM SET() GET() GỌI THOẢI CON GÀ MÁI N LẦN TRÊN TỪNG
            //OBJECT MÀ KO TẠO RA VÙNG NEW MỚI 
            //NÓ CHỈNH SỬA INFO CỦA OBJECT, VÙNG NEW ĐÃ TẠO TRƯỚC ĐÓ
            //Y CHANG MÌNH ĐỔI AVATAR CẢ VẠN LẦN, VẪN LÀ MÌNH

            //HÀM NEW KÈM CONSTRUCTOR -> VÙNG NEW MỚI, OBJECT ĐC TẠO RA, CỨ NEW LÀ VÙNG OBJECT RAM MỚI!!!

            //NEW PHẢI CÓ BIẾN ĐỂ THAM CHIẾU, NẾU KO!!!!!!!!!!

            //tui mún lưu trữ sv thứ 4

            Student s4 = new Student("SE4", "DŨNG STANDARD", 2006, 9.0);
            //NEW trả về toạ độ, trả về địa chỉ căn nhà bự trong ram
            //trả về địa chỉ vùng new, byte thứ mấy trong ram
            //địa chỉ đó đc gán cho s4, s4 hay gọi là con trỏ, pointer, points to vùng new
            //s4. tức là vào vùng new. tức là vào vùng new xem có đứa nào public ko thì mình giao tiếp với nó
            //y chang đi đến cổng 1 căn nhà, bấm chuông . đó
            //gia chủ có muốn ra tiếp hay ko - public hay private


            s4.ShowProfile();

            new Student("SE4", "DŨNG", 2005, 9.0).ShowProfile();
            //object đc tạo ra nhưng lại ko biến để móc vào để tham chiếu lâu dài
            //y chang con diều bay cao và đứt dây
            //ta ko có cơ hội giựt giựt dây diều nhiều lần, gọi hàm object nhiều lần
            //vùng new đc tạo ra mà ko có biến móc vào, vùng object này gọi là OBJECT VÔ DANH, ANONYMOUS OBJECT
            //TA CHỈ CÓ CƠ HỘI GỌI HÀM CỦA NÓ, VÀO VÙNG NEW CHẤM ĐÚNG 1 LẦN, VÌ VỪA NEW LÀ CÓ TOẠ ĐỘ, CHẤM ĐC NGAY!!!
            //SAU ĐÓ KO LƯU TOẠ ĐỘ LÂU DÀI, LÀM SAO CHẤM TIẾP, LÀM SAO GỌI HÀM TIẾP ĐC
            //VÙNG RAM MÀ KO CÓ CON TRỎ MÓC VÀO, CHƠI TRÒ NÀY MAU HẾT RAM, LEAK MEMORY, CHO NÊN JAVA, C# CÓ 1 CƠ CHẾ GIÁM SÁT VÙNG RAM, RUNTIME CÓ 1 ĐOẠN CODE NHO NHỎ, ĐỊNH KÌ QUÉT VÙNG RAM COI CÓ CON DIỀU NÀO ĐỨT DÂY HAY KO, OBJECT NÀO KO CÓ CCON TRỎ, NÓ CLEAR, ĐÁNH DẤU VÙNG RAM TỰ DO, ĐỂ SAU NÀY NEW TIẾP. ĐOẠN CODE NÀY GỌI LÀ CTY MÔI TRƯỜNG ĐÔ THỊ, DỌN RÁC OBJECT - GARBAGE COLLECTOR

            //KHI NÀO CHƠI TRÒ ANONYMOUS OBJECT 
            //TA CHỈ MUỐN TẠO OBJECT, GỌI HÀM, LẤY KẾT QUẢ TRẢ VỀ, RỒI THÔI KO CARE OBJECT
            //==================
            //JAVA:
            //Random rd = new Random();  //class sinh ra con số ngẫu nhiên
            //double x = rd.nextDouble(); //[0..1)
            //double x = new Random().nextDouble();

            //NẾU TA MUỐN LOẠI BỎ 1 OBJECT TRONG RAM, DẸP 1 VÙNG NEW KO DÙNG NỮA, THÌ LOẠI BỎ HẾT CÁC BIẾN TRỎ ĐẾN NÓ LÀ XONG
            //LOẠI = CÁCH CHO BIẾN TRỎ VÙNG NEW KHÁC HOẶC CHO BIẾN = NULL, TRỎ ĐÁY RAM LÀ XONG
            s4 = null; //vùng new trước đó bị trỏ bởi s4 đã mồ côi
            //CTY MTĐT DỌN DẸP SỚM

            //= null dùng khi: reset biến object của ta, hoặc trả về nothing khi search 1 object ko thấy!!!
            //thấy thì phải trỏ vùng new đã có!!!!





        }


    }
}
