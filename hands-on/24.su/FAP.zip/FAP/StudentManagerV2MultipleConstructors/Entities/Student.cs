﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerV2MultipleConstructors.Entities
{
    public class Student
    {
        private string _id;    //___________  (*)
        private string _name;  //___________  (*)
        private int _yob;     //____________
        private double _gpa;  //____________

        public Student(string id, string name, int yob, double gpa)
        {
            _id = id;
            _name = name;
            _yob = yob;
            _gpa = gpa;
        }

        public Student(string id, string name)
        {
            _id = id;
            _name = name;
        }

        //NẾU 1 OBJECT LÚC ĐC KHỞI TẠO, LÚC ĐC NEW MÀ KO GÁN/KO ĐỔ HẾT VALUE VÀO TRONG, THÌ CÁC ĐẶC ĐIỂM, FIELD KO ĐC ĐỔ SẼ MANG GIÁ TRỊ DEFAULT, KHÁC BIẾN CỤC BỘ LÀ MANG RÁC

        //KO BỊ SỢ CẢNH BÁO SAI CODE VÌ DÙNG RÁC, DO NEW ĐÃ DỌN DẸP RÁC RAM SẴN RỒI!!!

        //CHỨNG MINH = CÁCH NEW OBJECT

        //SỐ -> DEFAULT LÀ 0
        //CHUỖI -> RỖNG NULL
        //BOOL -> FALSE



        //public override string? ToString()
        //{
        //    return $"Id: {_id} | Name: {_name} | Yob: {_yob} | Gpa: {_gpa}";
        //}

        public override string ToString() => $"Id: {_id} | Name: {_name} | Yob: {_yob} | Gpa: {_gpa}";

        //hàm ShowProfile() in luôn, làm biếng gọi luôn ToString()
        //hàm gọi hàm!!!!
        public void ShowProfile() => Console.WriteLine(ToString());
        
        public string GetName()  //getName()
        {
            return _name;
        }

        //HÀM SET() NHẬN VALUE BÊN NGOÀI ĐƯA VÀO, ĐẶT TÊN BIẾN VALUE BÊN
        //NGOÀI LÀ GÌ CX ĐC, MIỄN CÓ Ý NGHĨA
        public void SetName(string value)
        {
            _name = value;
        }
        public int GetYob() => _yob;

        public void SetYob(int value) => _yob = value;

        public void SetGpa(double value) => _gpa = value;
        //điểm cũ bị đè bởi điểm mới
        //avatar cũ bì đè bởi avatar mới



        //1 form có nhiều cách điền, 1 account có những info phải điền trước, info khác điền sau, linh hoạt trong cách điền info. Vậy ta cx có nhiều constructor ứng với nhiều cách điền info khác nhau, đúc tượng với chất liệu khác nhau liều lượng khác nhau
        //1 class có nhiều constructor, ứng với có nhiều cách tạo object từ 1 cái class/khuôn

        //CONSTRUCTOR LÀ HÀM LUÔN GỌI KÈM TOÁN TỬ NEW
        //NEW NGHĨA LÀ XIN VÙNG RAM, NGHĨA LÀ ĐI CLONE, PHOTO TỜ GIẤY FORM, ĐỂ CHUẨN BỊ ĐIỀN INFO. TÊN NÓ VÌ VẬY PHẢI 100% GIỐNG TÊN CLASS MANG Ý NGHĨA CLONE 1 STUDENT, NEW 1 STUDENT, NEW 1 CÁI FORM ĐỂ ĐIỀN VÀO. THAM SỐ CHÍNH LÀ CÁCH ĐỔ MỰC ĐIỀN MỰC VÀO CÁC INFO CHỪA CHỖ, LÀ CÁCH ĐỔ VẬT LIỆU VÀO CÁC CHI TIẾT NGÓC NGÁCH TRONG KHUÔN
        //ctrl . chọn generate constructor






    }
}
