﻿using StudentManagerV1.Entities;
using System.Diagnostics;

namespace StudentManagerV1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //đúc object, clone cái form, khuôn, class, template, fill info vào - nhiều việc cùng lúc: gọi new gọi phễu constructor kèm value vật liệu mực bút đổ vào
            //giống đưa hệ số cho phương trình bậc 2 để có 1 pt cụ thể
            Student        s1        = new Student("SE1", "AN", 2004, 8.6);
            //data type  biến obj            object tốn ram bự chà bá
            //                         public và private gì đó ở object
            //                 chấm đề giao tiếp
            Console.WriteLine("s1 shows profile...");
            s1.ShowProfile();

            Student s2= new Student("SE2", "BÌNH", 2004, 8.7);
            Console.WriteLine("s2 shows profile");
            Console.WriteLine(s2.ToString());
            Console.WriteLine(s2); //gọi thầm tên em ToString()

            //và nếu ko có ToString(), Java sẽ băm (hash/hasing) vùng new thành dãy hexa
            //C# nó sẽ làm biếng nó báo, vùng new này là vùng Student
            //muốn ko bị khó hiểu kết quả, hay mún in toàn bộ info bên trong object đã đổ vào, in toàn bộ info của vùng new bạn nên chủ động tạo hàm ToString() và khi gọi hàm này ko cần .ToString(), C# và Java tự gọi giùm
            //khi dùng biến object ở các lệnh kiểu chuỗi cw(biến-object)

            Student s3 = new ("SE3", "CƯỜNG", 2004, 8.8);
            //KO CẦN new Student - cú pháp mới do đã có Student ở vế trái rồi
            Console.WriteLine("s3 shows profile...");
            s3.ShowProfile();

            var s4 = new Student ("SE4", "DŨNG", 2004, 8.9);
            //TYPE INFERENT - SUY LUẬN KIỂU - CÓ MANH MỐI CHO MÌNH SUY RA VÙNG NEW
            Console.WriteLine("s4 shows profile...");
            s4.ShowProfile();

            //var s5 = new Student("EM", 2004, 9.0, "SE5"); //ERROR SAI KIỂU DATA TRUYỀN VÀO HÀM, HÀM YÊU CẦU TUÂN THỦ THỨ TỰ KHAI BÁO VÀ TRUYỀN

            //NHƯNG...
            var s5 = new Student(name:"EM", yob: 2004, gpa: 9.0, id: "SE5");
            //named argument: dùng tên tham số để đảo thứ tự đầu vào theo ý thích
            Console.WriteLine("s5 shows profile...");
            s5.ShowProfile();

            Student s6 = s5;
            //hai chàng trỏ 1 nàng 
            //void F(Student x) 
            //{
            //    x thay đổi x. cái gì đó thì nơi gọi ngoài hàm bị thay đổi theo
            //}

            //F(s5) x thay đổi vùng ram vì đang trỏ cùng s5,
            // thì s5 bị thay đổi
            //BIẾN OBJECT LÀ TRUYỀN THAM CHIẾU, TRONG HÀM THAY ĐỔI VÙNG NEW NGOÀI HÀM THAY ĐỔI THEO MÀ KO CẦN REF VÀ OUT

            //gọi hàm nhận vào 1 object, biến object
            Console.WriteLine("Check s5 before calling method");  //9.0
            Console.WriteLine(s5);  //gọi thầm tên em ToString()
            PassAStudent(s5);
            Console.WriteLine("Check s5 after calling method");  //9.99
            Console.WriteLine(s5);

        }

        //THỬ NGHIỆM VỀ TRUYỀN OBJECT - BẢN CHẤT LÀ TRUYỀN ĐỊA CHỈ - THAM CHIẾU - MÀ KO CẦN REF VÀ OUT
        static void PassAStudent(Student x)  //x là biến object
        {                                    //nó sẽ lưu toạ độ 1 vùng new 

            x.SetGpa(9.99);  //2 chàng trỏ 1 nàng, x và biến đưa vào
        }                    //cùng trỏ 1 vùng new
                             //x sửa gì vùng new qua x.Set(...)
                             //thì vùng new bên ngoài của biến đưa vào
                             //bị sửa luôn
                             //nên: TRUYỀN BIẾN OBJECT QUA HÀM BẢN CHẤT LÀ
                             //TRUYỀN THAM CHIẾU RỒI MÀ KO CẦN REF OUT
                             //TRONG HÀM MÀ SỬA, NGOÀI HÀM HỐT ĐỦ 
                             //TRONG HÀM ẢNH HƯỞNG BÊN NGOÀI XA XA - CHIẾU
                             //RỌI - REFERENCE
    }
}
