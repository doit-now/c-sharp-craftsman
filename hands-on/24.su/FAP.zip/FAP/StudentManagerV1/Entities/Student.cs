﻿using System;
using System.Collections.Generic;
using System.Linq;  //StreamAPI bên Java (Lambda Expression)
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerV1.Entities
{
    public class Student
    {
        private string _id; //đặc điểm, field, state, biến đb nằm ngoài hàm, nhưng trong class,  của 1 object theo quy tắc: con Lạc Đà, và _ từ đầu tiên
        private string _name; //_____________
        private int _yob;     //_____________
        private double _gpa;  //_____________

        //lấy cây bút điền info vào form khi mình new, clone, xin 1 cái form để lưu info, khi mình cần lưu info của 1 sv mới bất kì
        //nói theo cái Khuôn đúc, thì nó chính là cái phễu hứng vật liệu đổ vào trong Khuôn
        //HÀM CONSTRUCT[OR]
        public Student(string id, string name, int yob, double gpa)
        {
            this._id = id; //thừa this. ko sai
            _name = name;
            _yob = yob;
            _gpa = gpa;
        }

        //LẬP TRÌNH CLASS/OOP CHÍNH LÀ LẬP TRÌNH CÁC XỬ LÍ TRÊN CÁC BIẾN 1 CÁCH CHUNG CHUNG NHẤT, LÁT HỒI ĐỔ INFO VÀO SẼ CÓ GIÁ TRỊ CỤ THỂ
        //Y CHANG NHƯ GIẢI PHƯƠNG TRÌNH BẬC 2 AX^2 + BX + C = 0
        //                         DELTA = B^2 - 4A.C
        //                         DELTA > 0, X1 = ..., X2 = ...
        //MAI MỐT ĐƯA INFO CỤ THỂ VÀO, THÌ CÓ INFO CỤ THỂ TRẢ VỀ SAU XỬ LÍ
        //ĐƯA A B C VÀO THÌ CÓ X1 X2
        //ĐƯA ID, NAME, YOB, GPA, CÓ CÁI GÌ ĐÓ TRẢ VỀ CỤ THỂ: TUỔI = 2024 - YOB
        //                                                         = CURRENT YEAR - YOB
        //                                                         
        //CÁC HÀM XỬ LÍ INFO RA VÔ OBJECT, Y CHANG MÌNH GIAO TIẾP BÊN NGOÀI ĐỜI
        //HÀM HỎI - HỎI NHAU CÂU CHUYỆN - GET() GETTER() 
        public string GetName()
        {
            return _name;
        }

        public int GetYob()
        {
            return _yob;
        }

        public double GetGgpa() => _gpa; //expression body/bodied

        //HÀM THAY ĐỔI - THẤY THẰNG BẠN CÓ GÌ, MÌNH VỀ BẮT CHƯỚC CHỈNH SỬA MÌNH SET() SETTER() SETTING() 
        public void SetName(string name)
        {
            _name = name;
        }

        public void SetYob(int yob)
        {
            _yob = yob;
        }

        public void SetGpa(double gpa) => _gpa = gpa;

        //HÀM FLEX NHIỀU INFO HƠN, THAY VÌ LẺ TỪNG MIẾNG INFO GET LẺ()
        //Y CHANG MỖI CÁ NHÂN CÓ 1 CÁI PROFILE TRÊN MXH: FB, TIKTOK, LINKED IN

        public void ShowProfile()
        {
            //show theo style FB
            Console.WriteLine("My profile:");
            Console.WriteLine("ID: " + _id);
            Console.WriteLine("Name: {0}", _name);
            Console.WriteLine($"Yob: {_yob}");
            Console.WriteLine(@$"Gpa: {_gpa}"); //dư @ vì mình ko in gì đặc biệt
        }

        //hành động chuẩn hoá của mọi object, như hành động đem theo CMND, CCCD khi đc hỏi show ra cho việc kiểm tra hành chính
        //với lập trình object show hết info thân nhân gọi là ToString()  toString()
        //HÀM JAVA: verb + Object theo con Lạc Đà()
        //HÀM C#  : Verb + Object theo Pascal

        //@Override
        public override string ToString() => $"ID: {_id} | Name: {_name} | Yob: {_yob} | Gpa: {_gpa}";


        //public override string ToString()
        //{
        //    string msg = $"ID: {_id} | Name: {_name} | Yob: {_yob} | Gpa: {_gpa}";
        //    return msg;
        //}

    }
}

//Class là 1 tên gọi chung, 1 danh từ chung, là tên gọi cho sự phân nhóm, phân loại/classify 1 đám object có điểm tương đồng: về đặc điểm và hành vi
//An Bình Cường Dũng... -> share chung nhiều đặc điểm hành vi
//  - Đặc điểm: id, name, yob, place of birth, address, major, gpa...
//  - Hành vi: DoQuiz() DoFinalExam() DoPresentation() ChatInClass() PlayGameInClasas()
//  Các bạn A B C D thuộc nhóm Student 
//                                ID: ______________
//                              Name: ______________
//                               Yob: ______________
//                             Major: ______________
//                               Gpa: ______________
//                PlayGame() -> rank: ______________
//Class ~ Khuôn đúc - Mold, Template, Blue-print (bản thiết kế), Form - biểu mẫu nhập 
//Chỉ cần chờ đổ info vào nữa là ra 1 cái gì đó cụ thể - OBJECT
//LÀM CÁI FORM/CLASS STUDENT - NHÓM SV ĐC LỢI ÍCH GÌ???
//KHI CÓ 1 SV MỚI ĐĂNG KÍ NHẬP HỌC, TA CHỈ CẦN CLONE (NEW) TẠO FORM TRỐNG CHO NGƯỜI ĐÓ, ĐỔ INFO VÀO VÀ TA ĐÃ LƯU TRỮ ĐC INFO CỦA 1 OBJECT
//NGƯỜI KHÁC ĐẾN -> NEW, CLONE FORM, FILL INFO -> OBJECT KHÁC ĐC LƯU

//RÕ RÀNG CLASS LÀ KHUÔN GIÚP ĐÚC/CLONE/NEW ĐC NHIỀU OBJECT 1 CÁCH HIỆU QUẢ
//LẬP TRÌNH OOP - OBJECT ORIENTED PROGRAMMING/PARADIGM 
//LỐI TƯ DUY VỀ CÁCH LƯU TRỮ, QUẢN LÍ THÔNG TIN QUANH TA QUA NHẬN DIỆN OBJECT -> TÌM RA CLASS -> CLONE OBJEC MỚI TRỞ LẠI

//OBJECT, OBJECT, OBJECT... -> CLASS X
//OBJECT, OBJECT, OBJECT... -> CLASS Y

//CLASS -> NEW OBJECT

//TỪ X, Y, CLONE TRỞ LẠI CÁC OBJECT KHÁC TƯƠNG ĐƯƠNG NEW, LƯU TRỮ INFO CỦA CÁC OBJECT KHÁC PHÁT SINH TRONG TƯƠNG LAI
//VỚI 1 TRƯỜNG HỌC, NEW HOÀI STUDENT()
//VỚI 1 CTY BÁN HÀNG, NEW HOÀI ORDER() PAYMENT()
//VỚI 1 CTY QUẢN LÍ TOUR DU LỊCH, NEW HOÀI TOUR() NEW HOÀI ORDER() NEW HOÀI SERVICE()
//VỚI 1 BỆNH VIỆN, NEW HOÀI BỆNH NHÂN() NEW HOÀI ĐƠN THUỐC, LÂU LÂU NEW DRUG() THUỐC MỚI ĐIỀU TRỊ BỆNH

//1 OBJECT Ở TRÊN SẼ NHỈN THEO 2 KHÍA CẠNH
//1. ĐẶC ĐIỂM (TĨNH - STATE) - FIELD (1 DẠNG BIẾN LƯU INFO)
//     id, name, yob, gpa...  
//2. HÀNH VI (ĐỘNG - BEHAVIOUR) - METHOD, FUNCTION, HÀM
//     DoPresentation() 
//     ComputeBill() {voucher, * / + - sản phẩm số lượng đơn giá}

//2 THÔNG TIN TRÊN ĐC GỌI CHUNG LÀ MEMBERS OF AN OBJEECT, MEMBERS OF A CLASS

//***************
//THIẾT KẾ OOP:
//1. NHẬN DIỆN RA CÁC OBJECT, VÍ DỤ 3O BẠN QUANH TUI, VÀ 1 MÌNH TUI
//2. CHIA NHÓM OBJECT, TÌM NHÓM OBJECT - TÌM CLASS, THEO ĐẶC ĐIỂM CHUNG, THEO HÀNH ĐỘNG CHUNG
//               NHÓM STUDENT, NHÓM LECTURER
//3. TẠO DỰNG DÀN KHUNG CHO CLASS, CÁI FORM VỚI NHỮNG CHỖ TRỐNG ĐỂ ĐIỀN VÀO SAU NÀY
// Student 
//                                ID: ______________
//                              Name: ______________
//                               Yob: ______________
//                             Major: ______________
//                               Gpa: ______________
//                PlayGame() -> rank: ______________

//4. CHUẨN BỊ VIỆC NHẬN INFO VÀO, ĐIỀN INFO VÀO FORM ĐỂ CÓ ĐƯỢC OBJECT  
//   NGOÀI ĐỜI CHÍNH LÀ XIN FORM, LẤY BÚT ĐIỀN VÔ 
//   TRONG CODE, ĐIỀN FORM CHÍNH LÀ FILL VÀO CÁC FIELD TRONG CLASS
//   HÀNH ĐỘNG TRONG CODE CHÍNH LÀ HÀM - HÀM TẠO RA CÁI FORM ĐIỀN INFO ĐỂ RA OBJECT
//   HÀM NÀY GIÚP TẠO RA OBJECT - GIỐNG LẤY BÚT ĐIỀN
//                CONSTRUCT (VERB)
//   HÀM NÀY SẼ GỌI LÀ CONSTRUCTOR() GIỐNG NHƯ CÂY BÚT BẮT ĐẦU ĐIỀN FORM
//   
//5. OBJECT XONG, ĐIỀN BÚT VÀO Ô TRỐNG XONG,
//  NGÓ LẠI, XEM ỔN KO:                  -> NHÌN THẤY ĐÃ ĐIỀN GÌ, GET() 
//  CÓ SAI 1 TÍ THÌ LẤY GÔM CHỈNH SỬA    -> SỬA, ĐƯA LẠI INFO VÀO SET() THAY ĐỔI

//6. FLEX CÁI FORM CHO AI ĐÓ CẦN, FLEX HẾT MÌNH CÓ, XEM HẾT (GẦN HẾT INFO)
//   SHOWPROFILE()
//   TOSTRING()
//   
//>>>>> 6 BƯỚC TRÊN GIÚP BẠN TẠO DỰNG RA ĐC CÁCH ĐỂ LƯU TRỮ INFO CỦA CÁC OBJECT QUANH TA
//THÔNG QUA MÁY TÍNH, GIỐNG NGOÀI ĐỜI, LƯU TRỮ 1 ĐỐNG FORM ĐÃ ĐIỀN


//7. ĐÚC OBJECT TRỞ LẠI TỪ CÁI KHUÔN, CÁI FORM
//   - CLONE CÁI FORM TRƯỚC ĐÃ, ĐI PHOTO CÁI FORM, NEW CÁI FORM, MƯỢN CÁI KHUÔN
//   - ĐỔ VẬT LIỆU VÀO CÁI FORM ĐÃ NEW, ĐỔ VÀO CÁI PHỄU, ĐỔ MỰC VÀO FORM
//       GỌI HÀM CONSTRUCTOR, ĐƯA VALUE, ĐƯA VẬT LIỆU, MỰC VÀO PHỄU, KHUÔN, FORM
//   CÓ ĐC OBJECT
//   ĐẶT TÊN CHO OBJECT CHO DỄ GỌI
//   MÌNH LÀ PERSON DO BA MÁ ĐÚC RA, NEW RA, BA MÁ GỌI MÌNH LÀ TÈO TÍ

//PERSON TÈO = NEW PERSON(....);
//STUDENT TÍ = NEW STUDENT(....);

//CÓ TÈO CÓ TÍ, CÓ OBJECT GIAO TIẾP HOY QUA GET() SET() HAY FLEX PROFILE()
//TOÀN BỘ CÁC OBJECT TUÂN THEO THIẾT KẾ CỦA CLASS CÁI NHÓM MÀ OBJECT THUỘC VỀ
//TÈO. TÍ. XỔ RA CÁC HÀNH ĐỘNG THEO ĐÚNG NHÓM ĐÃ THUỘC VỀ

//TÍ. GETGPA() SV CÓ ĐIỂM, FLEX ĐIỂM...
//TÈO. SHOWPROFILE() MỖI CÁ NHÂN FLEX GÌ ĐÓ TRÊN

//LẬP TRÌNH OOP: CLONE OBJECT HÀNG LOẠT, LẬP TRÌNH TRÊN TEMPLATE CHO 1 NHÓM OBJECT




