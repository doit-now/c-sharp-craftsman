﻿using StudentManagerV3EmptyConstructor.Entities;

namespace StudentManagerV3EmptyConstructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //nếu Khuôn Class ko có phễu/constructor
            //ta vẫn luôn khuôn ra đúc, đúc đc 1 object rỗng, object chứa không khí bên trong
            //giống ta đi photo 1 cái form, chưa điền, từ từ điền vào
            //JAVA, C# CUNG CẤP CHO BẠN 1 CÁI CONSTRUCTOR, PHỄU KO LÀM GÌ CẢ, KO ĐẦU VÀO, GIÚP MÔ TẢ HÀNH ĐỘNG ĐÚC 1 OBJECT MANG GIÁ TRỊ DEFAULT, OBJECT CHỨA KO KHÍ
            //PHOTO 1 CÁI FORM TRỐNG, TỪ TỪ ĐIỀN
            //PHOTO ĐC, NEW ĐC, KO LÀM GÌ THÊM, TỪ TỪ

            //object trống trơn, giống tờ giấy form trống
            //điền từ từ sau, tương ứng hàm Set() 
            //Set() đến đâu mình xem đến đó, hàm Get()
            //object luôn đc tạo ra

            //JAVA, C# TỰ TẠO GIÙM CONSTRUCTOR RỖNG

            Student s1 = new Student(); //constructor tự sinh ra

            //VỀ NHÀ LÀM NỐT GET()/SET(), TOSTRING() SHOWPROFILE()

        }
    }
}
