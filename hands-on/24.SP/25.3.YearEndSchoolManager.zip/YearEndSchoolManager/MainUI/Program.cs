﻿namespace MainUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cabinet<Student> seBox = new Cabinet<Student>();
            seBox.Add(new Student() {Id = "SE1", ... });
            seBox.PrintList();
        }
    }
}
