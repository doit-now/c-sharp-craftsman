﻿using Repositories.Entities;
using System.Linq.Expressions;

namespace Services
{
    public class Cabinet<T> //T: type, give me a certain Type
        //i will declare the array of that type
    {
        //private Student[] _list1 = new Student[300];
        //private Lecturer[] _list2 = new Lecturer[300];
        //private int _count1 = 0; //to count Students
        //private int _count2 = 0; //to count Lecturers

        private T[] _list = new T[300];
        private int _count = 0;

        public void PrintList()
        {
            for (int i = 0; i < _count; i++)
            {
                Console.WriteLine(_list[i]);
            }
        }

        public void Add(T item)
        {
            _list[_count] = item; //item is a new Student() outside
            _count++;
        }                         //        a new Lecturer() outside
                                  //        

    }
}
