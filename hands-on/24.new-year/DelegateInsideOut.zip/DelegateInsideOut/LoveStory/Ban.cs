﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoveStory
{
    internal class Ban
    {

        public static void NhanEm() => Console.WriteLine("Chúc em hạnh phúc bên người!!!");
    }
}
