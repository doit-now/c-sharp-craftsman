﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace LoveStory
{
    internal class Tui
    {
        public void TellHer() => Console.WriteLine("Cuộc sống em ổn không. Xa anh em phải hạnh phúc!!!");
    }
}
