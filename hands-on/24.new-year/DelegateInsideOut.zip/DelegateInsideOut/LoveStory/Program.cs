﻿namespace LoveStory
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Chuyện tình 3 chàng 1 nàng...");
            KuKia.MeetSweetHeart();
        }
    }
}
