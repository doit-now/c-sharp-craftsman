namespace Giaolang.FAP.V2.StudentMgt
{
    public partial class ListStudents : Form
    {
        public ListStudents()
        {
            InitializeComponent();
        }
    }
}