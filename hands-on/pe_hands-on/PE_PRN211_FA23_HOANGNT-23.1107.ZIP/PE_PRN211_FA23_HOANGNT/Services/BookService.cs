﻿using Repositories;
using Repositories.Entities;

namespace Services
{
    /// <summary>
    /// Class này chứa các hàm cung cấp/tương tác với GUI FORMS
    /// Nó sau đó sẽ giao tiếp với Repo tương ứng để tương tác gián tiếp
    /// với CSDL
    /// Các tên hàm nghe nó "người - human-being" hơn so với repo CRUD
    /// ví dụ:                 CheckLogin()           VS.     Get()
    ///                        GetAllBooks()           VS.     GetAll() 
    /// </summary>
    public class BookService
    {
        //cần repo để CRUD XUỐNG DB
        //CẦN ĐƯA RA HÀM ĐỂ CUNG CẤP CHO FORM 
        //THẰNG ĐỨNG 2 HÀNG
        private BookRepository _repo = new BookRepository();
        //NGUYÊN LÍ SOLID, TA PHỤ THUỘC VÀO INTERFACE HƠN LÀ 1 CLASS CỤ THỂ
        //CHỖ NÀY ĐÚNG CHUẨN PHẢI KHAI BÁO: IRepository<Book> _repo
        //                                  IBookRepository _repo;
        //lát hồi new ở Constructor() 1 cái class đã implement
        //HIỆN TƯỢNG, CÁCH NÀY GỌI LÀ DEPENDENCY INJECTION

        /// <summary>
        /// Hàm lấy tất cả sách từ DB và cung cấp cho form
        /// </summary>
        /// <returns></returns>
        public List<Book> GetAllBooks()
        {
            return _repo.GetAll();
        }

        //CÒN HÀM THÊM, XOÁ, SỬA, VÀ VÀ VÀ SEARCH()

    }
}