﻿using Repositories.Entities;

namespace Services
{
    public class Cabinet<T>
    {
        private T[] _list = new T[300];
        private int _count = 0;



    }
}
