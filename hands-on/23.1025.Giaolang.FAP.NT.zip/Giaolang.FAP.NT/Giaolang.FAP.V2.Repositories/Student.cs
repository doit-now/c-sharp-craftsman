﻿namespace Giaolang.FAP.V2.Repositories
{
    public class Student
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public double Gpa { get; set; }

    }
}