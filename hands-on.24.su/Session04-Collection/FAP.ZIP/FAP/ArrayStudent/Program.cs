﻿using ArrayStudent.Entities;

namespace ArrayStudent
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PlayWithStudentArrayV5();
        }


        static void PlayWithStudentArrayV5()
        {
            Student s1 = new Student() { Id = "SE2", Name = "BÌNH" };

            //LƯU HỒ SƠ CỦA 30 SV LỚP MÌNH
            Student[] arr = new Student[30];
            //     má mì    30 biến Student a, b, c, d, e, f... khác
            //                             [0] [1] [2]...
            arr[0] = s1; //2 chàng 1 nàng
            arr[1] = new Student() { Id = "SE3", Name = "CƯỜNG" };
            arr[2] = new Student() { Id = "SE4", Name = "DŨNG" };
            arr[3] = new Student() { Id = "SE5", Name = "GIANG" };

            //em thích for hết, dù biết mảng chưa full, chứa null từa lưa cuối mảng, 26 biến Student đang = null
            //for hết là Exception
            Console.WriteLine("The student list printed by using for i");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] is not null) //if (arr[i] != null)
                    arr[i].ShowProfile(); //tầng chấm 2
            }

            Console.WriteLine("The student list printed by using for each");
            foreach (Student x in arr)
            {
                if (!(x == null))
                    x.ShowProfile(); 
            }
        }

        static void PlayWithStudentArrayV4()
        {
            Student s1 = new Student() { Id = "SE2", Name = "BÌNH" };

            //LƯU HỒ SƠ CỦA 30 SV LỚP MÌNH
            Student[] arr = new Student[30];
            //     má mì    30 biến Student a, b, c, d, e, f... khác
            //                             [0] [1] [2]...
            arr[0] = s1; //2 chàng 1 nàng
            arr[1] = new Student() { Id = "SE3", Name = "CƯỜNG" };
            arr[2] = new Student() { Id = "SE4", Name = "DŨNG" };
            arr[3] = new Student() { Id = "SE5", Name = "GIANG" };

            Console.WriteLine("The student list printed by using for i");
            //for (int i = 0; i < arr.Length; i++)  //CHẾT DO VÙNG BIẾN CÒN LẠI TRỎ NULL, TRỎ NULL .SHOWPROFILE() EXCEPTION 
            //    arr[i].ShowProfile();

            for (int i = 0; i < 4; i++)
                arr[i].ShowProfile();

            Console.WriteLine("The student list printed by using for each");
            foreach (Student x in arr)
                x.ShowProfile(); //CHẾT LUÔN SAU KHI IN 4 BẠN
            //x = arr[i] i = 0..29
            //for each LUÔN CHẠY TỪ ĐẦU MẢNG ĐẾN CUỐI MẢNG!!!
            //[4] = null
        }

        static void PlayWithStudentArrayV3()
        {
            Student s1 = new Student() { Id = "SE2", Name = "BÌNH" };

            //LƯU HỒ SƠ CỦA 30 SV LỚP MÌNH
            Student[] arr = new Student[30];
            //     má mì    30 biến Student a, b, c, d, e, f... khác
            //                             [0] [1] [2]...
            arr[0] = s1; //2 chàng 1 nàng
            arr[1] = new Student() { Id = "SE3", Name = "CƯỜNG" };
            arr[2] = new Student() { Id = "SE4", Name = "DŨNG" };
            arr[3] = new Student() { Id = "SE5", Name = "GIANG" };

            arr[4] = arr[1]; //2 chàng [4] và [1] đều trỏ CƯỜNG
            arr[4].Id = "SE333";

            arr[0].ShowProfile();  //arr[i].ShowProfile();
            arr[1].ShowProfile();
            arr[2].ShowProfile();
            arr[3].ShowProfile();
            arr[4].ShowProfile();
            //SE2 | SE333 | SE4 | SE5 | SE333 => TRƯỚC KHI CHẠY APP, RUN APP MÀ MÌNH ĐOÁN ĐC KẾT QUẢ PHẢI LÀ MẤY CỦA CÁI HÀM
            //HOẶC CÓ THỂ ĐOÁN PHẢI IN RA SE2 | SE333 | SE4 | SE5 | SE333
            //NHƯNG THỰC TẾ CHẠY CÓ THỂ KHÁC: CODE CÙI/SAI/BUG, HOẶC MÌNH ĐOÁN SAI MÀ CODE THÌ ĐÚNG

            //KĨ THUẬT KIỂM THỬ, SO SÁNH THỰC TẾ HÀM TRẢ VỀ MẤY (ACTUAL VALUE)
            //VÀ CÁI MONG ĐỢI HÀM SẼ PHẢI TRẢ VỀ LÀ MẤY (EXPECTED VALUE)
            //KĨ THUẬT, HÌNH THỨC KIỂM THỬ NÀY GỌI LÀ UNIT TESTING - SWT301

            //NGOÀI ĐỜI, KHI MÌNH CHECK ĐIỂM GHI RA GIẤY, 1 NGƯỜI ĐC GHI 2 LẦN
            //NGOÀI ĐỜI, SỐ VÉ PHIM ĐC BÁN CHO 1 PHIM, CÓ NGƯỜI XEM 2 3 LẦN
            //BÁN ĐC 5000 VÉ, KO CÓ NGHĨA 5000 NGƯỜI KHÁC NHAU XEM
            //                CÓ KHI CÓ 4980 NGƯỜI KHÁC NHAU XEM
            //                VÌ 20 NGƯỜI XEM 2 3 LẦN  

            //ARRAY LIST, MẢNG, CHO PHÉP TRỎ TRÙNG, ĐẾM TRÙNG LẠI
            //SET: CẤM TRỎ TRÙNG!!!
        }
        static void PlayWithStudentArrayV2()
        {
            //tạo một hồ sơ sv...
            Student s1 = new Student();
            s1.Id = "SE1";
            s1.Name = "AN"; //ĐANG GỌI HÀM SET(value = "AN")

            Student s2 = new Student() { Id = "SE2", Name = "BÌNH" }; //OBJECT INITIALIZER

            Student s3, s4, s5, s6, s7, s8, s9, s10; //hok ... nhen

            Student[] arr =
                            {
                                new Student() { Id = "SE3"},   //[0]  s3
                                new Student() { Id = "SE4"}    //[1]  s4
                            };

            //       má mì   
            Console.WriteLine("The student list");
            arr[0].ShowProfile();
            arr[1].ShowProfile();
        }
        static void PlayWithStudentArrayV1()
        {
            //tạo một hồ sơ sv...
            Student s1 = new Student();
            s1.Id = "SE1";
            s1.Name = "AN"; //ĐANG GỌI HÀM SET(value = "AN")

            Student s2 = new Student() { Id = "SE2", Name = "BÌNH" }; //OBJECT INITIALIZER

            Student s3, s4, s5, s6, s7, s8, s9, s10; //hok ... nhen

            Student[] arr = { s1, s2 };
            //     má mì     [0] [1]    //arr[0] = s1 = new Student(...) ở trên
            //                s3  s4      
            //arr[0] trỏ cùng = s1 = trỏ cùng SE1 AN Ở TRÊN
            Console.WriteLine("1. Check [0] pointing to SE1 | AN...");
            arr[0].ShowProfile();  //2 chàng [0] và s1 cùng trỏ SE1 AN
            arr[0].Gpa = 8.6;
            Console.WriteLine("2. Check s1 pointing to SE1 | AN | 8.6");
            s1.ShowProfile();
            //hỏi thằng s1 xem sao
            //arr.Length; 
        }
    }
}

//CHỐT HẠ:
//MẢNG OBJECT LÀ MẢNG CỦA CÁC BIẾN OBJECT, LÀ MẢNG CON TRỎ
//2 TẦNG CON TRỎ
//TẦNG #1: TÊN MẢNG - MÁ MÌ - CON TRỎ CAI QUẢN 1 ĐỐNG BIẾN KHÁC, ĐỐNG BIẾN NÀY LÀ BIẾN CON TRỎ STUDENT, LECTURER, DOG, CAT...
//TẦNG #2: TỪNG BIẾN STUDENT, TỪNG BIẾN OBJECT, NHIỀU BIẾN SÁT NHAU
//         [0]  [1] [2]
//         CHÚNG ĐANG CHỜ TRỎ VÙNG NEW STUDENT() NEW OBJECT THẬT SỰ
//TỐN 3 TẦNG RAM, 2 TẦNG TRỎ, 1 TẦNG NEW OBJECT CÓ INFO THẬT SỰ CẦN
//MẢNG OBJECT, TÊN MÁ MÌ CHẤM CX XỔ RA LENGTH
//             [I] CHÍNH LÀ BIẾN OBJECT TRỎ VÙNG NEW THẬT
//             [I] CHẤM XỔ RA HÀM OBJECT
//             [I].SHOWPROFILE()
//2 TẦNG CHẤM

//MẢNG PRIMITIVE TỐN 2 TẦNG RAM, 1 TẦNG MÁ MÌ, 1 TẦNG TOÀN VALUE THẬT 

//MẢNG PRIMITVE TÊN MÁ MÌ CHẤM XỔ RA LENGTH
//1 TẦNG CHẤM

//CHỐT HẠ QUAN TRỌNG
//CHƠI VỚI MẢNG, NẾU BIẾT MẢNG CHƯA FULL, CHƯA ĐỔ ĐẦY VALUE THÌ KO NÊN FOR HẾT
//VÌ FOR HẾT ĐẾN CUỐI, CUỐI CHƯA GÁN VALUE, ĐANG == NULL
//CHECK KHÁC NULL MỚI GỌI HÀM, CPU CHECK PHÍ, TỐN CÔNG CHECK MÀ KO IN ĐC 

//CHỈ NÊN FOR ĐẾN SỐ PHẦN TỬ ĐANG CÓ, NẾU CHƯA ĐẦY, KO PHÍ CPU CHECK NULL
//                                    NẾU ĐẦY, CHÍNH LÀ FOR HẾT

//VẬY CHỐT HẠ: CHƠI VỚI MẢNG CẦN KIỂM SOÁT MẢNG ĐẦY HAY CHƯA??? ĐỂ FOR ĐẾN CHỖ ĐANG CÓ VALUE, ĐÃ GÁN VALUE
//             CHƠI VỚI MẢNG TA CẦN THÊM 1 BIẾN COUNT
//                                       COUNT = 0 LÚC KHỞI ĐẦU
//CỨ THÊM 1 VALUE, GÁN 1 VALUE, TA VIẾT [COUNT] = VALUE;  //5 10 15, NEW STUDENT()
//                                       COUNT++;
//                                       COUNT SẼ ĐẾN LÚC == FULL == KÍCH THƯỚC MẢNG

//                           VIẾT GỘP [COUNT++] = VALUE;  //5 10 15, NEW STUDENT()

//CHƠI MẢNG CẦN 1 BIẾN PHỤ COUNT ĐỂ FOR CHO ĐÚNG 
//MẢNG CÓ 2 HẠN CHẾ:
//                   KÍCH THƯỚC CỐ ĐỊNH 
//                   DÙNG COUNT ĐỂ ĐẾM

//>>>>>>>>>>>>>>> NÂNG CẤP MẢNG THÀNH MẢNG CO GIÃN - NỒI CƠM THẠCH SANH, TÚI BA GANG
//                   MẢNG BAN ĐẦU 0 CÓ GÌ, THÊM VÀO MẢNG, NỞ RA THÊM 1 CHỖ
//                   THÊM MẢNG NỞ THÊM CHỖ... -> MẢNG LUÔN FULL VÀ NỞ RA THÊM NẾU CẦN
//                >>>> LIST, SET, MAP (JAVA) -> COLLECTIONS              
