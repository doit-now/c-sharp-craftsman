﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerV3Generic.Services
{
    public class CabinetFantasy<T>   //T: type, data type
                                     //SẼ LÀ BẤT KÌ STUDENT, LECTURER, TIGER, CÁC LOẠI DATA TYPE, CLASS KHÁC ĐƯA VÀO
                                     //CLASS, DATA TYPE ĐƯA VÀO NHƯ 1 PARAM ; GENERIC: TUI LÀM VIỆC TỔNG QUÁT CHUNG CHUGN VỚI CÁC LOẠI DATA TYPE, HÃY ĐƯA DATA TYPE VÀO KHI DÙNG TUI!!!

    //new CabinetFantasy<Student>()   new CabinetFantasy<Lecturer>()
    {
        private T[] _arr;


    }
}
