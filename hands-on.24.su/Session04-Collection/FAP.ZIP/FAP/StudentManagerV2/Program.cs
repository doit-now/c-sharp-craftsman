﻿using StudentManagerV2.Entities;
using StudentManagerV2.Services;

namespace StudentManagerV2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StudentCabinet tuSEStudent = new StudentCabinet(30);
            //ram: có 30 biến sv nằm trong mảng _arr
            tuSEStudent.AddAStudent(new Student() { Id = "SE1", Name = "AN" }); //object initializer

            Student s = new Student() { Id = "SE2", Name = "BÌNH" };


            tuSEStudent.AddAStudent(s);  //2 chàng 1 nàng

            s.Gpa = 8.6;

            tuSEStudent.PrintStudents();

            //TỦ ĐỰNG HỒ SƠ GV
            LecturerCabinet tuSELecturer = new(30);
            tuSELecturer.AddALecturer(new Lecturer() { Id = "00012345", Name = "CƯỜNG"});
            
            //tuSELecturer.AddALecturer(new Lecturer() { Id = "00012346", Name = "GIANG", Salary = 20000000 });

            //tuSELecturer.AddALecturer(new Lecturer() { Id = "00012347", Name = "HƯƠNG", Salary = 25_000_000 }); //_ PHÂN CÁCH PHẦN NGÀN TRONG CODE CHO DỄ ĐỌC CODE. JAVA Y CHANG 100%

            //SWP391: LƯU Ý IN TIỀN, NHẬP TIỀN PHẢI CÓ PHẨY HOẶC CHẤM PHÂN CÁCH PHẦN NGÀN TUỲ THEO TIẾNG ANH HAY TIẾNG VIỆT 600.000đ

            tuSELecturer.PrintLecturers();


        }
    }
}


//BÀN VỀ SỰ LINH HOẠT TRONG VIẾT CODE - ĐA MỤC ĐÍCH TRONG VIẾT CODE!!!
//THAM SỐ CỦA HÀM - PARAMETER NGHĨA LÀ GÌ???
//PARAMETER LÀ ĐẠI DIỆN CHO CHO 1 ĐÁM VALUE NÀO ĐÓ
//             ĐC TRUYỀN VÀO TRONG HÀM. HÀM NHẬN THAM SỐ NGHĨA LÀ HÀM CÓ THỂ NHẬN ĐA DẠNG VALUE KHÁC NHAU
//             (int x) //đa dạng value x
//             (double y)  //đa dạng value y: 3.14, 10%, 9.8...
//             (string s)  //đa dạng chuỗi, câu chữ đưa vào!!!


//HÀM: LÀ 1 ĐOẠN CODE XỬ LÍ THÔNG TIN, ĐOẠN CODE NÀY ĐC ĐẶT 1 CÁI TÊN GỌI..

//void F1() {...}  //code bên trong hàm sẽ xử lí data sẵn có trong hàm
//                 //chưa linh hoạt lắm; phải có data sẵn trong hàm

//void F2(int x) {...} 
//hàm linh hoạt, vì data đc đưa vào qua x. x lúc này có thể là bất kì con số int nào đó, 5 10 15 20 25...
//x đc gọi là tham số đầu vào cho hàm!!!
//nó đại diện cho 1 value nào đó đc đưa vào hàm, giúp hàm có thể linh hoạt xử lí đc NHIỀU VALUE KHÁC NHAU TUỲ NHU CẦU GỌI HÀM

//LINH HOẠT NHƯNG VẪN CÒN HẠN CHẾ
//void F1(int x)  //linh hoạt data/value đưa vào x = 5 10 15 20...
//void F2(double y) //linh hoạt các con số thực đưa vào y = 3.14, 9.8
//void F3(string msg) //linh hoạt với các chuỗi kí tự đưa vào, msg = Ngọc Trinh, Phương Trinh, Midu

//NHƯNG VẪN CHƯA LINH HOẠT ĐẾN ĐỈNH CAO!!!
//VÌ void F1(int x) chỉ linh hoạt với value đưa vào, nhưng chính nó fixed chỉ chơi với int

//void F2(double y) linh hoạt với các value của double, nhưng chỉ chơi với double mà thoy

//LINH HOẠT ĐỈNH CAO - ƯỚC MƠ
//void FFantasy(??? x)  //linh hoạt cả với data type luôn
//                      //MUỐN HÀM CHƠI VỚI INT, THÌ ĐƯA INT VÀO ???
//                      //MUỐN HÀM CHƠI VỚI STRING, THÌ ĐƯA STRING VÀO ???
//                      //                  DOUBLE

//HÀM 2 MỨC LINH HOẠT, 2 TẦNG LINH HOẠT, 2 TẦNG THAM SỐ
//LEVEL 1 - THAM SỐ 1 (MỚI BIẾT): BẠN MUỐN CHƠI VỚI DATA TYPE NÀO, CHỌN ĐI, ĐƯA CHO HÀM
//   FFantasy(string x)
//   FFantasy(double x)
//   FFantasy(int x)
//   LẦN ĐẦU TIÊN TRÁI THANH LONG CÓ TRONG MÌ TÔM
//   LẦN ĐẦU TIÊN, DATA TYPE INT LONG, FLOAT, DOUBLE, STUDENT, LECTURER..
//   ĐC ĐƯA VÀO 1 HÀM, 1 CLASS, ĐC XEM LÀ THAM SỐ!!!

//LEVEL 2 - TRUYỀN THỐNG: DATA, VALUE CỦA DATA TYPE ĐÓ LÀ GÌ???

// FFantasy(string x)  //x = NGỌC TRINH, PHƯƠNG TRINH, MIDU...
// FFantasy(int x)  //x = 5 10 15 20 25

//LINH HOẠT DATA TYPE VÀ LINH HOẠT VỚI VALUE CỦA DATA TYPE ĐÓ
//-------------------    ------------------------------------
//                           QUEN TỪ C, JAVA KHI VIẾT HÀM CÓ THAM SỐ
//MỚI CÓ SAU NÀY CỦA OOP
//JAVA, C# GIỐNG 100% CHỖ NÀY

//HÀM MÀ CHƠI LINH HOẠT 2 LEVEL LÀ: XÁC ĐỊNH DATA TYPE MUỐN CHƠI, SAU ĐÓ MỚI XÁC ĐỊNH VALUE CỦA DATA TYPE ĐÓ

//KĨ THUẬT MÀ HÀM, CLASS CHƠI VỚI ĐA DẠNG DATA TYPE (MỚI) THÌ ĐC GỌI LÀ KĨ THUẬT GENERIC - CHƠI TỔNG QUÁT, CHUNG CHUNG VỚI CÁC DATA TYPE
//DÙNG KÍ HIỆU <DATA TYPE>  <T> ĐỂ NÓI RẰNG HÀM, CLASS CHƠI VỚI ĐA ĐẠNG DATA TYPE, XỬ LÍ CHUNG CHUNG TRÊN DATA TYPE
//
//LẦN ĐẦU TIÊN, XÀI HÀM MÀ KO ĐƯA VALUE VỘI, MÀ PHẢI ĐƯA, PASS DATA TYPE VÀO TRƯỚC CÁI ĐÃ

//GỌI HÀM, GỌI CLASS MÀ PHẢI XĐ NGAY TRƯỚC TIÊN, TỚ CHƠI VỚI DATA TYPE NÀO ĐÃ

//TRUYỀN DATA TYPE NHƯ LÀ 1 THAM SỐ - GENERIC <>

//QUEN: List<Stuent>
//      ArrayList<Lecturer>  BÊN JAVA
//BÊN C# Y CHANG!!!!

//QUAY LẠI BÀI CABINET
//CHƠI GENERIC, CABINET CHƠI VỚI ĐỦ DẠNG MẢNG KHÁC NHAU BÊN TRONG NÓ!!!

//CÓ: CABINET<STUDENT>
//    CABINET<LECTURER>
//    CABINET<TIGER>

