﻿using StudentManagerV2.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagerV2.Services
{
    public class StudentCabinet
    {

        private Student[] _arr;  // = new Student[30];
        //đằnng nào cx phải new, từ từ new, đóng cái tủ theo nhu cầu của mỗi nhà
        private int _count = 0; //tủ ban đầu chưa có món đồ, mảng chưa có value cho các biến, cho các phần tử, ở đây chính là [i] = new Student() sẽ là 1 value cho phần tử/biến thứ [i] của mảng

        //tủ độ đóng theo yêu cầu gia chủ, số ngăn tuỳ chọn
        //public StudentCabinet(int size)
        //{
        //    _arr = new Student[size];
        //}
        public StudentCabinet(int size) => _arr = new Student[size];

        //CÁC HÀM CRUD, CHO TỪNG MÓN ĐỒ TRONG TỦ, TỪNG BIẾN THỨ [I]
        //XỬ LÍ INFO, XỬ LÝ CÁC OBJECT TỪ ENTITY STUDENT

        public void PrintStudents()
        {
            if (_count <= 0)
            {
                Console.WriteLine("The cabinet is empty. Nothing to print");
                return; //thoát hàm luôn 
            }

            //ko in đến hết mảng, nhớ hok, coi chừng null reference exception, chỉ for đến count, hoặc for hết thì phải check null
            Console.WriteLine($"There is/are {_count} student(s) in the cabinet");
            for (int i = 0; i < _count; i++)
                _arr[i].ShowProfile();
        }

        public void AddAStudent(Student x) => _arr[_count++] = x;  //_arr[_count] = x; _count++;

    }
}
