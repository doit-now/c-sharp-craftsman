﻿using StudentManager.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManager.Services
{
    public class Cabinet
    {
        //đặc tính của cái Tủ sẽ là: sức chứa, chứa loại hồ sơ, đồ vật nào đó, object nào đó, mà là nhiều object. Lập trình: chứa nhiều là KHAI BÁO MẢNG. MẢNG NHỚ ĐI KÈM BIẾN COUNT ĐỂ KIỂM SOÁT SỐ PHẦN TỬ MẢNG

        //HÀNH ĐỘNG CỦA CÁI TỦ: CRUD - CREATE | RETRIEVE/READ | UPDATE | DELETE
        private Student[] _arr = new Student[30];
        private int _count = 0; 

        public Cabinet(int size)  //TỦ ĐÓNG THEO YÊU CẦU
        { 
            _arr = new Student[size];
        }
        public Cabinet() //HÀNG SX HÀNG LOẠT, 30 CHỖ 
        {            
        }

        //GET() SET() VIẾT THẾ NÀO??? CÓ LÀ GET() SET() STYLE MỚI ĐÃ HỌC HAY KO
        //KO LÀM GET() SET() KIỂU MỚI, TRUYỀN THỐNG CX KO LUÔN 
        //auto-implemented, fullprop
        //NẾU LÀM GET() GET _ARR, THÌ TRẢ VỀ NGUYÊN MẢNG, 30 BIẾN STUDENT TRỎ VÀO 30 VÙNG NEW STUDENT(), KO CÓ XỬ LÍ GÌ THÊM, DATA THÔ ĐƯA RA > THIẾU Ý NGHĨA VIỆC XỬ LÍ HƯỚNG USER -> GET KO CẦN (CHỨ KO PHẢI LÀ KO ĐC LÀM HÀM GET()
        //NẾU LÀM SET() THÌ SAO; SET 1 MẢNG = MẢNG KHÁC, _ARR = MẢNG KHÁC
        //PHÍ CÔNG NEW Ở TRÊN
        //NGOÀI ĐỜI: CHỜ ĐỦ NHIỀU OBJECT MỚI ĐƯA VÀO MẢNG, CHỜ ĐỦ NHIỀU ĐỒ MỚI BỎ VÀO TỦ -> SAI SAI, KO HIỆU QUẢ, KO PHẢI KO ĐC
        //HÀM SET() KO HAY, KO PHẢI KO ĐC 
        //MÀ CÁI MẢNG _ARR NÊN CÓ ĐC HỒ SƠ NÀO, THÌ ADD VÀO MẢNG, ADD VÀO TỦ NGAY CÁI ĐÓ, HÀM ADD() CREATE() 1 MÓN XUẤT HIỆN

        //NGOÀI ĐỜI: ĐÂU CẦN CHỜ ĐỦ NHIỀU ĐƠN HÀNG ĐẾN, NHIỀU K/H GỌI MỚI XỬ LÍ ĐƠN, MỚI TẠO ĐƠN, MÀ LÀ AI ĐẾN PHỤC VỤ LUÔN, CREATE TỪNG CÁI
        //NGOÀI ĐỜI: KO CHỜ 10 XE VÀO 1 LƯỢT, NHƯNG ĐC QUYỀN LÀM
        //TRONG APP: TẠO MỚI TỪNG ĐƠN HÀNG, TỪNG GIỎ HÀNG, MÓN HÀNG TRONG GIỎ
        //           ÀO ẠT 1 LƯỢT: GOM HẾT TRÊN TAY, ỤP VÀO CÁI XE ĐẨY
        //           IMPORT DANH SÁCH SINH VIÊN TỪ BÊN TUYỂN SINH
        //           IMPORT DANH SÁCH K/H TỪ BÊN SALES, TỪ BÊN PHẦN MỀM CŨ ĐEM SANG 

        //GET COUNT() CÓ VẺ OKIE, THỐNG KÊ SỐ LƯỢNG HỢP LÍ: NÓI RẰNG ĐẦY CHƯA???
        //SET COUNT() CÓ VẺ OKIE HEM??? KO HỢP LÍ, VÌ NÓ PHẢI PHẢN ÁNH SỐ VALUE ĐC GÁN VÀO MẢNG, ++ CÓ LÍ DO, GÁN LUNG TUNG, MẢNG LỦNG VALUE À???
        //KO PHẢN ÁNH ĐÚNG SỐ PHẦN TỬ MẢNG ĐÃ GÁN

        //CÁC HÀM XỬ LÍ DATA: CRUD TRÊN MẢNG, THEO TỪNG MÓN 1 MỚI HỢP LÍ
        //KO GET() SET() TRÊN MẢNG
        public void PrintStudentList()
        {
            //for hết hay for count, for hết phải kiểm tra null. ArrayList khỏi lo
            Console.WriteLine($"There is/are {_count} student(s) in the cabinet");
            for (int i = 0; i < _count; i++)
            {
                _arr[i].ShowProfile();
            }
        }

        public void AddAStudent()
        {
            //phải có lệnh nhập id, name, yob, gpa của từng sinh viên ở đây!!!
            //arr[_count] = new Student() {...};
            //    _count++

            //lệnh nhập data phụ thuộc vào UI: console, web, form (màn hình trên desktop - học sau), mobile
        }

        public void AddAStudent(string id, string name, int yob, double gpa)
        {
            //phải có lệnh nhập id, name, yob, gpa của từng sinh viên ở đây!!!
            //arr[_count] = new Student() {...};
            //    _count++

            //lệnh nhập data phụ thuộc vào UI: console, web, form (màn hình trên desktop - học sau), mobile
        }

        public void AddAStudent(Student s)
        {
            //phải có lệnh nhập id, name, yob, gpa của từng sinh viên ở đây!!!
            //arr[_count] = s;
            //    _count++;

            //lệnh nhập data phụ thuộc vào UI: console, web, form (màn hình trên desktop - học sau), mobile
            if (_count < 30)  //kiểm tra full
                _arr[_count++] = s;

            //_count++;
        }

        //CÁC HÀM TRÙNG TÊN TRONG 1 CLASS, NHƯNG KHÁC THAM SỐ => OVERLOAD, OVERLOADING
        //OVERLOAD LÀ 1 THỂ HIỆN CỦA NGUYÊN LÍ ĐA HÌNH - POLYMORPHISM
        //TỪ 1 HÀM, ÁNH XẠ NHIỀU CÁCH CÀI CODE - IMPLEMENT

        //OVERRIDE MỚI ĐÃ HƠN, CHA GỌI HÀM, CÁC CON HƯỞNG ỨNG!!!
    }

}
