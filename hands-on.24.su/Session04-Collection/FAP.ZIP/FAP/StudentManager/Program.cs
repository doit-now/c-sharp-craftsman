﻿using StudentManager.Entities;
using StudentManager.Services;

namespace StudentManager
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //ĐI MUA TỦ, MUA 2 CÁI CHO MÁU
            Cabinet tuSE = new Cabinet();  //phòng có 30 chỗ, tủ có 30 slot trống, count = 0
            Cabinet tuBiz  = new Cabinet(); //30 chỗ 
            tuBiz.AddAStudent(new Student() { Id = "SS01", Name = "AN" });
            tuBiz.AddAStudent(new Student() { Id = "SS02", Name = "BÌNH" });

            tuSE.AddAStudent(new Student() { Id = "SE01", Name = "AN" });
            tuSE.AddAStudent(new Student() { Id = "SE02", Name = "BÌNH" });
            tuSE.AddAStudent(new Student() { Id = "SE10", Name = "CƯỜNG" });

            tuSE.PrintStudentList();
            tuBiz.PrintStudentList();
                

        }
    }
}

//BÀI TẬP VỀ NHÀ:
//1. HOÀN THIỆN NỐT BÀI QUẢN LÍ SINH VIÊN
//   - IN RA MENU 
//         1. ADD STUDENT - NHẬP TỪ BÀN PHÍM
//         2. PRINT STUDENTS - SORT THEO TĂNG DẦN VỀ ĐIỂM
//         3. PRINT STUDENTS - SORT THEO TĂNG DẦN VỀ TÊN
//         4. XOÁ, SỬA, SEARCH, KO ÉP PHẢI LÀM  ĐIỂM++
//         5. QUIT!

//1.ADD STUDENT - NHẬP TỪ BÀN PHÍM: CONSOLE.READLINE() -> TRẢ VỀ CHUỖI
//-> CẦN SỐ THÌ PHẢI CONVERT, INTERGER.PARSEINT() 
//-> BÊN NÀY TƯƠNG TỰ, CHATGPT

//SORT VÀ IN RA: VÔ SỐ TIÊU CHÍ SORT KHÁC NHAU
//          TÊN, NĂM SINH, ĐIỂM, CÙNG TÊN ĐIỂM GIẢM DẦN, GOM NHÓM THEO TỈNH...
//          AI VIẾT DỞ/NEWBIE: MỖI TIÊU CHÍ SORT LÀ 1 HÀM
//          MAI MỐT THÊM KIỂU SORT KHÁC LÀ PHẢI SỬA CODE
//          VIẾT NGON: CHỈ 1 HÀM SORT, MÀ TIÊN ĐOÁN ĐC TƯƠNG LAI, KO SỬA CODE MỚI
//          NGON, KĨ THUẬT DEPENDENCY INJECTION (DI)
//              > YOUTUBE GIÁO.LÀNG, MÔN SOFTWARE TESTING CÓ DI CODE DEMO, CỰC ĐÃ
//              > DÙNG LAMBDA EXPRESSION 

//2. LÀM CLASS LECTURER, TỦ ĐỰNG HỒ SƠ GIẢNG VIÊN: ADD() PRINT()
//THÔNG TIN GIẢNG VIÊN GỒM: ID, NAME, YOB, SALARY

//CHUẨN BỊ CHO BÀI GENERIC <>  List<Student>
//NỘP BÀI LÊN LMS
//Y CHANG NỘP BÀI THI PE
//GIẢM KÍCH THƯỚC THƯ MỤC SOLUTION (VÌ CHỨA LIBRARY - DEPENDENCY TẢI MẠNG VỀ)
//MENU BUILD | CLEAN SOLUTION > NHỎ NGAY > NÉN .ZIP .RAR UPLOAD 
