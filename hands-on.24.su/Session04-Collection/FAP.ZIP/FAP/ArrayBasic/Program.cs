﻿namespace ArrayBasic
{
    internal class Program
    {
        //public string Id { get; }


        static void Main(string[] args)
        {
            PlayWithIntegerListV6();
        }

        static void PlayWithIntegerListV6()
        {
            int a = 10;
            int b = a; //primitive, value-type; b có value của a

            //mảng chơi trò gán bằng thì ra sao
            int[] arr1 = { 5, 10, 15, 20, 25 };  //new ngầm int[4] xin 4 biến int

            int[] arr2 = { 2, 4, 6, 8, 1, 3, 5, 7 };  //new ngầm int[4] xin 4 biến int

            //in thử arr2 trước
            Console.WriteLine("arr2 at first...");
            foreach (int x in arr2)
                Console.Write(x + " ");

            Console.WriteLine();

            arr2 = arr1;  //2 chàng 1 nàng
            arr1[0] = 999;

            Console.WriteLine("arr2 after assigning to the...");
            foreach (int x in arr2)
                Console.Write(x + " ");

            Console.WriteLine();

            arr2[1] = 662024;

            Console.WriteLine("check arr1 again after modifying by arr2...");
            foreach (int x in arr1)
                Console.Write(x + " ");  //999 662024 15 20 25

            Console.WriteLine();

        }

        static void PlayWithIntegerListV5()
        {
            int[] arr = new int[10];  //10 element, 10 phần tử, 10 biến int lẻ nay đc gom chung trong tên arr. arr là biến má mì quản lí 10 biến con kiểu int arr[0] arr[1], ....
            //                         int   a   ,   b  , .... 
            //có 11 biến: 1 má mì + 10 biến con/lẻ truyền thống
            arr[0] = 5;
            arr[1] = 10;
            arr[2] = 15;
            arr[3] = 20;
            //gán trước 4 giá trị cho 4 biến đầu, hỏi rằng 6 biến còn lại là mấy???
            //VÙNG 6 BIẾN INT CÒN LẠI SẼ MANG DEFAULT - OBJECT LÀ VẬY, KO ĐIỀN ĐỦ INFO LÀ MANG DEFAULT
            //số -> default 0 | boolean -> default false
            //object -> default là null, trỏ đáy ram
            Console.WriteLine("The list of numbers (printed by using for i...)");
            //for (int i = 0; i < arr.Length; i++)
            for (int i = 0; i < 4; i++)
                Console.Write(arr[i] + " ");

            Console.WriteLine(@"
The list of numbers (printed by using for i...)");  //verbatim string

            foreach (int x in arr)  //toán tử với mọi x thuộc tập arr - là 1 đống biến int [i]
                //x có quyền bằng từng con số trong mảng, = phần tử thứ [i]
            {
                Console.Write($"{x} ");
            }
            Console.WriteLine();  //sống có trách nhiệm
        }


            //TOÁN TỬ VỚI MỌI TRONG TẬP HỢP, CHỮ A NGƯỢC TRONG TOÁN HỌC
            static void PlayWithIntegerListV4()
        {
            int[] arr = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 35, 35 }; //NEW NGẦM new int[10]

            Console.WriteLine("The list of 5..10 (printed by using for each)");

            foreach (int x in arr)
            {   //với x rơi vào in tập arr, thì x có thể = arr[0], x = arr[1], x = arr[i] - toán tử với mọi trong tập hợp toán học
                //chơi với x chính là chơi với arr[i]
                Console.Write($"{x} ");  //chính là chơi từng arr[i]
                //với mọi x sẽ quét qua hết từng phần tử trong mảng, để lấy value
            }
            Console.WriteLine(); //sống có trách nhiệm, xuống hàng sau in

            foreach (var x in arr)
            {   //với x rơi vào in tập arr, thì x có thể = arr[0], x = arr[1], x = arr[i] - toán tử với mọi trong tập hợp toán học
                //chơi với x chính là chơi với arr[i]
                Console.Write($"{x} ");  //chính là chơi từng arr[i]
                //với mọi x sẽ quét qua hết từng phần tử trong mảng, để lấy value
            }

            Console.WriteLine(); //sống có trách nhiệm, xuống hàng sau in
            //SQL NÓI CHUNG CÓ LỆNH KIỂU NÀY
            //SELECT * FROM STUDENT WHERE PROVINCE IN (N"BÌNH DƯƠNG", N"ĐỒNG NAI", N"TÂY NINH")

            //FORE TAB 
            //FORE TAB TAB ĐỂ GỢI Ý CÚ PHÁP IN MẢNG DÙNG TOÁN TỬ VỚI MỌI

        }

        static void PlayWithIntegerListV3()
        {
            int[] arr = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 35, 35 }; //NEW NGẦM new int[10]
            //  má mì    [0] [1] [2]
            //in mảng, in từng biến 1
            Console.WriteLine("The list of 5..10...");

            Console.WriteLine($"{arr[0]} {arr[1]} {arr[2]} {arr[3]} {arr[4]} {arr[5]} {arr[6]} {arr[7]} {arr[8]} {arr[9]}");
            //XÀI LỐ PHẦN TỬ, APP BỊ GIẾT NGAY - OUT OF RANGE EXCEPTION

            Console.WriteLine("The list of 5..10 using for i:");
            //for (int i = 0; i < 11; i++)
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write($"{arr[i]} ");
                //                  vào phần tử thứ i, biến thứ i, lấy value, in
                //                  biến đi kèm value, tên biến phức tạp hơn 1 tí
            }
            //SỐNG CÓ TRÁCH NHIÊM, IN XONG PHẢI XUỐNG HÀNG
            Console.WriteLine();

            //tính tổng
            int sum = 0;
            Console.WriteLine("The sum of list of 5..10 using for i:");
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }
            Console.WriteLine("SUM: " + sum);

            //

        }

        static void PlayWithIntegerListV2()
        {
            //KHAI BÁO SỈ CÁC BIẾN: KHAI BÁO NHIỀU BIẾN, NHƯNG NHANH VÀ HIỆU QUẢ
            //MẢNG LÀ KĨ THUẬT KHAI BÁO BIẾN, NHIỀU BIẾN 1 CÁCH HIỆU QUẢ
            //MẢNG LÀ KĨ THUẬT KHAI BÁO NHIỀU BIẾN CÙNG LÚC, CÙNG KIỂU, CÙNG TÊN, VÀ Ở SÁT NHAU TRONG RAM - Y CHANG DÃY NHÀ LIÊN KẾ, Y CHANG 1 TẦNG CHUNG CƯ 

            //int a = 5, b = 10, c = 15, d = 20, e = 25, f = 30, g = 35, h = 40, i = 45, j = 50;  khai báo lẻ hoy
            int[] arr; //arr ko phải là 1 biến int, vì có dấu []
                       //         //arr là 1 biến, ko phải biến int, mà là biến, mà là tên gọi, mà là tên biến ĐẠI DIỆN CHO NHIỀU BIẾN INT KHÁC
                       //TỨC LÀ BIẾN ARR KO MANG GIÁ TRỊ 5 10 15 20; MÀ NÓ LÀ TÊN GỌI CHUNG
                       //CHO NHIỀU BIẾN INT KHÁC MÀ NÓ NẮM GIỮ, QUẢN LÍ
                       //ARR: TUI GỌI LÀ BIẾN MÁ MÌ (TÚ ÔNG TÚ BÀ)
                       //HỎI ARR: ÔNG CÓ GÌ, BÀ CÓ GÌ, TUI CÓ NHIỀU KẺ DƯỚI TAY, DƯỚI TRƯỚNG
                       //NGHE MÙI BANG HỘI, NHIỀU KẺ CÙNG STYLE - MẢNG LÀ NHIỀU BIẾN CÙNG KIỂU
                       //int[] arr = 10;  //GẪY VÌ ARR LÀ ÁM CHỈ NHIỀU BIẾN INT; CẦN THÊM NHIỀU VALUE; VÌ KO LÀ BIẾN ĐƠN 

            int[] arr1 = { 1 };
            int[] arr2 = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
            //new ngầm; hậu trường lúc runtime là new int[10] 


            //vietsub: arr2 đại diện cho 10 biến int khác
            //             5 là giá trị của biến int đầu tiên trong 10 biến int
            //             10 là giá trị của biến int thứ 2 trong 10 biến
            //             ...
            //MỖI BIẾN TRONG MẢNG THÌ GỌI LÀ 1 PHẦN TỬ CUẢ MẢNG
            //CÒN GỌI LÀ ELEMENT OF AN ARRAY
            int[] arr3 = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
 
            int[] arr4 = new int[10] { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
            //Student s = new Student(...) {...};

            int s = 2024;

            int[] arr5 = new int[] { s, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
            //                     arr[0] = s = 2024;
            int[] arr6;
            arr6 = new int[10];
            arr6[0] = 5;
            arr6[1] = 10;
            arr6[2] = 15;
            //...

            int[] arr7 = new int[10];
            arr7[0] = 5;
            arr7[1] = 10;
            arr7[2] = 15;
            //...

            //TỔNG QUÁT: CÓ 2 CÁCH KHAI BÁO MẢNG - KHAI BÁO NHIỀU BIẾN

            //VỪA KHAI BÁO VỪA GÁN VALUE CHO TỪNG BIẾN/TỪNG PHẦN TỬ
            //KHAI BÁO MẢNG 1 CÂU LỆNH, SAU ĐÓ GÁN VALUE CHO TỪNG PHẦN TỬ
            //CÁCH NÀY GÕ TỪNG BIẾN 1 HƠI MẤT SỨC 1 TÍ

            //NEW INT[???]: CHÍNH LÀ XIN VÙNG NEW BỰ ĐỂ CHỨA BIẾN KHÁC/ELEMENT
            //NEW CÓ THỂ NGẦM KO CẦN GÕ RA NẾU CHƠI TRÒ VỪA KHAI BÁO MẢNG
            //VỪA GÁN VALUE

            //VẬY NÊN KHAI BÁO MẢNG THEO STYLE NÀO? 
            //THỰC TẾ: STYLE 2, LÍ DO TA ĐÂU BIẾT TRƯỚC HẾT VALUE!!
            //LƯỢNG MƯA TRONG NĂM CHƯA BIẾT HẾT, SAO GÁN VALUE NGAY LÚC KHAI BÁO MẢNG

            int[] arr8 = { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
            int[] arr9 = new int[] { 5, 10, 15, 20, 25, 30, 35, 40, 45, 50 };
            //   MÁ MÌ QUẢN LÍ 10 BIẾN INT DƯỚI TRƯỚNG
            //                      [0] [1] [2] [3] [4]
            //                   arr[0]
            //                ~ int a
            //                       arr[1]
            //                       int b

            //[] BIỂU DIỄN TÊN PHỤ, KHI CÁC BIẾN XÀI CHUNG TÊN ARR
            //ARR -> MÁ MÌ QUẢN LÍ 10 ĐỨA CÙNG TÊN ARR PHÂN BIỆT BẰNG TÊN PHỤ
            //       ARR[0]  ARR[1]  ARR[2]  ARR[3]  ...... ARR[9] LÀ BIẾN INT
            //                          DƯỚI TRƯỚNG
            //ARR KO NGOẶC VUÔNG: MÁ MÌ
            //ARR[] NHỮNG ĐỨA DƯỚI BÀN TAY MÁ MÌ => ĐỨA/BIẾN LƯU VALUE THỰC SỰ
            //ARR[0] LÀ CÓ VALUE 5
            //ARR[1] LÀ CÓ VALUE 10
            // 
            //[0...TỐI ĐA - 1]   [0...9] NẾU MẢNG 10 PHẦN TỬ
            //0 -> 9 GỌI LÀ CHỈ SỐ PHẦN TỬ CỦA MẢNG, BIẾN THỨ 0..9
            //INDEX    I 
            //KHI CHƠI VỚI MẢNG, INDEX I CHẠY TỪ 0...9 THÌ TA SẼ DÙNG VÒNG LẶP
            //CHƠI VỚI LẶP FOR I [0...9]
            //TA SỜ ĐC CÁC BIẾN KO MẤT SỨC, 2 DÒNG LỆNH: FOR
            //                                              ARR[I] LÀ XONG 
            //MẢNG 5000, 30000, 100000 PHẦN TỬ, 2 DÒNG LỆNH MÀ THOY
            //ƯU ĐIỂM: DÙNG ÍT LỆNH MÀ QUÉT ĐC HẾT BIẾN
            //NHƯỢC: TÊN BIẾN PHỨC TẠP 1 XÍU, THÊM [I]







        }

        //CHALLENGE 1: HÃY LƯU TRỮ VÀ IN RA DÃY SỐ 5 10 15 20 25 30 35 40 45 50
        //CHALLENGE 2: HÃY LƯU TRỮ LƯỢNG MƯA TỪNG NGÀY CỦA TỪNG NĂM
        //             QUY MÔ DATA: 365 x SỐ NĂM 
        //mục tiêu 2 challenge: LƯU TRỮ NHIỀU DATA, CHƯA BÀN XỬ LÍ

        //LƯU DỮ LIỆU TRONG RAM: BIẾN
        //LƯU TRỮ DỮ LIỆU LÂU DÀI: THIẾT BỊ LƯU TRỮ HDD/SSD
        //                         CÂY THƯ MỤC, DATABASE
        //CẦN NHIỀU BIẾN THÌ LƯU ĐC NHIỀU VALUE

        //VÌ TẠI 1 THỜI ĐIỂM, 1 BIẾN LƯU 1 VALUE

        static void PlayWithIntegerListV1()
        {
            //HÃY LƯU TRỮ VÀ IN RA DÃY SỐ 5 10 15 20 25 30 35 40 45 50
            //KĨ THUẬT TRÂU BÒ - DÙNG SỨC - KHAI BÁO LẺ TỪNG BIẾN

            //int a, b, c, d, e;  //f, g, h, i, j;
            //int f, g, h, i, j;

            //a = 5; b = 10; c = 15; d = 20; e = 25; f = 30; g = 35; h = 40; i = 45; j = 50;

            //well-formed format
            int a = 5, b = 10, c = 15, d = 20, e = 25, f = 30, g = 35, h = 40, i = 45, j = 50;

            //in kết quả - thấy tía má: HỘC MÁU GÕ TÊN TỪNG BIẾN
            Console.WriteLine("The list of 5 10 15...");
            Console.WriteLine($"{a} {b} {c} {d} {e} {f} {g} {h} {i} {j}");


            //CÁCH NÀY GỌI LÀ: KHAI BÁO LẺ, KHAI BÁO RỜI RẠC TỪNG BIẾN
            //CÁCH NÀY DỄ LÀM DỄ HIỂU
            //NHƯNG KO HIỆU QUẢ, MẤT SỨC NẾU CÓ NHIỀU BIẾN

            //CẦN LƯU TRỮ BAO NHIÊU VALUE, TA CẦN BẤY NHIÊU BIẾN!!!!!!!!!!!

            //TÍNH TOÁN, XỬ LÍ: TÍNH TỔNG CỦA CHÚNG
            int sum = a + b + c + d + e + f + g + h + i + j;

            //HÃY TÍNH LƯỢNG MƯA CẢ NĂM - TỰ TAY GÕ 365 BIẾN
            Console.WriteLine("Sum 5 10...: " + sum);
        }

    }
}

//CHỐT HẠ: MẢNG LÀ KHAI BÁO NHIỀU BIẾN CÙNG LÚC CÙNG KIỂU CÙNG TÊN, Ở SÁT NHAU TRONG RAM
//VẬY THÌ GÁN GIÁ TRỊ CHO NHIỀU BIẾN THÌ SẼ LÀ LÔI TỪNG BIẾN THỨ [I] RA = VALUE;
//THƯỜNG MẢNG SẼ LUÔN CHƯA ĐẦY, MỌI BIẾN SẼ CHƯA ĐC GÁN VALUE 
//EX. LƯỢNG MƯA TỪNG NGÀY TRONG NĂM -> MẢNG 365 BIẾN DOUBLE
//    TẠI LÚC NÀY - 6/2024 MẢNG MỚI ĐẦY 1/2
//FOR HẾT NĂM LÀ KO CẦN THIẾT, DO 1/2 NĂM CÒN LẠI LÀ 0 - DEFAULT, ĐÃ SANG NGÀY MỚI ĐÂU MÀ ĐO MƯA!!!

//* CHƠI VỚI MẢNG TA HAY - LUÔN FOR ĐẾN COUNT - COUNT LÀ 1 BIẾN ĐẾM DÙNG LƯU SỐ LƯỢNG BIẾN ĐANG CÓ VALUE!!!!
//COUNT = 4, MẢNG CÓ 10 BIẾN, BIẾT NGAY CÒN 6 BIẾN SẼ CẦN GÁN VALUE!!!
//FOR ĐẾN 4 TRONG BÀI NÀY, FOR ĐẾN COUNT ĐẢM BẢO IN VALUE CÓ NGHĨA, CÒN LẠI DEFAULT KO CARE!!!

//CHỐT HẠ: GÁN MẢNG CHO MẢNG, MÁ MÌ = MÁ MÌ KHÁC, 2 CHÀNG 1 NÀNG
//2 MÁ MÌ CÙNG QUẢN 1 ĐÁM!!!!!!!!!!!!!!!!
//