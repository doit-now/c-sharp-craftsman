﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //CODE CHUẨN CHỖ NÀY SẼ LÀ KHAI BÁO BIẾN INTERFACE = NEW IMPLEMENT
        //DEPENDENCY INJECTION
        private AirConService _service = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            DetailWindow d = new();
            //d.Show();
            d.ShowDialog();
            //F5 LẠI GRID KHI ĐÓNG MÀN HÌNH
            //TODO: ĐÚNG CHUẨN PHẢI KIỂM TRA NẾU CÓ TẠO MỚI, NHẤN NÚT SAVE THÌ MỚI F5
            FillDataGrid();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillDataGrid();
        }

        //hàm helper, trợ giúp cho hàm khác
        private void FillDataGrid()
        {
            AirConsDataGrid.ItemsSource = null; //xoá grid
            AirConsDataGrid.ItemsSource = _service.GetAllAirCons();
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            //AirConsDataGrid.SelectedItem //biến object - nhưng đang là Máy lạnh đc lựa chọn -> casting, ép kiểu 
            //AirConditioner? selected = (AirConditioner)AirConsDataGrid.SelectedItem;

            AirConditioner? selected = AirConsDataGrid.SelectedItem as AirConditioner;
            if (selected == null)
            {  //user ko chọn dòng nào mà lại nhấn nút edit, chửi
                MessageBox.Show("Please select a row/ an air con before editing", "Select a row", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }
            //chạy đến đây là đã chọn dòng, ta đẩy nó sang màn hình Detail - EditedAir đc gán value bên này

            DetailWindow d = new();
            d.EditedAirCon = selected;  //2 chàng trỏ 1 nàng
            d.ShowDialog();
            //F5 LẠI GRID KHI ĐÓNG MÀN HÌNH
            //TODO: ĐÚNG CHUẨN PHẢI KIỂM TRA NẾU CÓ TẠO MỚI, NHẤN NÚT SAVE THÌ MỚI F5
            FillDataGrid();



        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            AirConditioner? selected = AirConsDataGrid.SelectedItem as AirConditioner;
            if (selected == null)
            {  //user ko chọn dòng nào mà lại nhấn nút xoá, ta chửi
                MessageBox.Show("Please select a row/ an air con before deleting", "Select a row", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            MessageBoxResult answer = MessageBox.Show("Do you really want to delete?", "Confirm?", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer == MessageBoxResult.No)
                return;

            //đến đây, mún xoá, nhờ Service
            _service.DeleteAirCon(selected);
            //F5 grid
            FillDataGrid();
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}