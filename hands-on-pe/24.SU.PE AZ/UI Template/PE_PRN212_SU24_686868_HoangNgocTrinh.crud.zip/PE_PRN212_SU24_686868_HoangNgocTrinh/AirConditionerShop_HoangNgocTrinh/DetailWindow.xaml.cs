﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    public partial class DetailWindow : Window
    {

        private AirConService _service = new();
        private SupplierService _supService = new();

        public AirConditioner EditedAirCon { get; set; } = null;
        //biến này gọi là biến Flag, biến cờ, phất lên tuỳ ngữ cảnh
        //nếu nó ko đc giơ/ phất lên, nghĩa là null, nghĩa là màn hình này là màn hình tạo mới
        //nếu biến này phất lên = máy lạnh nào đó có sẵn (đc truyền từ bên Grid đem sang)
        //do user chọn dòng muốn edit => EditedAirCon = dòng bên Main
        //nó != null => ta đã có data của máy lạnh muốn edit, khi đó ta đổ vào các ô
        public DetailWindow()
        {
            InitializeComponent();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            //gọi Service để lưu AirCon xuống table, phải new AirCon()
            //AirConditioner x = new AirConditioner();            
            //AirConditioner x = new() { };

            //TODO: CHẶN DATA VỚ VẨN, CHỬI HẾT, NGON THÌ MỚI GÁN VÀO - VALIDATION

            AirConditioner x = new();
            x.AirConditionerId = int.Parse(AirConditionerIdTextBox.Text); 
            //KEY TỰ TĂNG KO CÓ LỆNH NÀY, HỆ THỐNG TỰ GENERATE NẾU TẠO MỚI
            //NẾU UPDATE THÌ VẪN CẦN
            x.AirConditionerName = AirConditionerNameTextBox.Text;
            x.Warranty = WarrantyTextBox.Text;
            x.SoundPressureLevel = SoundPressureLevelTextBox.Text;
            x.FeatureFunction = FeatureFunctionTextBox.Text;
            x.Quantity = int.Parse(QuantityTextBox.Text);
            x.DollarPrice = float.Parse(DollarPriceTextBox.Text);
            //x.SupplierId = "SC0006"; //hard-coded đỡ đã
            x.SupplierId = SupplierIdComboBox.SelectedValue.ToString();

            //kiểm tra flag, xem tình huống nào thì Add() tình huống nào thì Edit() 
            if (EditedAirCon == null)
                _service.AddAirCon(x);
            else
                _service.UpdateAirCon(x);

            //TODO: BẮT EXCEPTION NẾU TRÙNG PK
            //ĐÓNG MÀN HÌNH DETAIL, TRỞ VỀ MAIN

            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FillComboBox();
            FillElements(EditedAirCon);
            //fill label cho rõ màn hình thuộc chế độ: Add hay Edit
            if (EditedAirCon != null)
                DetailWindowModeLabel.Content = "Cập nhật thông tin máy lạnh";
            else
                DetailWindowModeLabel.Content = "Tạo mới thông tin máy lạnh";
        }

        //hàm này đổ vào các ô nhập, cuốn lịch... data của 1 máy lạnh có sẵn
        private void FillElements(AirConditioner x) 
        {
            if (x == null)
                return;
            //khác null mới đổ
            AirConditionerIdTextBox.Text = x.AirConditionerId.ToString();
            //disable ô nhập Id
            AirConditionerIdTextBox.IsEnabled = false;

            AirConditionerNameTextBox.Text = x.AirConditionerName;
            WarrantyTextBox.Text = x.Warranty;
            SoundPressureLevelTextBox.Text = x.SoundPressureLevel;
            FeatureFunctionTextBox.Text = x.FeatureFunction;
            QuantityTextBox.Text = x.Quantity.ToString();
            DollarPriceTextBox.Text = x.DollarPrice.ToString();

            //nhảy đến đúng cái lựa chọn trong danh sách 5 nhà cung cấp
            //cái lựa chọn này đang có sẵn trong khoá ngoại đọc từ table lên, x.SupplierId

            SupplierIdComboBox.SelectedValue = x.SupplierId;
            //                                 máy lạnh mày đang có id supplier gì, đưa tao đẩy vào combobox, -> tự nhảy đến cột name tương ứng

        }

        //hàm helper đổ data vào ComboBox
        private void FillComboBox()
        {
            SupplierIdComboBox.ItemsSource = _supService.GetAllSuppliers();
            //hiển thị column nào
            SupplierIdComboBox.DisplayMemberPath = "SupplierName";
            //khi chọn thì lấy value từ cột nào, dùng làm FK cho table AirCon
            SupplierIdComboBox.SelectedValuePath = "SupplierId";
            //khi user chọn cột, thì value của cột SupplierId sẽ đc đổ vào prop SelectedValue 

        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }   //TODO: hỏi rằng có muốn save hay ko trước khi đóng
    }
}
