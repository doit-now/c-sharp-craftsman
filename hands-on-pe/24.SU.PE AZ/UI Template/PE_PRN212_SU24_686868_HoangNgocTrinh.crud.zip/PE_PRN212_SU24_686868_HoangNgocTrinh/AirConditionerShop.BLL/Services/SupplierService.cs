﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    ///GUI-UI<-> SERVICE<-> REPO<-> DBCONTEXT<-> TABLE THỰC SỰ Ở SQLSERVER, MYSQL...
    // L1          L2         L3  
    // UI          BLL        DAL (CRUD TABLE) 
    public class SupplierService
    {

        private SupplierRepository _repo = new();

        public List<SupplierCompany> GetAllSuppliers()
        {
            return _repo.GetAll();
        }
    }
}
