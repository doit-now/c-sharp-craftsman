﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{

    ///GUI-UI<-> SERVICE<-> REPO<-> DBCONTEXT<-> TABLE THỰC SỰ Ở SQLSERVER, MYSQL...
    // L1          L2         L3  
    // UI          BLL        DAL (CRUD TABLE) 
    public class AirConService
    {

        private AirConRepository _repo = new(); 

        //HÀM CRUD++, TÊN HÀM ĐẶT DỄ HIỂU, GẦN HƠN VỚI USER
        public List<AirConditioner> GetAllAirCons()
        {
            return _repo.GetAll();
        }

        //GUI UI phải gửi x cho hàm này
        public void AddAirCon(AirConditioner x)
        {
            _repo.Add(x);
        }

        public void UpdateAirCon(AirConditioner x)
        {
            _repo.Update(x);
        }

        public void DeleteAirCon(AirConditioner x)
        {
            _repo.Delete(x);
        }

        //HÀM SEARCH SẢN PHẨM THEO TIÊU CHÍ...
        public List<AirConditioner> SearchAirConsByFeatureQuantity(string feature, int quantity)
        {            
            //feature AND quantity            
        }
    }
}
