﻿using AirConditionerShop.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //GUI-UI <-> SERVICE <-> REPO <-> DBCONTEXT <-> TABLE THỰC SỰ Ở SQLSERVER, MYSQL...
    // L1          L2         L3  
    // UI          BLL        DAL (CRUD TABLE) 

    //CHUẨN HƠN, THÌ THÊM INTERFACE, CLASS NÀY IMPLEMENTS... -> FUTURE PLAN
    public class AirConRepository
    {
        private AirConditionerShop2024DbContext _context; //khi dùng mới new()

        //HÀM CRUD ỨNG VỚI 4 LỆNH SQL CƠ BẢN: INSERT, UPDATE, DELETE, SELECT
        //TÊN HÀM GẦN VỚI DB, THÔ VÀ NGẮN GỌN

        public List<AirConditioner> GetAll()
        {
            //_context = new AirConditionerShop2024DbContext();
            _context = new();
            //return _context.AirConditioners.ToList(); //select * from Air...
            return _context.AirConditioners.Include("Supplier").ToList();
            //                                      JOIN VÀ LẤY HẾT CỘT SUPPLIER
        }

        public void Add(AirConditioner x)
        {
            _context = new();
            _context.AirConditioners.Add(x); //lưu vào ram   
            _context.SaveChanges(); //lưu thực sự xuống DB
        }  //TODO: TRÙNG PK/PRIMARY KEY THÌ SAO
           //TODO: KEY TỰ TĂNG

        public void Update(AirConditioner x)
        {
            _context = new();
            _context.AirConditioners.Update(x);  //ram
            _context.SaveChanges();              //table
        }

        public void Delete(AirConditioner x)
        {
            _context = new();
            _context.AirConditioners.Remove(x); //ram
            _context.SaveChanges();             //table 
        }
    }
}
