﻿using System;
using System.Collections.Generic;

namespace AirConditionerShop.DAL.Entities;

public partial class AirConditioner
{
    public int AirConditionerId { get; set; }

    public string AirConditionerName { get; set; } = null!;

    public string? Warranty { get; set; }

    public string? SoundPressureLevel { get; set; }

    public string? FeatureFunction { get; set; }

    public int? Quantity { get; set; }

    public double? DollarPrice { get; set; }

    public string? SupplierId { get; set; }  //đến cột này là của DB FK 

    public virtual SupplierCompany? Supplier { get; set; } //OOP. object này Máy Lạnh tham
                                                           //chiếu đến Nhà cung ứng
    //                              Supplier là biến trỏ vùng new SupplierCompany() - 1 dòng Supplier trong table
    //                             Navigation Path - join column
}
