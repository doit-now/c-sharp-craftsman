﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Q2.Entities;
using System;
using System.Collections.Generic;
using System.IO;

namespace Q2;

public partial class Prn2125Context : DbContext
{
    public Prn2125Context()
    {
    }

    public Prn2125Context(DbContextOptions<Prn2125Context> options)
        : base(options)
    {
    }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Kitchen> Kitchens { get; set; }

    public virtual DbSet<MenuItem> MenuItems { get; set; }


    private string GetConnectionString()
    {
        IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", true, true)
            .Build();

        return config.GetConnectionString("DefaultConnectionStringDB")
            ?? throw new InvalidOperationException(
                "Connection string DefaultConnectionStringDB not found."
            );
    }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer(GetConnectionString());

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.CategoryId).HasName("PK__Categori__19093A0BCC2B0936");

            entity.Property(e => e.CategoryName).HasMaxLength(100);
        });

        modelBuilder.Entity<Kitchen>(entity =>
        {
            entity.HasKey(e => e.KitchenId).HasName("PK__Kitchens__8A856CC1307BEDA8");

            entity.Property(e => e.Email).HasMaxLength(150);
            entity.Property(e => e.KitchenName).HasMaxLength(100);
        });

        modelBuilder.Entity<MenuItem>(entity =>
        {
            entity.HasKey(e => e.MenuItemId).HasName("PK__MenuItem__8943F72297EECAC4");

            entity.Property(e => e.ItemCode).HasMaxLength(50);
            entity.Property(e => e.ItemName).HasMaxLength(150);
            entity.Property(e => e.Price).HasColumnType("decimal(18, 2)");

            entity.HasOne(d => d.Category).WithMany(p => p.MenuItems)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MenuItems_Categories");

            entity.HasOne(d => d.Kitchen).WithMany(p => p.MenuItems)
                .HasForeignKey(d => d.KitchenId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_MenuItems_Kitchens");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
