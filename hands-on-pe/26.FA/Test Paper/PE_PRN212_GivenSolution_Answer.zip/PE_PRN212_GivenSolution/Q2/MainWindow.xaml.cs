﻿using Microsoft.EntityFrameworkCore;
using Q2.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Q2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Prn2125Context _ctx = new(); //new ăn bớt vế phải
        public MainWindow()
        {
            InitializeComponent();

            //viết dưới lệnh Init
            //fill grid
            MenuDataGrid.ItemsSource = _ctx.MenuItems.ToList(); //chưa include

            FillComboBoxes(); //ngay lúc màn hình open, constructor class cửa sổ này đc gọi, ta gọi thêm hàm fill combobox
        }

        //VIẾT CÁC HÀM HELPER, HÀM NHO NHỎ LÀM TỪNG VIỆC CHUYÊN BIỆT: ĐỔ GRID, ĐỔ COMBOBOX, CHECKVAR...
        //LÁT HỒI TA GỌI CÁC HÀM NÀY TUỲ NGỮ CẢNH:
        //mở màn hình lên thì đổ grid, thì đổ category, đổ kitchen...
        //nhấn nút Save thì gọi hàm check var()
        private void FillComboBoxes()
        {
            //đổ data vào 4 cái combo, trong đó 2 cái filter thì phải add thêm option -- All --
            //nhờ thằng DbContext nó đang chứa 3 List<các entity - các table>
            var cateFilterBag = _ctx.Categories.ToList();  //lấy full Categories
            var kitchenFilterBag = _ctx.Kitchens.ToList(); //lấy full Kitchens

            //bổ sung thêm 2 option --All--
            cateFilterBag.Insert(0, new Category() { CategoryId = 0, CategoryName = "--All--"});
            kitchenFilterBag.Insert(0, new Kitchen() { KitchenId = 0, KitchenName = "--All--" });

            CategoryFilterComboBox.ItemsSource = cateFilterBag;
            //chọn cột để show và chọn cột để lấy giá trị khi đc lựa chọn - treo đầu dê, lấy thịt heo
            CategoryFilterComboBox.DisplayMemberPath = "CategoryName";
            CategoryFilterComboBox.SelectedValuePath = "CategoryId";
            CategoryFilterComboBox.SelectedValue = 0; //mặc định chọn all

            KitchenFilterComboBox.ItemsSource = kitchenFilterBag;
            KitchenFilterComboBox.DisplayMemberPath = "KitchenName";
            KitchenFilterComboBox.SelectedValuePath = "KitchenId";
            KitchenFilterComboBox.SelectedValue = 0; //mặc định chọn all

            //FILL VÀO 2 COMBOBOX Ở KHU VỰC TẠO MỚI MỘT MENU
            var cateBag = _ctx.Categories.ToList();  //lấy full Categories
            var kitchenBag = _ctx.Kitchens.ToList(); //lấy full Kitchens
                       
            CategoryComboBox.ItemsSource = cateBag;
            //chọn cột để show và chọn cột để lấy giá trị khi đc lựa chọn - treo đầu dê, lấy thịt heo
            CategoryComboBox.DisplayMemberPath = "CategoryName";
            CategoryComboBox.SelectedValuePath = "CategoryId";
            
            KitchenComboBox.ItemsSource = kitchenBag;
            KitchenComboBox.DisplayMemberPath = "KitchenName";
            KitchenComboBox.SelectedValuePath = "KitchenId";

        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            //ĐI BẮT XEM USER CÓ CHỌN 2 COMBOBOX HAY KO, NẾU CHỌN THÌ FILTER THEO CATEGORY, VÀ SAU ĐÓ THEO KITCHEN 

            //1. LƯU LẠI 2 GIÁ TRỊ LỰA CHỌN Ở BÊN 2 FILTER COMBOX
            int selectedCateId = (int)CategoryFilterComboBox.SelectedValue; //có thể là số 0 đấy - chọn all đấy
            int selectedKitchenId = (int)KitchenFilterComboBox.SelectedValue;
            //có thể là 0 - chọn all đấy


            //2. WHERE TRÊN 2 GIÁ TRỊ ĐÃ CHỌN, HOẶC KO CHỌN THÌ KHỎI WHERE. NHỚ INCLUDE, VÌ CÓ SHOW CỘT JOIN CÁC BẢNG Ở DATA GRID
            //nếu selected id là 0, ko where vì ứng với chọn ALL
            var query = _ctx.MenuItems.Include("Category").Include("Kitchen").AsNoTracking().AsQueryable(); //select * hết cả đám MenuItem và đã join luôn rồi để lấy cột Name của table Category và table Kitchen

            //ta where thêm nếu user có chọn filter, ko thì khỏi where
            if (selectedCateId != 0) //filter theo Cate đã chọn
            {
                query = query.Where(x => x.CategoryId == selectedCateId);
            }

            if (selectedKitchenId != 0) //filter theo Kitchen đã chọn
            {
                query = query.Where(x => x.KitchenId == selectedKitchenId);
            }

            //3. ĐỔ DATA TÌM THẤY VÀO CÁI GRID 
            MenuDataGrid.ItemsSource = null; //xoá grid
            MenuDataGrid.ItemsSource = query.ToList();

        }

        private void ClearFilterButton_Click(object sender, RoutedEventArgs e)
        {
            CategoryFilterComboBox.SelectedValue = 0; //nhảy lên chữ All
            KitchenFilterComboBox.SelectedValue = 0;  //nhảy lên chữ All

            //gọi lại hàm filter ở trên, giả bộ click nút filter
            FilterButton_Click(sender, e);

        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (!CheckVar())
            {
                return;  //bị vi phạm validation thì ta thoát hàm Add, ko làm tiếp
            }


            //thành công phần validation, thì save DB
            //ĐEM DATA VỪA GÕ XUỐNG TABLE - THẰNG _CTX NÓ CHỈ CHƠI VỚI OBJECT, NÓ ĐANG NẮM TRONG TAY 3 DANH SÁCH List<ỨNG VỚI 3 TABLE: Category, Kitchen -----------< MenuItem  >

            //List<MenuItem> bag -> cái túi chứa đồ, thì bag có thể .Add()  .Remove() nhiều hàm giúp thao tác trên List, và nó  chơi với object 

            //1. Chuẩn bị object MenuItem ~~~ Fruit object trong bài trái cây ~~~ Student trong bài Quản lý sv, data lấy từ các ô nhập đã validation rồi, check var ở trên
            Entities.MenuItem newOne = new();  //new = object initializer, nhưng bài này ko dùng, do cần lấy data từ các ô nhập liệu, code dài
            newOne.ItemCode = ItemCodeTextBox.Text.Trim();
            newOne.ItemName = ItemNameTextBox.Text.Trim();
            newOne.Price = decimal.Parse(PriceTextBox.Text); //ko sợ exception, do đã pass check var ở trên
            newOne.PreparationMinutes = int.Parse(PreparationMinutesTextBox.Text);
            newOne.KitchenId = (int)KitchenComboBox.SelectedValue;
            newOne.CategoryId = (int)CategoryComboBox.SelectedValue;


            //2. Add vào cái List<MenuItem>
            _ctx.MenuItems.Add(newOne);

            //3. Nhờ CTX đem xuống DB
            _ctx.SaveChanges();  //hàm có sẵn của DbContext, EF Core

            //4. Clear màn hình để sẵn sàng nhập mới
            ClearForm();

            //5. Fill lại grid
            MenuDataGrid.ItemsSource = null; //xoá grid
            MenuDataGrid.ItemsSource = _ctx.MenuItems.Include("Category").Include("Kitchen").AsNoTracking().ToList();


            //6. Thông báo thành công
            MessageBox.Show("Save successfully!!!");  //test giả bộ đã save

        }

        //hàm helper, xoá ô nhập
        private void ClearForm()
        {
            ItemCodeTextBox.Clear();
            ItemNameTextBox.Clear();
            PriceTextBox.Clear();
            PreparationMinutesTextBox.Clear();
            KitchenComboBox.SelectedItem = null;  //xoá ko cho chọn 1 cháu nào trong danh sách
            CategoryComboBox.SelectedItem = null;
        }

        //hàm trợ giúp checkvar - check validation các ô nhập
        private bool CheckVar()
        {
            if (string.IsNullOrWhiteSpace(ItemNameTextBox.Text))
            {
                MessageBox.Show("Item Name is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;  //thoát hàm vì đã vi phạm 1 ô nhập
                               //cứ có vi phạm dừng ngay hàm 
            }

            if (string.IsNullOrWhiteSpace(ItemCodeTextBox.Text))
            {
                MessageBox.Show("Item Code is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;  //thoát hàm vì đã vi phạm 1 ô nhập
                               //cứ có vi phạm dừng ngay hàm 
            }
                       
            //giá tiền khó hơn: 2 tình huống: gõ cà chớn ahihi - exception  => xài out
            //                                gõ đúng và nằm ngoài range x..y
            //                                                    khai báo inline, bản chất là biến riêng
            bool priceStatus = double.TryParse(PriceTextBox.Text, out double price);

            if (priceStatus == false)  //bắt cà chớn
            {
                MessageBox.Show("Price must be a number", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (price < 5 || price > 10)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Price must be between 5..10!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //LÀM TƯƠNG TỰ CHO PREPARATION MINUTES => BỮA SAU ÔNG KIỂM TRA!!!

            int minutes;
            bool minutesStatus = int.TryParse(PreparationMinutesTextBox.Text, out minutes);
            if (minutesStatus == false)  //bắt cà chớn
            {
                MessageBox.Show("Preparation Minutes must be a number", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (minutes < 1 || minutes > 100)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Minutest must be between 1..100!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //nếu chưa chọn combobox thì .SelectedItem đang null

            if (CategoryComboBox.SelectedItem == null)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Category is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (KitchenComboBox.SelectedItem == null)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Kitchen is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //CHECK VAR QUAN TRỌNG: KIỂM TRA XEM TABLE MENUITEM(ID, CODE) KHI CHÈN/INSERT ITEM MỚI, MÓN ĂN MỚI CÓ BỊ TRÙNG CODE HAY KO, CODE LÀ STRING, KO PHẢI ID TỰ TĂNG
            //Y CHANG TABLE STUDENT NGOÀI ĐỜI
            //STUDENT( ID-CỘT PK, KEY TỰ TĂNG | STUDEN-CODE-CHAR(8) TUỲ TRƯỜNG ĐH, CÓ THỂ DÀI HƠN,
            //                                  NHƯNG CX CẤM TRÙNG LUÔN - GỌI LÀ UNIQUE)

            //TẤT CẢ CÁC THƯ VIỆN CHƠI VỚI DATABASE, CHỈ HỖ TRỢ MẶC ĐỊNH HÀM CHECK TRÙNG KEY, KIỂM TRA KEY CÓ TỒN TẠI HAY KO, CÒN NHỮNG CỘT CÒN LẠI, MUỐN CHECK TRÙNG TA PHẢI TỰ VIẾT: 
            //- SQL, LAMBDA... ĐỂ CHECK TRÙNG

            //với bài này, ta cần check var, cần check xem user nhập item-code có bị trùng hay ko
            //nhớ trước khi check, phải cắt dấu cách đầu đuôi - vì nó vô nghĩa
            //chơi với chuỗi luôn cắt khoảng trắng đầu đuôi, cẩn thận hoa thường khi so sánh!!!


            bool duplicatedCode = _ctx.MenuItems.Any(x => x.ItemCode.ToLower() == ItemCodeTextBox.Text.Trim().ToLower());

            if (duplicatedCode)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Item code is duplicated!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }
    }
}