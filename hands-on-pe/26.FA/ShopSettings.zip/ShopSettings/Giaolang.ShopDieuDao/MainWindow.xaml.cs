﻿using Giaolang.ShopDieuDao.Models;
using Microsoft.EntityFrameworkCore;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Giaolang.ShopDieuDao
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //KHAI BAO BIEN CONTEXT ĐỂ SỜ CHẠM 2 TABLE .Fruits, .Categories
        private Prn21226faShopDieudaoContext _cxt = new(); //new ăn bớt vế phải
        public MainWindow()
        {
            InitializeComponent();

            //constructor của class cửa sổ chính, sẽ đc gọi khi new cửa sổ, vậy ta dùng để fill vào các grid, các combobox

            FillComboBox();

            IdTextBox.IsEnabled = false;  //phế võ công ô id ngay lúc mở màn hình


        }

        //HÀM LẺ, HÀM RIÊNG, HÀM PHỤ TRỢ, DÙNG NỘI BỘ, KO PUBLIC RA NGOÀI CLASS. HỖ TRỢ CHO CÁC HÀM KHÁC, CODE CHIA ĐỂ TRỊ, FUNCTION HOÁ
        private void FillComboBox()
        {
            //nhờ thằng context _ctx đang nắm giữ các List<ứng với các table> để select lên
            List<Category> cateBag = _cxt.Categories.ToList();

            //bổ sung thêm option ko có trong DB: ----- Select All -----
            //bổ sung bằng tay vào đầu cái cateBag

            cateBag.Insert(0, new Category() { Id = 0, 
                                               Name = "--- Select all ---", 
                                               Description = "..."
                                             });
            //.Insert(obj) ~~~~ .Add(obj) nhưng add thì vào cuối List, còn Insert(chọn vị trí vào túi)

            //đổ túi vào combo filter
            CategoryFilterComboBox.ItemsSource = cateBag;
            CategoryFilterComboBox.DisplayMemberPath = "Name";  //show cột này
            CategoryFilterComboBox.SelectedValuePath = "Id";    //nhưng lấy value cột này

            //mặc định chọn sẵn giùm luôn select all
            CategoryFilterComboBox.SelectedValue = 0;  //cột key Id đc chọn, chọn con số 0

            //đổ vào combo id để add xuống table
            CategoryIdComboBox.ItemsSource = _cxt.Categories.ToList(); //ko chứa --- Select All ---
            CategoryIdComboBox.DisplayMemberPath = "Name";  //show cột này
            CategoryIdComboBox.SelectedValuePath = "Id";    //nhưng lấy value cột này

            //mặc định chọn sẵn giùm luôn select all
            //CategoryIdComboBox.SelectedValue = 0;  //cột key Id đc chọn, chọn con số 0
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            //đổ vào grid đám trái cây
            //FruitDataGrid.ItemsSource = _cxt.Fruits.Include("Category").ToList();
            FruitDataGrid.ItemsSource = _cxt.Fruits.Include(x => x.Category).ToList(); //viết theo lambda
            //                               Fruits tui là cái list có nhiều trái cây, nhưng chưa join
            //                               hãy ép tui join sang bên kia đi, thì sẽ có data trong ram cho Category
            //                                        load luôn cái object Category vào ram
            //                                        khi object Fruit đc load vào ram
            //                 trong class Fruit có khai báo Category Category
            //                                                        **** THẰNG NÀY NÈ - TAY PHẢI, BIẾN OBJ
            //                                                        LOAD CÁI BIẾN NÀY VÀO RAM
            //                                                        PHÍA SAU BIẾN NÀY LÀ CLASS CATEGORY
            //                                                        và là table category, có lệnh include thì
            //                                                        mới join để có full object 1 - N
        }

        private void CategoryButton_Click(object sender, RoutedEventArgs e)
        {
            //mỗi màn hình chính là 1 class OOP như truyền thống
            //nó chỉ khác class truyền thống là nó có thêm cái hàm render() để gọi GPU để render ra cửa sổ - hàm đặc biệt chơi với card đồ hoạ
            //ta mún thấy 1 cửa sổ thì khai báo biến, và new và show

            CategoryWindow cateWin = new();

            //cateWin.Show();  //có thể mở nhiều instance / object cửa sổ khi quay lại nhấn nút bấm này.
            //có 1 cách khác, tại 1 thời điểm chỉ mở 1 cửa sổ khi bấm nút, ko đóng ko cho quay về bấm tiếp.
            //TRONG KĨ THUẬT THIẾT KẾ UI / FE, ĐÓ CHÍNH LÀ KỸ THUẬT SHOW MODAL
            //SHOW ĐỘC QUYỀN, KO XONG VỚI TỚ, CẬU KO ĐC ĐI CHỖ KHÁC

            cateWin.ShowDialog();



        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            //filter danh sách trái cây theo id của category 
            //~~~ select * from Fruit where categoryid = id vừa chọn từ danh sách xổ
            //                        where trên cột khoá ngoại hướng về Category
            //Lambda mãi đỉnh, hỗ trợ lọc dữ liệu cho cái List chứa nhiều data -> HỌC RỒI!!!!!!!!!!!!!!!

            //kiểm tra xem có filter hay ko, user chọn gì từ danh sách xổ
            int cateId = (int)CategoryFilterComboBox.SelectedValue; //bạn chọn gì thì id của category đc  chọn sẽ nằm ở thuộc tính này, ép kiểu về int, vì bản chất là cate_id nhưng dưới dạng data type object

            //khai báo túi đựng trái cây
            var query = _cxt.Fruits.Include(x => x.Category).AsNoTracking().AsQueryable(); //chưa thành ToList() do chưa biết where thế nào do option chọn của combobox chưa xđ
            List<Fruit> fruitBag;

            if (cateId == 0)
            {
                //select all
                fruitBag = query.ToList();
            }
            else
            {
                fruitBag = query.Where(f => f.CategoryId == cateId)
                    .OrderByDescending(x => x.Price).ToList();  //sắp xếp giảm dần theo giá
            }
            //đổ grid
            FruitDataGrid.ItemsSource = null; //xoá grid
            FruitDataGrid.ItemsSource = fruitBag;
          

        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            //1. checkvar các ô nhập coi đúng định dạng, giá trị hay ko - VALIDATION
            //      nhập cà chớn thì bị chửi, và thoát hàm click, ko làm tiếp
            //      viết hàm checkvar riêng, và if ở đây 
            if (CheckVar() == false)
            {
                return;
            }

            //2. tạo object Fruit(id, name,...)
            Fruit newOne = new()
            {
                Name = NameTextBox.Text.Trim(),
                Description = DescriptionTextBox.Text.Trim(),  //trim cắt khoảng trắng đầu đuôi
                Price = double.Parse(PriceTextBox.Text.Trim()), //convert thoải mái ko sợ vì đã pass checkvar ở trên, chắc chắn là số rồi
                //FK, 
                CategoryId = (int)CategoryIdComboBox.SelectedValue,

                //ngày tháng
                ExpiredDate = (DateTime)ExpiredDateDatePicker.SelectedDate.Value

            };

            //3. gửi object này cho DbContext nhờ nó CRUD
            _cxt.Fruits.Add(newOne);  //mới vào List<Fruit> trong RAM
            _cxt.SaveChanges();   //xuống DB thật sự

            FruitDataGrid.ItemsSource = null;
            FruitDataGrid.ItemsSource = _cxt.Fruits.Include(x => x.Category).ToList();

            MessageBox.Show("Save successfully!", "Notification", MessageBoxButton.OK, MessageBoxImage.Information);

            ClearForm(); //xoá màn hình

        }

        public void ClearForm()
        {
            NameTextBox.Clear();  //.Text = ""; cx okie
            DescriptionTextBox.Clear();
            PriceTextBox.Clear();
            CategoryIdComboBox.SelectedItem = null; 
            //khoá ô nhập id
            IdTextBox.IsEnabled = false; //ko cho gõ, lock lại
            ExpiredDateDatePicker.SelectedDate = null;
        }

        private bool CheckVar()
        {
            if (string.IsNullOrWhiteSpace(NameTextBox.Text))
            {
                MessageBox.Show("Name is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;  //thoát hàm vì đã vi phạm 1 ô nhập
                               //cứ có vi phạm dừng ngay hàm 
            }

            if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show("Desc is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;  //thoát hàm vì đã vi phạm 1 ô nhập
                               //cứ có vi phạm dừng ngay hàm 
            }

            int descLength = DescriptionTextBox.Text.Trim().Length;
            if (descLength < 5 || descLength > 50)
            {
                MessageBox.Show("Desc must be in 5..50 characters!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;  //thoát hàm vì đã vi phạm 1 ô nhập
                               //cứ có vi phạm dừng ngay hàm 
            }

            //giá tiền khó hơn: 2 tình huống: gõ cà chớn ahihi - exception  => xài out
            //                                gõ đúng và nằm ngoài range x..y
            //                                                    khai báo inline, bản chất là biến riêng
            bool priceStatus = double.TryParse(PriceTextBox.Text, out double price);

            if (priceStatus == false)  //bắt cà chớn
            {
                MessageBox.Show("Price must be between 5..10!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            if (price < 5 || price > 10)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Price must be between 5..10!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //nếu chưa chọn combobox thì .SelectedItem đang null
        
            if (CategoryIdComboBox.SelectedItem == null)  //gõ mlem, nhưng ngoài biên
            {
                MessageBox.Show("Category is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (ExpiredDateDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Expired Date is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }


            return true;
        }
    }
}