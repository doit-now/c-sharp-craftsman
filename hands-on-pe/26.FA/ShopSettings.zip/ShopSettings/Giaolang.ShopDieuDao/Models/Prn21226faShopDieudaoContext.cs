﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;

namespace Giaolang.ShopDieuDao.Models;

public partial class Prn21226faShopDieudaoContext : DbContext
{
    public Prn21226faShopDieudaoContext()
    {
    }

    public Prn21226faShopDieudaoContext(DbContextOptions<Prn21226faShopDieudaoContext> options)
        : base(options)
    {
    }

    //         ~~~ List<Fruits> _fruits
    //DbSet to hơn, mạnh hơn List vì nó chơi đc với cả RAM và table
    //                       List chỉ chơi với RAM thôi
    //ta có thể convert từ DbSet thành List để xử lý data trong RAM
    //new class này và chấm 2 prop này ~~~ với SELECT * FROM FRUIT
    //                                 ~~~ với SELECT * FROM CATEGORY
    //CÓ LIST NÀY TA FILL VÀO DATA GRID

    //Prn21226faShopDieudaoContext ctx = new Prn21226faShopDieudaoContext();
    //FruitDataGrid.ItemSource = ctx.Fruits.ToList();

    //FruitDataGrid.ItemSource = new Prn21226faShopDieudaoContext().Fruits.ToList();

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<Fruit> Fruits { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer(GetConnectionString());
    }

    private string GetConnectionString()
    {
        IConfiguration config = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", true, true)
            .Build();

        return config.GetConnectionString("DefaultConnectionStringDB")
            ?? throw new InvalidOperationException(
                "Connection string DefaultConnectionStringDB not found."
            );
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Category>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Category__3214EC07E831B352");

            entity.ToTable("Category");

            entity.Property(e => e.Description).HasMaxLength(200);
            entity.Property(e => e.Name).HasMaxLength(50);
        });

        modelBuilder.Entity<Fruit>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Fruit__3214EC07FDC29DC2");

            entity.ToTable("Fruit");

            entity.Property(e => e.Description).HasMaxLength(200);
            entity.Property(e => e.Name).HasMaxLength(50);

            entity.HasOne(d => d.Category).WithMany(p => p.Fruits)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Fruit_Category");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
