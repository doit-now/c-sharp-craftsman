﻿using System;
using System.Collections.Generic;

namespace Giaolang.ShopDieuDao.Models;

public partial class Fruit
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public double Price { get; set; }

    public int CategoryId { get; set; }

    public DateTime? ExpiredDate { get; set; }

    public virtual Category Category { get; set; } = null!;
}
