﻿using System;
using System.Collections.Generic;

namespace Giaolang.ShopDieuDao.Models;

public partial class Category
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public virtual ICollection<Fruit> Fruits { get; set; } = new List<Fruit>();
}
