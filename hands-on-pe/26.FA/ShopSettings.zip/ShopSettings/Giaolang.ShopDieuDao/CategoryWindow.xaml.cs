﻿using Giaolang.ShopDieuDao.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Giaolang.ShopDieuDao
{
    /// <summary>
    /// Interaction logic for CategoryWindow.xaml
    /// </summary>
    public partial class CategoryWindow : Window
    {
        public CategoryWindow()
        {
            InitializeComponent();
        }

        private void ShowCatesButton_Click(object sender, RoutedEventArgs e)
        {
            //combobox hộp xổ cơ bản giống cái data grid đã làm, nó show nhiều dòng dữ liệu, dữ liệu nhận vào là 1 List<?> 
            //khác data grid là: data grid đc show nhiều cột
            //     combobox    : chỉ chọn 1 cột để show, các cột khác ẩn hết, dù List object có nhiều cột, Fruit có 4 cột, chỉ chọn 1 cột để show, Category có 3 cột, chọn cột Name để show

            //khác data grid là chọn 1 dòng, và thông tin dòng đc chọn lưu vào 2 3 chỗ khác nhau, tuỳ nhu cầu muốn lấy thông tin dòng đc chọn
            //.SelectedValue    -> trỏ đến 1 cột của dòng vừa chọn
            //.SelectedItem     -> trỏ đến nguyên cả cái dòng, cái object vừa chọn
            //.SelectedIndex    -> mang giá trị dòng thứ mấy đc chọn 
            //ví dụ: cái combo này xổ danh sách Tỉnh/Thành phố

            //Province sẽ gồm Id |   Name         | Description | Area | 
            //                50    TP. HCM         ...
            //                29    TP. Hà Nội      ...
            //-> chọn         60    Đồng Nai        ...             -> .SelectedValue
            //                63    Tiền Giang
            //                 |          |
            //                 |     xổ/show cái cột này
            //                 |     .DisplayMemberPath
            //                 |                   
            //                lấy cột này, lấy value cột này để xài
            //                .SelectedValuePath
            //                
            //CHUẨN BỊ SẴN DANH SÁCH 3 LOẠI TRÁI CÂY ~ 3 TỈNH TP
            List<Category> bag =
                [
                  new Category() { Id = 0, Name = "-- Select All --", Description = "..." },
                  new Category() { Id = 1, Name = "Trái cây nhập khẩu", Description = "Trái cây Úc..." },
                  new Category() { Id = 2, Name = "Trái cây VietGAP", Description = "Trái cây nhà vườn..." },
                  new Category() { Id = 3, Name = "Trái cây sấy khô", Description = "Trái cây sấy nhiệt..." }
                ];

            CatesComboBox.ItemsSource = bag;
            CatesComboBox.DisplayMemberPath = "Name";  //treo đầu dê. chọn Name
            CatesComboBox.SelectedValuePath = "Id";    //bán thịt hẹo, lấy cột Id để dùng

        }

        private void ShowSelectedCateButton_Click(object sender, RoutedEventArgs e)
        {
            if (CatesComboBox.SelectedItem == null)
            {
                //chửi vì ko chịu chọn list mà lại nhấn nút show
                MessageBox.Show("Làm ơn chọn giúp em 1 cate!!!");
                return;
            }

            int selectedCate = (int)CatesComboBox.SelectedValue;  //lấy value của cột id của dòng đc chọn
            MessageBox.Show("Bạn đã chọn id: " + selectedCate);
        }
    }
}
