﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //                    !!!        _BAG
    public class SupplierRepo
    {
        //class này chịu trách nhiệm crud table Supplier NCC
        //nhưng ta chỉ làm select * select all vì PE KO YÊU CẦU
        //VÀ KO ĐỦ THỜI GIAN ĐỂ LÀM XOÁ, SỬA, THÊM 1 NCC
        //NHƯNG SWP THÌ PHẢI CÓ
        private AirConditionerShopDbContext _ctx; //ko new

        public List<SupplierCompany> GetAll()
        {
            _ctx = new();
            return _ctx.SupplierCompanies.ToList();
        }

    }
}
