﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //                    !!!        _BAG
    public class AccountRepo
    {

        //CHỈ LÀM HÀM LIÊN QUAN LOGIN, VÌ THỜI LƯỢNG THI KO CHO PHÉP CRUD USER, CRUD ACCOUNT
        //LOGIN DỰA TRÊN EMAIL VÀ PASSWORD

        //LOGIN XỊN, THÌ CHỈ WHERE TRÊN EMAIL!!!!!! ĐỂ BIẾT CHÍNH XÁC SAI GÌ?
        //SAI EMAIL -> THÔNG BÁO ACCOUNT KO TỒN TẠI
        //ĐÚNG EMAIL -> SAI PASS THÔNG BÁO SAI PASS
        //ĐÚNG EMAIL -> SAI PASS, SAI NHIỀU LẦN, LOCK ACCOUNT
        //ĐÚNG MAIL, ĐÚNG PASS -> VÀO APP ĐI EM, NHỚ CHECK THÊM ROLE!!!
        //--------------------    -----------------------------------
        // AUTHENTICATION         IF ROLE == ADMIN -> ENABLE ALL NÚT BẤM
        //                        IF ROLE == MEMBER -> DISABLE CREATE/UPDATE/DEL
        //                        VÀO ĐC, NHƯNG BỊ GIỚI HẠN TÍNH NĂNG
        //XÁC THỰC                PHÂN QUYỀN -> AUTHORIZATION
        //MÌNH QUEN NHAU KO       QUEN, NHƯNG ĐC CHẠM VÀO NHỮNG GÌ
        //AUTHEN ĐI TRƯỚC, AUTHOR ĐI SAU

        //TÊN HÀM BÊN REPO, ĐẶT NGẮN GỌN, GẦN DATABASE
        //HÀM LOGIN TRẢ VỀ DUY NHẤT 1 ACCOUTN, HOẶC NULL, MÀY LOGIN KO ĐC VÌ ACC KO TỒN TẠI, HOẶC SAI PASS

        private AirConditionerShopDbContext _ctx;  //ko new
         
        public StaffMember? FindByEmail(string email) //có tồn tại email trong DB ko
        {
            //thằng DbContext có sẵn 1 loạt hàm giúp ta query data theo tiêu chí nào đó,
            //dùng biểu thức lambda!!!
            _ctx = new();
            //_ctx.StaffMembers.Where(đk lọc theo Lamda Expression - trả về nhiều);
            //_ctx.StaffMembers.FirstOrDefault(đk lọc theo Lambda - trả về 1 dòng, hoặc null)

            return _ctx.StaffMembers.FirstOrDefault(nt => nt.EmailAddress == email);
        } 
    }
}
