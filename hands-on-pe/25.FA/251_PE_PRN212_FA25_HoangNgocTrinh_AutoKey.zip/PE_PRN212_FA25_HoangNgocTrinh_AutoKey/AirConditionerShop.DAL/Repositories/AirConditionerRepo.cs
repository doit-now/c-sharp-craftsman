﻿using AirConditionerShop.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    public class AirConditionerRepo
    {
        //MANTRA
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //                    !!!        _BAG
        private AirConditionerShopDbContext _ctx; 
        //ko new, chừng nào xài ở các hàm thì mới new
        //mỗi hàm xài nó thì new lại 1 lần

        //HÀM CRUD TABLE AIR-CON

        //hàm này trả về select * from AirCon phục vụ cho việc show lưới ở cửa sổ MainWindow
        public List<AirConditioner> GetAll()
        {
            //_ctx = new AirConditionerShop2024DbContext();
            _ctx = new();
            //sờ vào cái túi là có tất cả
            //return _ctx.AirConditioners.ToList();
            return _ctx.AirConditioners.Include("Supplier").ToList();  //join luôn, học rồi, join với Cate
            //        DbSet<> rất giống List<> cần convert

            //lát hồi: Suplier.SupplierName là lấy đc cột Name của Category!!!!!!!!! để show grid cho đẹp trai!!!
            //0.75 điểm, nếu ko chỉ show khoá ngoại mã - ncc vô hồn
            //thay vì show chữ Apple, Samsung, Daikin
        }

        //CÁC HÀM TRONG REPO THƯỜNG ĐẶT TÊN RẤT NGẮN GỌN, VÌ NÓ GẦN SÁT TABLE
        //VỚI TABLE: 4 LỆNH SQL CƠ BẢN: SELECT FROM, SELECT FROM WHERE, UPDATE, DELETE, INSERT
        //ĐƯA KEY, THÌ WHERE KEY ĐỂ XOÁ, 
        //ĐƯA NGUYÊN OBJECT, TRONG OBJECT CÓ KEY
        //THẰNG SELECTED BÊN GUI CÓ CHỨA KEY. THẢY NÓ VÀO HÀM NÀY LUÔN
        public void Delete(AirConditioner obj)   //SERVICE GỌI HÀM NÀY
        {
            _ctx = new(); //luôn new cho mỗi hành động
            _ctx.AirConditioners.Remove(obj);
            _ctx.SaveChanges();  //XUỐNG DB THẬTS
        }

        public void Update(AirConditioner obj)   //SERVICE GỌI HÀM NÀY
        {
            _ctx = new(); //luôn new cho mỗi hành động
            _ctx.AirConditioners.Update(obj);
            _ctx.SaveChanges();  //XUỐNG DB THẬTS
        }

        public void Create(AirConditioner obj)   //SERVICE GỌI HÀM NÀY
        {
            _ctx = new(); //luôn new cho mỗi hành động
            _ctx.AirConditioners.Add(obj);
            _ctx.SaveChanges();  //XUỐNG DB THẬTS
        }

    }
}
