﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //                    !!!        _BAG
    public class AccountService
    {
        private AccountRepo _repo = new(); //new luôn

        //CHỈ 1 HÀM DUY NHẤT KHI THI PE, DO KO ĐỦ THỜI GIAN ĐỂ LÀM CRUD TẤT CẢ

        public StaffMember? Authenticate(string email) {

            return _repo.FindByEmail(email);
        }  //HÀM LOGIN, XÁC THỰC QUA EMAIL.

    }
}
