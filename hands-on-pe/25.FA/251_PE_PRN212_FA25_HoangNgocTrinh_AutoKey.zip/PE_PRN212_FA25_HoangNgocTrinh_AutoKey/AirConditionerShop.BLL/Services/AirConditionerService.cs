﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    public class AirConditionerService
    {
        //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //         !!!
        //chứa các hàm xử lí data trong RAM và nó sẽ cần Repo trợ giúp
        private AirConditionerRepo _repo = new(); //new luôn ko sợ

        //bên repo ko new DbContext; xài đến đâu new đến đó vì nó dính trực tiếp table
        //bên Service mình xài Repo, ko xài trực tiếp DbContext, Repo che DbContext, mình new thoải mái!!!

        //các hàm CRUD TABLE TRUNG TÂM: AIR-CON
        //bên Service đặt tên hàm gần gũi, rõ ràng
        //bên Repo đặt tên hàm gần với câu SQL: ngắn gọn
        //                                      GetAll() Create() Insert() Remove()
        public List<AirConditioner> GetAirConditioners()
        {
            return _repo.GetAll();
        }

        //CRUD AIR-CON NHƯNG NÓ LẠI ĐI GỌI REPO GIÚP
        public void DeleteAirCon(AirConditioner obj)
        {
            _repo.Delete(obj);
        }

        public void UpdateAirCon(AirConditioner obj)
        {
            _repo.Update(obj);
        }

        public void CreateAirCon(AirConditioner obj)
        {
            _repo.Create(obj);
        }




    }
}
