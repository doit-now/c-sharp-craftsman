﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //          !!!                  _BAG
    public class SupplierService
    {
        private SupplierRepo _repo = new();

        public List<SupplierCompany> GetAllSuppliers()
        {
            return _repo.GetAll();
        }
    }
}
