﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //     LAYER 1     BLL LAYER 2   DAL LAYER 3             
        //GUI/CONTROLLER --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
        //!!!
        //@Autowire: bên Java là DEPENDENCY INJECTION 
        //           bên C# cũng có luôn!!! XEM VIDEO SỐ 4 CỦA ANH QUÂN 
        private AirConditionerService _airService = new();
        //                                          TỰ NEW GỌI LÀ TIGHT-COUPLING
        //                            KO TỰ NEW MÀ BÊN NGOÀI ĐƯA VÀO
        //                            LOOSE-COUPLING


        //đc gán từ Login sang!!!!!!!!!
        //dùng nó để biết role để enable/disble nút bấm
        public StaffMember LoggedInUser { get; set; }
        //ko có cửa null, vì login thành công mới đến đây

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            DetailWindow d = new();
            d.Show();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //SHOW TOÀN BỘ MÁY LẠNH
            //AirCondDataGrid.ItemsSource = _airService.GetAirConditioners();
            FillDataGrid(_airService.GetAirConditioners());

            //CHECK NÚT BẤM:
            if (LoggedInUser.Role == 2)
            {
                //staff hả, cấm nút bấm
                CreateButton.IsEnabled = false;
                UpdateButton.IsEnabled = false;
                DeleteButton.IsEnabled = false;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //1. BẮT RA 1 DÒNG, BẮT XEM CHỌN DÒNG CHƯA
            AirConditioner? selected = AirCondDataGrid.SelectedItem  as AirConditioner;
            if (selected == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //2. ARE YOU SURE?
            MessageBoxResult answer = MessageBox.Show("Are you sure?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer == MessageBoxResult.No)
            {
                return;
            }
            //3. YES -> XOÁ THẬT THÌ PHẢI GỌI SERVICE, CUNG CẤP CRUD TRÊN CÁI TABLE AIR-CON

            _airService.DeleteAirCon(selected);

            //4. F5 GRID     F5 GRID XUẤT HIỆN Ở DELETE, UPDATE, CREATE, SEARCH
            //   TÁCH THÀNH HÀM ĐỂ RE-USE, HÀM TRỢ GIÚP CHO CÁC HÀM KHÁC, HELPER METHOD - PRIVATE
            FillDataGrid(_airService.GetAirConditioners());
        }
        //public để đỡ màu xám, chuẩn chỉ cần private, hàm nội bộ
        public void FillDataGrid(List<AirConditioner> bag)
        {
            AirCondDataGrid.ItemsSource = null; //xoá nếu đang có
            AirCondDataGrid.ItemsSource = bag;
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            //1. BẮT 1 DÒNG ĐÃ CHỌN, HOẶC CHỬI NẾU CHƯA
            AirConditioner? selected = AirCondDataGrid.SelectedItem as AirConditioner;
            if (selected == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //2. GỬI SANG MÀN HÌNH DETAIL CHO USER EDIT
            DetailWindow detail = new();
            //detail.Show();

            detail.EditedOne = selected; //đẩy em sang bên Detail
            //2 chàng 1 nàng, chỗ này là 3 chàng 1 nàng

            detail.ShowDialog();  //ko xong màn hình này, ko cho về lại Main

            //3. USER SAVE BÊN DETAIL, ĐÓNG DETAIL, QUAY LẠI ĐÂY, TA F5 GRID
            FillDataGrid(_airService.GetAirConditioners());

        }

        private void CreateButton_Click_1(object sender, RoutedEventArgs e)
        {
            //1. gọi cửa sổ Detail lên, show Detail
            //  ko truyền selected sang vì tạo mới, màn hình Detail trống trơn
            DetailWindow detail = new();
            //detail.Show();

            detail.ShowDialog();  //ko xong màn hình này, ko cho về lại Main
            //2. chờ màn hình Detail nhập mới info Máy lạnh, Save, đóng màn hình detail
            //3. F5 cái grid bên Main
            FillDataGrid(_airService.GetAirConditioners());

        }
    }
}