﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    /// 

    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //!!!                            _BAG
    public partial class DetailWindow : Window
    {

        private AirConditionerService _airService = new(); //save
        private SupplierService _supService = new(); //combo

        //BIẾN AIR-CON ĐỂ HỨNG SELECTED BÊN MAIN GỬI SANG, MỚI CÓ INFO ĐỂ FILL VÀO Ô NHẬP
        //private AirConditioner _airCon; và thêm hàm get set
        //chơi property cho pro
        public AirConditioner EditedOne { get; set; }
        //biến flag đó em


        public DetailWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            //ko care mode, đều treo đầu dê bán thịt heo, đều cho chọn NCC từ danh sách xổ xuống, y chang chọn danh sách tỉnh, quận, huyện
            SupplierIdComboBox.ItemsSource = _supService.GetAllSuppliers();
            //treo đầu dê
            SupplierIdComboBox.DisplayMemberPath = "SupplierName";
            //lấy thịt heo
            SupplierIdComboBox.SelectedValuePath = "SupplierId";
            //cột khoá ngoại đó em!!!!

            AirConditionerIdTextBox.IsEnabled = false; //khoá ô id lại ko cho sửa DÙ LÀ TẠO MỚI HAY EDIT!!!!!!!!!!!

            if (EditedOne != null)
            {  //có người gửi seleted sang kìa, edit mode
                DetailWindowMode.Content = "Chỉnh sửa info máy lạnh";
                //fill data từ selected vào các ô nhập
                AirConditionerIdTextBox.Text = EditedOne.AirConditionerId.ToString();
               
                AirConditionerNameTextBox.Text = EditedOne.AirConditionerName;
                QuantityTextBox.Text = EditedOne.Quantity.ToString();
                DollarPriceTextBox.Text = EditedOne.DollarPrice.ToString();
                FeatureFunctionTextBox.Text = EditedOne.FeatureFunction;
                SoundPressureLevelTextBox.Text = EditedOne.SoundPressureLevel;
                WarrantyTextBox.Text = EditedOne.Warranty;

                //NGÀY THÁNG NĂM
                ManuDateDatePicker.Text = EditedOne.ManufacturedDate.ToString();


                //CÒN KHOÁ NGOẠI THÌ SAO????
                //TA SẼ KO CÓ Ô NHẬP KHOÁ NGOẠI MÀ SẼ SHOW KHOÁ NGOẠI QUA COMBOBOX
                //XỔ RA 1 ĐỐNG CÁC NHÀ CUNG CẤP 
                //                            ĐÓ LÀ VIỆC CỦA:
                //                         SupplierService     ->  SupplierRepo
                SupplierIdComboBox.SelectedValue = EditedOne.SupplierId;
                //combo, mày hãy nhảy đến đúng chỗ giùm tao, vì selected tao đang có supplier id là X  
            }
            else
            {  //new mode
                DetailWindowMode.Content = "Tạo mới máy lạnh";
            }
        }

        private bool CheckVar()
        {
            //bắt từng ô nhập, check đk theo đầu bài, true thì đi tiếp trong hàm qua ô kế, sai, dừng hàm luôn
            //if (string.IsNullOrWhiteSpace(AirConditionerIdTextBox.Text))
            //{
            //    MessageBox.Show("Id is required!", "Required field", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return false;
            //}
            //vượt id, check tiếp name
            if (string.IsNullOrWhiteSpace(AirConditionerNameTextBox.Text))
            {
                MessageBox.Show("Name is required!", "Required field", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            //check độ dài name từ 5..50 kí tự
            int length = AirConditionerNameTextBox.Text.Length;
            if (length < 5 || length > 50)
            {
                MessageBox.Show("Name must be in 5 to 50 characters length!", "Invalidated length", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            //vượt name, check tiếp quantity...
            //VUI: NẾU GÕ AHIHI VÀO Ô NHẬP SỐ -> CHỬI
            //     NẾU GÕ SỐ THẬT SỰ, KIỂM TRA TRONG ĐOẠN [X ... Y] [5...50] 
            //CÁCH 1: int.Parse(chữ sẽ biến thành số) là luôn quăng về ngoại lệ nếu đưa vào chuỗi cà chớn, muốn check user gõ số hay chữ cà chớn thì phải try catch
            //CÁCH 2: ko thích dùng try catch thì dùng
            //int.TryParse(chữ sẽ biến thành số, out biến để lưu số) -> bool
            //hàm trả về 2 giá trị nếu convert thành công: convert ok và số mấy!!!!!!!!!!!!!!!!!!!!! OUT MÃI ĐỈNH
            bool convertedStatus;
            convertedStatus = int.TryParse(QuantityTextBox.Text, out int result);
            if (!convertedStatus) //convert ko đc do gõ NGOC TRINH..., THÌ CHỬI
            {
                MessageBox.Show("Quantity must be a number!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //GÕ TỬ TẾ, THÌ CHECK XEM CÓ NẰM TRONG ĐOẠN TỪ 50...100 (VÍ DỤ THEO ĐỀ)
            if (result < 50 || result > 100)
            {
                MessageBox.Show("Quantity must be in the range of 50...100!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //PRICE LÀM TƯƠNG TỰ, NHƯNG DÙNG double.TryParse()

            //TODO: KIỂM TRA NGÀY THÁNG ĐÃ GÕ CHƯA
            //      KIỂM TRA XEM NGÀY CÓ BÉ HƠN NGÀY HIỆN TẠI HAY KO
            if (ManuDateDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Date is requied!!!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            DateTime current = DateTime.Today; //lấy ngày hiện nay so sánh với ngày nhập vào!!!
            if (ManuDateDatePicker.SelectedDate >= current)
            {
                MessageBox.Show("Manu date must be less than current date!!!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }


            return true;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            //0. chửi nếu chưa validation trên các ô nhập
            //1 đống lệnh if, nếu sai thì return, ko chạy xuống 1. ở dưới -> tách hàm validation cho code gọn!!!
            //if (CheckVar() == false)  //dính sẹo validation ô nhập nào đó, ko làm tiếp
            //{ 
            //    return; 
            //}

            if (!CheckVar())  //dính sẹo validation ô nhập nào đó, ko làm tiếp
            {
                return;
            }


            //1. tạo mới 1 object, gom thông tin từ các ô nhập
            AirConditioner obj = new AirConditioner() { };

            if (EditedOne != null)  //NẾU LÀ EDIT THÌ GÁN ID ĐANG EDIT VÀO OBJECT
                obj.AirConditionerId = int.Parse(AirConditionerIdTextBox.Text);

            //NẾU CREATE MODE THÌ KO GÁN ID CHO OBJECT!!!!!!!!!!!!!!!!!!!!!!!

            obj.AirConditionerName = AirConditionerNameTextBox.Text;
            obj.Warranty = WarrantyTextBox.Text;
            obj.Quantity = int.Parse(QuantityTextBox.Text);
            obj.DollarPrice = double.Parse(DollarPriceTextBox.Text);
            obj.FeatureFunction = FeatureFunctionTextBox.Text;
            obj.SoundPressureLevel = SoundPressureLevelTextBox.Text;

            //NGÀY THÁNG
            obj.ManufacturedDate = ManuDateDatePicker.SelectedDate;

            //khoá ngoại ơi
            obj.SupplierId = SupplierIdComboBox.SelectedValue.ToString();
                            //xin thịt heo

            //2. if edit mode thì gọi hàm update của service
            if (EditedOne != null)
            {
                _airService.UpdateAirCon(obj);
            }
            else
            {
                _airService.CreateAirCon(obj);
            }
            //3. if new mode thì gọi hàm create của service
            //4. đóng màn hình, về main, F5 grid

            this.Close(); //gọi hàm class Window cha để đóng màn hình
        }
    }
}
