﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{

    //MANTRA
    //GUI --- SERVICE --- REPO --- DBCONTEXT --- TABLE THẬT
    //!!!                            _BAG

    public partial class LoginWindow : Window
    {

        private AccountService _service = new();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
           



        }

        private void LoginButton_Click_1(object sender, RoutedEventArgs e)
        {
            string email = EmailAddressTextBox.Text;
            string pass = PasswordTextBox.Text;

            //chửi trước, ko nhập gì chửi!!!
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Both email and password are required!!!", "Field required", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            StaffMember? acc = _service.Authenticate(email);
            //có nguy cơ sau: acc null -> email ko tồn tại rồi
            //                acc !=null -> check tiếp pass đang nằm trong acc == gõ hay ko
            if (acc == null)
            {
                MessageBox.Show("Email doesn't exist. Sign-up please", "Invalidated credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //email đã tồn tại rồi, check pass
            if (acc.Password != pass)  //== đc quyền dùng trong C# để check chuỗi!!!, Java cấm. So sánh có hoa thường
            {
                MessageBox.Show("Wrong password. Reset password please", "Invalidated credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //AUTHORIZATION
            //ngon lành đúng email đúng pass, check role tiếp
            if (acc.Role == 3)  //member cấm vào app luôn
            {
                MessageBox.Show("You are member, and you have no permission to access!!!", "Access denied", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //ADMIN, HOẶC STAFF, MỜI EM VÀO APP ANH
            MainWindow main = new();

            main.LoggedInUser = acc;  //đẩy acc sang màn hình Main
            
            main.Show();
            this.Hide(); //ẩn màn hình login, ko tắt .Close() Login, vì nó như hàm main()

        }
    }
}
