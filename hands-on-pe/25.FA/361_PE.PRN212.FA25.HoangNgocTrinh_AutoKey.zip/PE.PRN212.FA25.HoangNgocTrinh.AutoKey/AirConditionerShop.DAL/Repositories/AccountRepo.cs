﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                             !!!
    public class AccountRepo
    {
        private AirConditionerShopDbautoKeyContext _ctx; //ko new chờ trong hàm!!!!!!!!!!!!!!!!!!

        //KO VIẾT CÁC HÀM CRUD VÌ KO ĐỦ THỜI GIAN CHO PE. SWP LÀM ĐỦ
        //ĐỪNG QUÊN CÁI _BAG CỦA DB CONTEXT CHỨ FULL DATA CỦA TABLE STAFFMEMBER - ACCOUNT
        //TÊN HÀM BÊN REPO THƯỜNG NGẮN GỌN, TÊN SERVICE THƯỜNG ĐỦ Ý NGHĨA
        public StaffMember? FindByEmail(string email)
        {
            //VIẾT WHERE TRÊN EMAIL HOY
            //DÙNG BIỂU THỨC LAMBDA, HỌC SAU
            _ctx = new();
            //return _ctx.StaffMembers.ToList(); //sờ túi là sờ đc tất cả các Account, mình ko muốn lấy hết, chỉ lấy account thoả cái email đưa vào!!!!!!!!
            //_ctx.StaffMembers.CHẤM GÌ ĐÓ LÀ TRẢ VỀ 1 DÒNG, HOẶC NHIỀU DÒNG. 
            //_ctx.StaffMembers.FirstOrDefault(đk where) -> 1 dòng, hoặc null nếu ko tìm thấy ->login

            //_ctx.StaffMembers.Where(đk where) -> 1 dòng, hoặc nhiều dòng!!!  -> hàm search

            //thò tay vào túi, lấy 1 món đồ, hoặc nhiều món đồ
            return _ctx.StaffMembers.FirstOrDefault(nt => nt.EmailAddress == email);

        }

        public StaffMember? FindByEmailAndPassword(string email, string pass)
        {
            //VIẾT WHERE TRÊN CẢ EMAIL VÀ PASS
            return _ctx.StaffMembers.FirstOrDefault(nt => nt.EmailAddress == email && nt.Password == pass);           
        }
    }
}

//TRONG C# SO SÁNH CHUỖI ĐC QUYỀN DÙNG ==, NHƯNG BẢN THÂN PHÍA SAU CHÍNH LÀ SO SÁNH 2 OBJECT NHƯ BÊN JAVA

//TRONG JAVA, SO SÁNH 2 CHUỖI PHẢI DÙNG HÀM CỦA CLASS STRING
//msg.Equals("Hello") -> true false
