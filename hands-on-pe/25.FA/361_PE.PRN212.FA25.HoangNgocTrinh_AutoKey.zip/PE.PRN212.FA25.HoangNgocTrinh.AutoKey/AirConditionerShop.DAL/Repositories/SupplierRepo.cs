﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                             !!!
    public class SupplierRepo
    {
        private AirConditionerShopDbautoKeyContext _ctx; //chừng nào xài thì mới đc new

        //CRUD THÊM XOÁ SỬA TÌM KIẾM NHÀ CUNG CẤP!!!
        //THI PE KO CẦN THÊM XOÁ SỬA, VÌ KO ĐỦ THỜI GIAN
        //NHƯNG SWP THÌ PHẢI LÀM

        //chỉ làm hàm getAll() vì cần nó cho treo đầu dê lấy thịt heo ở màn hình detail
        public List<SupplierCompany> GetAll()
        {
            _ctx = new();
            return _ctx.SupplierCompanies.ToList();
                 //mày chứa 3 cái túi, ứng với 3 table
                 //chấm là lấy hết data
        }
    }
}
