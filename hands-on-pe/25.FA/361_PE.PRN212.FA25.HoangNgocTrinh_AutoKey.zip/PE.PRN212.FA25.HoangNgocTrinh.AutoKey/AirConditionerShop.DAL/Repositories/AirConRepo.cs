﻿using AirConditionerShop.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    public class AirConRepo
    {
        //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
        //                             !!!
        //chứa hàm CRUD table AirCon, chắc chắn phải xài DbContext
        //xài thì phải khai báo và new!!!!!!!!!!!!!!
        private AirConditionerShopDbautoKeyContext _ctx; 
        //QUAN TRỌNG: ko new, CHỪNG NÀO XÀI Ở MỖI HÀM MỚI NEW
        //MỖI HÀM NEW LẠI NÓ 1 NHÁT CHO NHẤT QUÁN VIỆC QUẢN LÍ 
        //DỮ LIỆU CỦA CÁC TABLE

        //HÀM 1: SELECT * FROM AIRCON -> SHOW LÊN CÁI GRID
        public List<AirConditioner> GetAll()
        {
            //_ctx = new AirConditionerShopDbContext();
            _ctx = new(); //new ngắn gọn
            //return _ctx.AirConditioners.ToList();

            return _ctx.AirConditioners.Include("Supplier").ToList(); 

            //      vì cái túi gốc _bag trong DbContext nó là
            //  DbSet<AirCon> rất giống List<AirCon> nên ta cần convert về List<> để dùng.
            //  .ToList() chính là convert về List

        }

        //HÀM 2: INSERT INTO AIRCON VALUES (...) -> CREATE
        public void Create(AirConditioner obj)
        {
            _ctx = new(); //luôn new lại DbContext để đảm bảo tính đồng bộ trong ram và table
            _ctx.AirConditioners.Add(obj);
            _ctx.SaveChanges();  //LỆNH NÀY MỚI XUỐNG TABLE THẬT SỰ 
        }

        //HÀM 3: UPDATE AIRCON SET CỘT-X = VALUE-MỚI WHERE KEY = ?
        //                          -> UPDATE
        //                          
        public void Update(AirConditioner obj)
        {
            _ctx = new(); //luôn new lại DbContext để đảm bảo tính đồng bộ trong ram và table
            _ctx.AirConditioners.Update(obj);
            _ctx.SaveChanges();  //LỆNH NÀY MỚI XUỐNG TABLE THẬT SỰ 
        }

        //HÀM 4: DELETE FROM AIRCON WHERE KEY = ??? -> DELETE
        //các hàm trong Repo thường sẽ đặt tên rất ngắn gọn, vì nó rất gần Table, mà table thì có 4 lệnh cơ bản: 
        //INSERT into AirCon values(...)
        //UPDATE AirCon set cột-x = value-mới, cột-y = value-mới WHERE cột-key = key-dòng-muốn-update
        //DELETE FROM AIRCON WHERE cột-key = key-dòng-muốn-xoá
        //SELECT * FROM  -> GET ALL
        //SELECT * FROM AIRCON WHERE KEY = .... CỘT-KHÁC =... KEYWORD
        //                             -> TÌM KIẾM 1 DÒNG HAY NHIỀU DÒNG
        //TÊN HÀM TRONG REPO ĐẶT NGẮN GỌN GIỐNG NHƯ LỆNH SQL VÌ NÓ THAO TÁC TRÊN TABLE
        //TÊN HÀM TRONG SERVICE ĐẶT CHI TIẾT HƠN, RÕ RÀNG HƠN DO NÓ GẦN UI  / GẦN GUI, HƯỚNG VỀ NGƯỜI DÙNG

        //DELETE PHẢI NHỚ: KO WHERE LÀ TOANG TOÀN BỘ TABLE!!!
        //DELETE TRONG ORM / OBJECT RELATIONAL MAPPING, CHƠI CSDL STYLE OOP THÌ
        //HOẶC BẠN ĐƯA KEY ĐỂ XOÁ
        //HOẶC BẠN ĐƯA 1 OBJECT ĐỂ XOÁ, TRONG OBJECT CÓ KEY RỒI
        public void Delete(int key)
        {
           //thách thức danh hài, sao xoá
        } 

        public void Delete(AirConditioner obj)
        {
            _ctx = new(); //luôn new lại DbContext để đảm bảo tính đồng bộ trong ram và table
            _ctx.AirConditioners.Remove(obj);  //XOÁ TRONG RAM
            _ctx.SaveChanges();  //LỆNH NÀY MỚI XUỐNG TABLE THẬT SỰ 
        }


        //HÀM 5: SELECT * FROM AIRCON WHERE CỘT = ? 
        //                                  CỘT LIKE '%KEYWORD%' -> SEARCH
        //                                  
    }
}
