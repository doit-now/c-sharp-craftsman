﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                    !!!
    public class AccountService
    {
        private AccountRepo _repo = new(); //mình cần ai thì lưu số người đó, Service cần Repo thì phải có biến repo

        public StaffMember? Authenticate(string email)
        {
            return _repo.FindByEmail(email);
        }
        public StaffMember? Authenticate(string email, string pass)
        {
            return _repo.FindByEmailAndPassword(email, pass);
        }

    }
}
