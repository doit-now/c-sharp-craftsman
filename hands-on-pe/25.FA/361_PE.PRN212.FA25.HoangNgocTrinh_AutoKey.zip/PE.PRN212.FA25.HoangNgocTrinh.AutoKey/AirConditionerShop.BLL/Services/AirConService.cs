﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    public class AirConService
    {
        //                   BLL       DAL 
        //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
        //                   !!!
        //SERVICE CHỨA CÁC HÀM CUNG CẤP CHO BÊN GUI, CONTROLLER XÀI
        //        NÓ CẦN REPO TRỢ GIÚP, CHỨ KO BAY THẲNG XUỐNG DBCONTEXT
        //SERVICE PHẢI KHAI BÁO BIẾN REPO,
        //                      Y CHANG REPO KHAI BÁO BIẾN DBCONTEXT


        //@Autowire: ko cần new Repo, mà để nơi khác new, và nơi đó đưa object vào đây qua 3 cách: field = ; constructor =, setter =
        //NEW NƠI KHÁC TIÊM, CHÍCH, ĐƯA VÀO, INJECT (VERB), INJECTION (NOUN)
        //HIỆN TƯỢNG DEPENDENCY INJECTION
        //JAVA: NHÌN RÕ HƠN C# CÁI VỤ DI (DEPENDENCY INJECTION)
        //C#: GIẤU KĨ HƠN QUA FILE PROGRAM.CS, SERVICE BUILDER, NƠI NÀY NÓ NEW GIÙM MÌNH, ĐƯA VÀO CLASS NÀY CHO MÌNH
        //          NƠI NEW, ĐƯA VÀO CHO CLASS MÌNH XÀI: IoC Container
        //                   Inversion of Control Container

        private AirConRepo _repo = new(); //new luôn, vì DbContext đã đc new và kiểm soát bởi bên trong repo rồi, tính đóng gói!!!
                                          
        //KHAI BÁO BIẾN REPO VÀ NEW REPO()
        //

        //HÀM 1: GetAllAirCons()  chúng mình chỉ gọi Repo giúp
        public List<AirConditioner> GetAllAirCons()
        {
            return _repo.GetAll();
        }

        //HÀM 2: CreateAirCon()
        public void CreateAirCon(AirConditioner obj)
        {
            _repo.Create(obj);
        }

        //HÀM 3: UpdateAirCon()
        public void UpdateAirCon(AirConditioner obj)
        {
            _repo.Update(obj);
        }

        //HÀM 4: DeleteAirCon()
        public void DeleteAirCon(AirConditioner obj)
        {
            _repo.Delete(obj);
        }
       

        //HÀM 5: SearchAirConsBy()

        //HÀM 6 7 8: GỌI MOMO, GỌI FIREBASE, GỌI GHN..., TÍNH VOUCHER...
        //TÍNH TOÁN CÁC IF ELSE CỦA BUSINESS RULE


    }
}

//DI  -> SOLID