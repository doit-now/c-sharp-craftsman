﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                    !!!
    public class SupplierService
    {
        //DI, kì 7 ko ghi new, mà dùng DI 
        private SupplierRepo _repo = new();

        public List<SupplierCompany> GetAllSuppliers()
        {
            return _repo.GetAll();
        }
        
    }
}
