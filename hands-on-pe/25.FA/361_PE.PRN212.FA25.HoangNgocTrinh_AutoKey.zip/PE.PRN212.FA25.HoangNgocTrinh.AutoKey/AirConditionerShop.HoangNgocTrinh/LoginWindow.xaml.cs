﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //    !!!

    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {

        private AccountService _service = new(); 

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            //lấy email, pass đã gõ, gửi cho Service giúp, nó lại đi gọi Repo
            string email = EmailAddressTextBox.Text;
            string pass = PasswordTextBox.Text;

            //đề phòng ko gõ mà nhấn Login, chửi
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(pass))
            {
                MessageBox.Show("Both email and password are required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //đã có email và pass rồi, check coi có tồn tại hay ko
            StaffMember? acc = _service.Authenticate(email);
            //StaffMember? acc = _service.Authenticate(email, pass);

            if (acc == null)
            {
                MessageBox.Show("Email doesn't exist. Sign-up please!", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //xuống đây email tồn tại rồi, check pass
            if (acc.Password != pass)
            {
                MessageBox.Show("Invalidated password. Reset it, please!", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                //count++ số lần sai pass!!!
                return;
            }  //brute force tấn công dò pass

            //phân quyền 1 phần ở đây!!!
            //NẾU LÀ MEMBER, KO CHO VÀO APP, VÌ ĐÂY LÀ APP QUẢN LÍ
            //STAFF, ADMIN MỚI ĐC VÀO =>TUỲ ĐẦU BÀI SẼ ĐỔI ROLE
            //bài này mình ko cho manager role 3 vào
            if (acc.Role == 3)
            {
                MessageBox.Show("You have no permission to access!", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MainWindow main = new();

            //gửi role
            main.Role = acc.Role;

            main.Show();
            this.Hide(); //ẩn login, do nó chạy đầu tiên giống hàm Main() ko đc tắt

        }
    }
}
