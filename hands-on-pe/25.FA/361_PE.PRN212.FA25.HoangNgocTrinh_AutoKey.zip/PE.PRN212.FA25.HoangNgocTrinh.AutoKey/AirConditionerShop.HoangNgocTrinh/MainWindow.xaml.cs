﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //KHAI BÁO 1 PROPERTY ĐÊ HỨNG ROLE GỬI TỪ LOGIN SANG
        //BIẾN INT LÀ ROLE, HOẶC BIẾN STAFFMEMBER, THÌ PHẢI CHẤM ROLE
        //y chang EditedOne

        public int? Role { get; set; } //1 admin  2 staff  3 manager

        //                   BLL       DAL 
        //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
        //     !!!

        //@Autowire  Loose Coupling 
        //private AirConService _airService;  

        private AirConService _airService = new(); //new luôn mà ko sợ
        //KÌ 7, MÌNH KO THÈM NEW SERVICE, CHỈ KHAI BÁO VÀ XÀI
        //              KHAI BÁO MÀ KO THÈM NEW MÀ VẪN XÀI ĐC,
        //              CHẮC CHẮN PHẢI CÓ CHỖ NÀO ĐÓ, KHI NÀO ĐÓ NEW CHO MÌNH, ĐƯA NEW CHO MÌNH
        //KĨ THUẬT NEW, ĐƯA CHO MÌNH, GỌI LÀ DEPENDENCY INJECTION (DI)
        //TIÊM/CHÍCH/INJECT CÁI NEW VÀO CHO MÌNH, GỌI LÀ DI

        
        //OOP: KHAI BÁO BIẾN VÀ NEW THÌ MỚI ĐC XÀI,
        //XÀI: TỨC LÀ CHẤM ĐỂ GỌI TÊN HÀM


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //đổ vào lưới, nhưng phải nhờ trước AirConService giúp tui List<AirCon>, Service lại đi nhờ Repo, Repo lại nhờ DbContext

            AirConDataGrid.ItemsSource = _airService.GetAllAirCons();

            if (Role == 2)
            {   //staff đó cấm nút đi
                CreateButton.IsEnabled = false;
                UpdateButton.IsEnabled = false;
                DeleteButton.IsEnabled = false;
            }

        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //1. check xem đã click đúng dòng chưa
            //2. are you sure?
            //3. nhờ service xoá, service đi nhờ repo, repo đi nhờ DbContext
            //4. f5 grid qua hàm

            AirConditioner? selected = AirConDataGrid.SelectedItem as AirConditioner;

            if (selected == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }

            MessageBoxResult answer = MessageBox.Show("Are you sure?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer == MessageBoxResult.No)
            {
                return;
            }

            //xoá thật nè....
            //MessageBox.Show($"Xoá thật nè: {selected.AirConditionerId} {selected.AirConditionerName} {selected.FeatureFunction}");
            _airService.DeleteAirCon(selected);

            //F5 - REFRESH CÁI GRID ĐỂ THẤY DÒNG XOÁ ĐÃ MẤT
            //VIỆC REFRESH CÁI GRID NÀY XUẤT HIỆN Ở:
            //NÚT CREATE (THÊM MƠI THÌ PHẢI CHO THẤY ĐÃ THÊM)
            //NÚT UPDATE (SỬA THÌ PHẢI CHO THẤY INFO ĐÃ ĐC CHỈNH)
            //NÚT DELETE (MẤT DÒNG TRÊN GRID LUÔN)
            //NÚT SEARCH (LƯỚI PHẢI HIỂN THỊ 1 - N DÒNG SEARCH THẤY)
            //LOADED_ (MÀN HÌNH MỞ LÊN, LƯỚI PHẢI ĐC ĐỔ SẴN DATA)
            //TÁCH 1 HÀM CHỈ LO VIỆC ĐỔ INFO VÀO GRID -> HÀM HELPER - HÀM TRỢ GIÚP NỘI BỘ; GIÚP CODE TRONG SÁNG VỀ Ý NGHĨA
            FillDataGrid(_airService.GetAllAirCons());

        }

        public void FillDataGrid(List<AirConditioner> data)
        {
            AirConDataGrid.ItemsSource = null; //xoá data đang có nếu có
            AirConDataGrid.ItemsSource = data;
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            //1. check xem đã click đúng dòng chưa
            //2. chọn 1 dòng thÌ GỬI NÓ SANG MÀN HÌNH DETAIL -> HỌC RỒI
            //3. CHỈNH SỬA DATA BÊN MÀN HÌNH DETAIL, ĐÓNG LẠI
            //4. F5 CÁI GRID 

            AirConditioner? selected = AirConDataGrid.SelectedItem as AirConditioner;

            if (selected == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }

            DetailWindow detail = new();
            //GỬI SELECTED SANG             
            detail.EditedOne = selected;  //= _editedOne của Detail
            //3 chàng trỏ 1 nàng: EditedOne, selected, grid có 1 con trỏ -> trỏ vùng new AirCon đang cần edit!!!!
            detail.ShowDialog();

            //f5 lại cái grid
            FillDataGrid(_airService.GetAllAirCons());

        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            DetailWindow detail = new();          
            //KO CÓ VÀ KO CẦN GỬI EDITEDONE SANG DETAIL DO TẠO MỚI
            //THÌ ĐỂ MÀN HÌNH BÊN DETAIL TRỐNG TRƠN CHỜ NHẬP VÀO!!!

            detail.ShowDialog();
            
            //f5 lại cái grid
            FillDataGrid(_airService.GetAllAirCons());
        }
    }
}

//SOLID:  ROBERT C. MARTIN -> CLEAN CODE 
//               BAD SMELLS