﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    /// 
     //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //      !!!
    public partial class DetailWindow : Window
    {
        //private AirConditioner _editedOne; //= selected bên Main, gán vào qua hàm Set() -> thay = property 
        public AirConditioner EditedOne { get; set; }

        //cần 2 service bên detail
        //SupplierSerive dành cho treo đầu dê
        //AirConService dành cho nút [Save] -> create, update AirCon
        private AirConService _airService = new(); //new luôn  nút Save
        private SupplierService _supService = new(); //treo đầu de

        public DetailWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // chẳng quan tâm mode, phải đổ vào combo cả 2 mode
            //tạo mới cx chọn, edit cũng chọn NCC
            SupplierIdComboBox.ItemsSource = _supService.GetAllSuppliers();
            //thằng combo giống data grid là show nhiều dòng
            //nhưng grid show all cột, thằng combo chỉ show 1 cột
            SupplierIdComboBox.DisplayMemberPath = "SupplierName"; //treo đầu dê
            SupplierIdComboBox.SelectedValuePath = "SupplierId"; //lấy thịt heo

            //KHOÁ Ô ID DÙ TẠO MỚI HAY LÀ EDIT, DO KEY TỰ TĂNG
            //KEY TỰ TĂNG, Ô ID BỎ TRỐNG, KO CHO GÕ KHI CREATE MODE
            //KEY TỰ TĂNG, VẪN GÁN GIÁ TRỊ Ở MODE EDIT, NHƯNG CẤM SỬA KHI EDIT LUÔN.
            //CẤM SỬA, CẤM GÕ ID PHẢI NẰM NGOÀI IF
            AirConditionerIdTextBox.IsEnabled = false; 

            //lưu ý: biến EditedOne chính là biến flag, biến cờ đánh dấu trạng thái, mode của màn hình này
            //nếu biến này == null, tạo mới, vì ko có selected đc gửi sang!!!
            //khác null là do đi từ nút bấm [Update], thì có gửi sang selected 
            //MÌNH DÙNG BIẾN NÀY ĐỂ BIẾT KHI NÀO CREATE, KHI NÀO UPDATE KHI NHẤN NÚT [SAVE] DO MÀN HÌNH NÀY XÀI CHUNG CHO TẠO MỚI VÀ UPDATA
            if (EditedOne != null)
            {  //edit mode
                DetailWindowMode.Content = "Sửa thông tin đi em";
                //đổ info từ object vào các ô nhập, học rồi
                AirConditionerIdTextBox.Text = EditedOne.AirConditionerId.ToString(); //chữ và số phải convert mới gán vào đc

                //KHOÁ Ô ID LẠI
                //AirConditionerIdTextBox.IsEnabled = false; //ko cho sửa key
                
                AirConditionerNameTextBox.Text = EditedOne.AirConditionerName;
                QuantityTextBox.Text = EditedOne.Quantity.ToString();
                DollarPriceTextBox.Text = EditedOne.DollarPrice.ToString();
                WarrantyTextBox.Text = EditedOne.Warranty;
                SoundPressureLevelTextBox.Text = EditedOne.SoundPressureLevel;
                FeatureFunctionTextBox.Text = EditedOne.FeatureFunction;

                //GÁN NGÀY THÁNG CHO Ô NHẬP MANU DATE
                ManuDateDatePicker.Text = EditedOne.ManufacturedDate.ToString();

                //lát hồi lấy ngày mới chọn thì dùng: .SelectedDate

                //NHẢY ĐẾN ĐÚNG CATE, ĐÚNG HÃNG SX MÀ SẢN PHẨM THUỘC VỀ
                SupplierIdComboBox.SelectedValue = EditedOne.SupplierId;

                //CÒN CÁI FK, KO SHOW FK VÀO Ô TEXT, MÀ SHOW QUA TREO ĐẦU DÊ BÁN THỊT HEO
                //VÌ CATEGORY, HAY NHÀ SẢN XUẤT, NHÀ CUNG CẤP LÀ 1 BẢNG KHÁC
                //id | name | quantity | price | ... | mã-hãng-sản-xuất FK
                //                                            H1
                //                                            H2
                //MÌNH PHẢI SHOW CÁI COMBOBOX, CHỨA CHỮ SAMSUNG, TOSHIBA, DAIKIN
                //NHƯNG KHI CHỌN SAMSUNG, THÌ LẤY H1 CẤT VÀO FK


                //id mã hãng sx | name  tên hãng sx | country - quốc gia |
                //   H1             SAMSUNG               HÀN QUỐC
                //   H2             TOSHIBA               NHẬT BẢN
                //   H3             DAIKIN                NHẬT BẢN
            }
            else
            {  //create mode
                DetailWindowMode.Content = "Tạo mới đi em";
            }
        }


        private bool CheckVar()
        {
            //Toàn bộ các lệnh kiểm tra tính hợp lệ của các ô nhập -> đề thi yêu cầu: ko ô nào đc bỏ trống
            //name thì từ 5...50 chacracter, số từ 50...100...
            //sai cái nào chửi cái đó, return false ngay!!!
            //check required, ô nhập đã gõ chưa, chưa quan tâm gõ đúng hay ko, ta dùng hàm: string.IsNullOrWhiteSpace()
            //if (string.IsNullOrWhiteSpace(AirConditionerIdTextBox.Text))
            //{
            //    MessageBox.Show("Id is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return false; //ko nhập id, chửi, thoát hàm, ko cho save ở bên btnSave
            //}

            if (string.IsNullOrWhiteSpace(AirConditionerNameTextBox.Text))
            {
                MessageBox.Show("Name is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; //ko nhập id, chửi, thoát hàm, ko cho save ở bên btnSave
            }

            int len = AirConditionerNameTextBox.Text.Length;
            //lấy ra chiều dài của 1 chuỗi, chỉ việc lấy biến chuỗi chấm Length
            if (len < 5 || len > 50)
            {
                MessageBox.Show("Name must be 5 to 50 characters length!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; //ko nhập id, chửi, thoát hàm, ko cho save ở bên btnSave
            }

            //ngày tháng nhập vào ko vượt quá ngày hiện hành
            //C# so sánh ngày tháng dùng > >= < <= do nó đã cố tình cài đặt phép so sánh này vốn chỉ dành cho primitive, nhưng nay dành cho DataTime xài đc luôn. Lẽ ra phải dùng hàm chấm
            //vì DateTime là object
            //Java nghiêm ngặt hơn, ko cho xài > < ==, C# phóng túng hơn
            //nhưng bản chất vẫn là object so sánh với nhau
            //áp dụng luôn cho string trong C#, xài == luôn, Java cấm
            //nhưng bản chất hậu trường là như nhau

            if (ManuDateDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Manu date is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; //ko nhập id, chửi, thoát hàm, ko cho save ở bên btnSave
            }
            //nhập rồi, cấm vượt qua ngày hôm nay
            if (ManuDateDatePicker.SelectedDate >= DateTime.Today)
            {
                MessageBox.Show("Manu date must be less than today!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false; //ko nhập id, chửi, thoát hàm, ko cho save ở bên btnSave
            }

            //Quantity [__________], gõ ngoc trinh ->
            //                          int.Parse("ngoc trinh") sẽ bị Exception
            //                          phải bắt try catch
            //inline   <span style="color:red;font-weight:bold;">Ahihi</span>
            //int.TryParse(chuỗi-cần-convert, out int result)  -> true / false để nói rằng kí tự gõ vào đúng là số hay ko, convert đc hay ko, ko cần try catch

            bool convertedStatus;  //lưu trạng thái convert chữ thành số
            convertedStatus = int.TryParse(QuantityTextBox.Text, out int quantity);
            //if (convertedStatus == false)
            if (!convertedStatus)
            {
                MessageBox.Show("Quantity must be an integer number!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            //gõ số đàng hoàng rồi, coi xem có là từ 100...200 hem?
            if (quantity < 100 || quantity > 200)
            {
                MessageBox.Show("Quantity must be an integer number between 100...200!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //CHATGPT: KIỂM TRA 1 Ô NHẬP BẮT BUỘC PHẢI LÀ SỐ
            //BƯỚC 1: ĐẢM BẢO NHẬP SỐ
            //HÀM  int.Parse() nguy hiểm -> ném ra ngoại lệ khi nó convert chữ số. Java y chang -> phải try catch
            // int.TryParse() ko ném ngoại lệ, nhưng cách dùng phức tạp hơn 1 xíu...

            //BƯỚC 2: ĐẢM BẢO SỐ > MIN VÀ < MAX
            //IF (num < 5 || num > 100) thì MessageBox...

            return true;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {

            //check var phải check trước khi save xuống table
            //if (CheckVar() == false)
            //{
            //    return; //vi phạm việc nhập dữ liệu -> thoát, ko save, chửi trong hàm check var
            //}

            //     TRUE        FALSE  -> FALSE
            //     FALSE       FALSE  -> TRUE
            if (!CheckVar())
            {
                return; //vi phạm việc nhập dữ liệu -> thoát, ko save, chửi trong hàm check var
            }


            //BẠN GÕ GÌ TRÊN MÀN HÌNH, TỚ CẤT HẾT VÀO OBJECT AIRCON
            AirConditioner obj = new() { };

            if (EditedOne != null)
            {   //edit mode thì ta lấy id của ô nhập đập ngược trở lại object
                //để where trên id này
                obj.AirConditionerId = int.Parse(AirConditionerIdTextBox.Text);
            }
            //tạo mới thì field id hok đc gán giá trị!!!!!!!!!!! để tự tăng
            
            obj.Quantity = int.Parse(QuantityTextBox.Text);
            obj.DollarPrice = double.Parse(DollarPriceTextBox.Text);
            obj.Warranty = WarrantyTextBox.Text;
            obj.SoundPressureLevel = SoundPressureLevelTextBox.Text;
            obj.FeatureFunction = FeatureFunctionTextBox.Text;
            obj.AirConditionerName = AirConditionerNameTextBox.Text;
            obj.ManufacturedDate = ManuDateDatePicker.SelectedDate;
            //gán vào cuốn lịch thì .Text, lấy ra thì .SelectedData

            //CÁI CUỐI KHOÁ NGOẠI lấy thịt heo
            obj.SupplierId = (string)SupplierIdComboBox.SelectedValue;

            if (EditedOne == null)
            {
                _airService.CreateAirCon(obj);
            }
            else
            {
                _airService.UpdateAirCon(obj);
            }
            this.Close();
            
        }
    }
}
