﻿using AirConditionerShop.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //Mantra:
    //             3 LAYERS -> SAI, VÌ LÀ ĐẾM TẦNG
    //             3-LAYER -> KHÁI NIỆM THUẬT NGỮ 3-LAYER ARCHITECTURE 
    //                   BLL       DAL     --------DB---------  
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                             !!!
    public class AirConRepo
    {
        //class này sẽ lo việc CRUD TABLE AIRCON
        //ĐỂ CRUD TABLE, THÌ CẦN DBCONTEXT, TỨC LÀ KHAI BÁO BIẾN VÀ NEW

        private AirConditionerShopDbautoKeyContext _ctx;
        //ko new, vì thằng DbContext nó quản lí data từ ram vào table
        //mỗi hành động trên table, cần new lại _ctx để đảm bảo tính đồng bộ data 

        //HÀM 1: SELECT * FROM AIRCON -> GetAll() lấy hết bảng, để show
        //                                ra trên cái Grid
        public List<AirConditioner> GetAll()
        {
            //_ctx = new AirConditionerShopDbContext();
            _ctx = new(); //new ngắn
            //sờ cái túi ứng với select *
            //return _ctx.AirConditioners.ToList();  //_bag trả về, đang gọi qua property
            //       DbSet<AirCon> rất giống List<AirCon>, ta cần convert về List để dùng dễ dàng
            return _ctx.AirConditioners.Include("Supplier").ToList();
            //                      join với bảng 1-N
            //                      1 máy lạnh phải thuộc về NCC  
            //                      field móc sang NCC

        }

        public void Create(AirConditioner obj)
        {
            //obj.AirConditionerId //key
            _ctx = new();
            _ctx.AirConditioners.Add(obj);  //xoá object trong túi trong ram
            _ctx.SaveChanges();     //xuống table thật sự

        }

        //HÀM 2: UPDATE AIRCON SET CỘT-X = VALUE? WHERE ID = ???
        //         -> Update(???)  update phải nhớ where key!!!!!!!!!!
        public void Update(AirConditioner obj)
        {
            //obj.AirConditionerId //key
            _ctx = new();
            _ctx.AirConditioners.Update(obj);  //xoá object trong túi trong ram
            _ctx.SaveChanges();     //xuống table thật sự

        }

        //HÀM 3: DELETE FROM AIRCON WHERE KEY = ?
        //          -> Delete(???) delete phải nhớ where key!!!!!!!!
        //cách đặt tên hàm trong repo thường ngắn gọn, cô đọng, vì nó gần mức database, mà database và table xưa nay chỉ có 4 động từ
        //insert, update, delete, select
        //bên service thường đặt tên hàm dài hơn, gần gũi hơn mức user, mức gui
        //Delete()            DeleteAirCon()
        //Update()            UpdateAirCon()
        //GetAll()            GetAllAirCons()
        //FindBy()            FindAirConsById()
        //FindById()         
        public void Delete(int key)  //hàm xoá 1 máy lạnh theo key
        {
            //DELETE VÀ UPDATE LÀ 2 LỆNH NGUY HIỂM!
            //ẢNH HƯỞNG TOÀN BỘ TABLE NẾU THIẾU WHERE!!!
            //HÀM TRÊN VIẾT CODE THẾ NÀO: VỀ NHÀ SUY NGHĨ NẾU HIỂU OOP TỐT THÌ THÊM 1 LỆNH SO VỚI HÀM DƯỚI!!!!!!!!!!!!!!!!!!!!!!!!!!

        }

        public void Delete(AirConditioner obj)
        {
            //obj.AirConditionerId //key
            _ctx = new();
            _ctx.AirConditioners.Remove(obj);  //xoá object trong túi trong ram
            _ctx.SaveChanges();     //xuống table thật sự

        }

        //HÀM 4: SELECT * FROM AIRCON WHERE CỘT-X = KEYWORD
        //            CỘT-X LIKE '%KEYWORD' 
        // -> SearchBy(??? keyword)




    }
}
