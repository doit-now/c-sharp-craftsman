﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //Mantra:
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                             !!!
    public class AccountRepo
    {
        //CLASS NÀY SẼ CRUD TABLE ACCOUNT, STAFFMEMBER!!!!!!!!!!!!!!
        //SWP THÌ PHẢI LÀM VẬY
        //PE KO ĐỦ THỜI GIAN, NÊN KO LÀM CRUD USER/ACCOUNT
        //MÀ CHỈ LÀM LOGIN LÀ ĐỦ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        private AirConditionerShopDbautoKeyContext _ctx; //ko new còn nhớ hem?

        //trả về 1 account nếu login thành công, hoặc trả null để nói rằng tìm hok thấy 1 dòng account trong table!!!!

        public StaffMember? FindByEmail(string email)
        {
            //1 cái túi của DbContext ứng với 1 table
            //_ctx.SupplierCompanies   sờ túi thấy đc tất cả món đồ, nsx   
            //_ctx.AirConditioners    lấy đc hết máy lạnh
            //_ctx.StaffMembers       lấy đc hết member/account
            //                        .Add()  .Remove()  .Update()
            //                        .Where(đk where đề lấy ra các món
            //                               thoả tiêu chí nào đó) -> trả về
            //                        nhiều dòng thoả đk -> hàm search
            //                        .FirstOrDefault(đk lọc)
            //                        trả về 1 dòng duy nhất thoả đk, hoặc trả về
            //                        null nếu ko thoả     
            //                        -> dùng cho login, dùng cho edit, lôi
            //                           ra 1 dòng để: login, edit!!!
            //dk lọc, đk where DÙNG BIỂU THỨC LAMBDA!!!
            _ctx = new(); //DbContext đc new khi xài, đừng quên bên Repo

            return _ctx.StaffMembers.FirstOrDefault(nt => nt.EmailAddress == email);
        }

        public StaffMember? FindByEmailAndPassword(string email, string pass)
        {
            return _ctx.StaffMembers.FirstOrDefault(nt => nt.EmailAddress == email && nt.Password == pass);
        }

        //TRONG JAVA, SO SÁNH 2 CHUỖI KO ĐC DÙNG == VÌ LÀ OBJECT, PHẢI GỌI HÀM
        //msg.Equals("Hello")  msg.EqualIgnoreCase(msg2)
        //TRONG C# NÓ ĐÃ ĐỘ LẠI == ĐỂ DÙNG ĐC VỚI STRING, NHƯNG HẬU TRƯỜNG THÌ Y CHANG JAVA, VIẾT GỌN HƠN JAVA, XỬ LÍ THÌ GIỐNG NHAU
        //if (msg1 == msg2)    if (msg1.Equals(msg2))
        //   C#                       Java   
    }
}
