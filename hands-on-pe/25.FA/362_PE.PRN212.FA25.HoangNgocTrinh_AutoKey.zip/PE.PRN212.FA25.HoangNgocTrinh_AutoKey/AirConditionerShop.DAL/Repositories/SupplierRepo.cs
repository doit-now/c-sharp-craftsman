﻿using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.DAL.Repositories
{
    //                   BLL       DAL     --------DB---------  
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                             !!!
    public class SupplierRepo  //NHÀ SẢN XUẤT, NHÀ CUNG CẤP
    {                          //ID, NAME (DAIKIN, SAMSUNG), COUNTRY 
        private AirConditionerShopDbautoKeyContext _ctx; //ko new mà xài mới new

        public List<SupplierCompany> GetAll()
        {
            //trả về full NCC để treo đầu dê
            _ctx = new();  //NEW KHI XÀI
            return _ctx.SupplierCompanies.ToList(); //SỜ GIỎ LÀ LẤY ĐC FULLL
        }
    }
}
