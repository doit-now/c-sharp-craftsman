﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //Mantra:
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                   !!!
    public class AccountService
    {
        //gọi lại repo login giúp bằng cách đưa cho nó email, pass tuỳ xài cách login nào
        //Service cần Repo thì khai báo và new biến Repo
        private AccountRepo _repo = new(); //new luôn hoặc DI


        //login dùng email và (hoặc) pass để lấy về 1 account nếu match, hoặc null
        public StaffMember? Authenticate(string email)
        {
            return _repo.FindByEmail(email);
        }

        public StaffMember? Authenticate(string email, string pass)
        {
            return _repo.FindByEmailAndPassword(email, pass);
        }

    }
}
