﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //                   BLL       DAL     --------DB---------  
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                   !!!
    public class SupplierService
    {
        private SupplierRepo _repo = new();  //new luôn ko sợ do repo nó bao new rồi

        public List<SupplierCompany> GetAllSuplliers()
        {
            return _repo.GetAll();
        }
    }
}
