﻿using AirConditionerShop.DAL.Entities;
using AirConditionerShop.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirConditionerShop.BLL.Services
{
    //                   BLL       DAL     --------DB---------  
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //                    !!!
    //CUNG CẤP CÁC HÀM CHỨA DATA CHO API, CHO GUI
    //CÁC HÀM CŨNG BAO GỒM CRUD CỦA TABLE TƯƠNG ỨNG
    //GetAllAirCons() | CreateAirCon() | UpdateAirCon()
    //DeleteAirCon() | SearchAirConsBy(keyword)

    //GỌI MOMO, GỌI GHN, TÍNH VOUCHER, TÍNH KHTT
    //CÀI CÁC BUSINESS RULE (IF ELSE TRONG CODE MÀN HÌNH)

    public class AirConService
    {
        //KÌ 7, HOẶC AI ĐÃ ĐANG LÀM API CỦA C#; THÌ CHỖ NÀY MÌNH KO NEW 
        //MÀ ĐỂ RUNTIME TỰ NEW GIÚP, NEW XONG, NÓ GỬI CÁI NEW CHO MÌNH Ở ĐÂY XÀI
        //ĐƯA VÀO, CHÍCH, TIÊM, INJECT
        //KĨ THUẬT KHAI BÁO BIẾN, HOK THÈM NEW, ĐỂ RUNTIME, THƯ VIỆN KHÁC NEW GIÚP ĐƯA VÀO, GỌI LÀ DEPENDENCY INJECTION


        //OOP 100 NĂM NAY: KHAI BÁO BIẾN THUỘC CLASS VÀ NEW ĐỂ CÓ OBJECT
        //                 CÓ OBJECT THÌ CHẤM ĐỂ GỌI HÀM
        //                 Student s = new Student() {} 
        //                         s.GetYob()  s.ShowProfile()   s.Yob

        //@Autowire: tự new và tiêm vào!!!!!!!!!! 
        private AirConRepo _repo = new(); 
        //new trực tiếp 1 object của class khác mình tự viết
        //đc gọi là tight-coupling, phụ thuộc người khác chặt chẽ
        //ko tốt khi nâng cấp code sau này...
        //có 1 kĩ thuật, new nơi khác, và đưa vùng new đó vào biến
        // _repo bên trong class mình
        //đưa vào, tiêm vào, chích vào, inject (verb), injection (noun)
        //kĩ thuật viết code mà chích tiêm object từ ngoài vào class mình viết gọi là: DI - DEPENDENCY INJECTION
        //NƠI MÀ NÓ NEW GIÚP, BÀI NEW REPO GIÚP, SAU ĐÓ TÌM CÁCH ĐƯA VÀO CLASS MÌNH, THÌ NƠI ĐÓ GỌI LÀ: IoC Container
        //                       Inversion of Control Container
        //thùng chứa các object và đảo ngược tư duy kiểm soát object
        //Bên Java, kĩ thuật DI nhìn rõ hơn bên C#
        //Java: @Autowire
        //C#  : khai báo ở trong Program.cs, Service Builder, thuốc cần chích tập trung ở 1 nơi!!!!!!!!!! SWP XÀI API SẼ THẤY
        //3 CÁCH TIÊM: TIÊM QUA FIELD - FIELD INJECTION
        //             TIÊM QUA CONSTRUCTOR, TIÊM QUA SETTER!!!!!!!
        //             

                    //new luôn, khác bên Repo thì ko new luôn DbContext
                    //ko sợ ảnh hưởng việc new DbContext do lúc này
                    //phần quản lí DbContext nằm tít sâu trong repo
                    //service đứng ngoài repo gọi hàm repo, hàm repo đã kiểm soá DbContext ổn rồi -> tính đóng gói!!! nhìn bên ngoài, ko chi tiết bên trong

        public List<AirConditioner> GetAllAirCons()
        {
            return _repo.GetAll(); //gọi repo giúp
                                   //repo lại đi gọi DbContext
                                   
        }
        //tên hàm đặt chi tiết hơn so với Repo
        //service gọi repo
        public void CreateAirCon(AirConditioner obj)
        {
            _repo.Create(obj);
        }

        public void UpdateAirCon(AirConditioner obj)
        {
            _repo.Update(obj);
        }

        public void DeleteAirCon(AirConditioner obj)
        {
            _repo.Delete(obj);
        }

        //CÒN HÀM LIÊN QUAN 3RD PARTY - BÊN THỨ 3 NHƯ MOMO, VNPAY, GHN, GHTK, UPLOAD FIREBASE... -> SERVICE TỒN TẠI VÌ Ý NGHĨA NÀY!!!!!!!!!!!
    }
}
