﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for DetailWindow.xaml
    /// </summary>
    public partial class DetailWindow : Window
    {
        //                   BLL       DAL     --------DB---------  
        //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
        //     !!!

        //2 service luôn???
        private AirConService _airService = new(); //cần cho nút save, save máy lạnh
        private SupplierService _supplierService = new(); //cần treo đầu dê
                                                 

        //private AirConditioner _editedOne; //làm hàm set để bên Main gọi và gán vào, y chang SetYob(...) _biến = 
        //hàm Set + _backign field thì thay bằng Property

        public AirConditioner EditedOne { get; set; }
        //biến flag phất cờ new hoặc edit mode
        //nếu nó null tức là new, new là mình trống, cần gì gửi từ main
        //nếu edit mode, thì phải gửi selected sang đây, not null
        //ko có biến này thì nhấn nút [SAVE] SAO BIẾT INSERT HAY UPDATE XUỐNG TABLE

        public DetailWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            //ko care edit mode hay new mode, đổ vào treo đầu dê, ngay từ đầu ngoài if
            SupplierIdComboBox.ItemsSource = _supplierService.GetAllSuplliers();
            //chọn treo đầu dê
            SupplierIdComboBox.DisplayMemberPath = "SupplierName";
            //lấy thịt heo, cất id vào 1 property để dành
            //chọn name hay country cất id để dành đưa FK cho AirCon
            SupplierIdComboBox.SelectedValuePath = "SupplierId";

            AirConditionerIdTextBox.IsEnabled = false; //khoá ko cho sửa id ở edit mode
            //DÙ EDIT HAY TẠO MỚI, THÌ ĐỀU LOCK CÁI Ô NHẬP ID KO CHO GÕ
            //TẠO MỚI: ĐỂ TRỐNG ID
            //EDIT: CÓ ID GỬI TỪ MAIN SANG
            //2 TÌNH HUỐNG ĐỀU KHOÁ Ô ID KO CHO GÕ, KO CHO SỬA
            //VÌ LÀ KEY TỰ TĂNG THÌ KO CẦN GÕ LÚC TẠO MỚI
            //LÚC EDIT THÌ CÓ SẴN KEY RỒI ĐỀ WHERE UPDATE, VÀ DĨ NHIÊN CẤM SỬA KEY ĐANG CÓ
            //DẶT CÂU LỆNH .ISENABLED = FALSE NẰM NGOÀI IF ELSE VÌ LÝ DO NÀY


            //kiểm tra biến flag để biết mode nào?
            if (EditedOne != null)
            {  //edit mode
                DetailWindowModeLabel.Content = "Chỉnh sửa sản phẩm đi em";
                //fill data vào các ô edit

                AirConditionerIdTextBox.Text = EditedOne.AirConditionerId.ToString();  //vì key là số int, mà ô nhập là text, phải convert

                //AirConditionerIdTextBox.IsEnabled = false; //khoá ko cho sửa id ở edit mode

                AirConditionerNameTextBox.Text = EditedOne.AirConditionerName;
                WarrantyTextBox.Text = EditedOne.Warranty;
                FeatureFunctionTextBox.Text = EditedOne.FeatureFunction;
                QuantityTextBox.Text = EditedOne.Quantity.ToString(); //do text và int khác kiểu
                DollarPriceTextBox.Text = EditedOne.DollarPrice.ToString();
                SoundPressureLevelTextBox.Text = EditedOne.SoundPressureLevel;

                //DATETIME: ĐỔ VÀO Ô DATETIME .TEXT
                //          LẤY NGÀY ĐÃ CHỌN TỪ CUỐN LỊCH .SELETECEDDATE
                ManuDateDatePicker.Text = EditedOne.ManufacturedDate.ToString();

                //FK NÈ EM, CỘT EditedOne.SupplierId KO CÓ Ô NHẬP ĐỂ ĐỔ VÀO
                //VÌ NÓ LÀ DANH SÁCH TREO ĐẦU DÊ LẤY THỊT HEO
                //NHẢY ĐÚNG CATEGORY, NHẢY ĐÚNG NSX
                SupplierIdComboBox.SelectedValue = EditedOne.SupplierId; 


                //ID | NAME | QUANTITY | PRICE | ... | MÃ NHÀ SẢN XUẤT SUPPLIER-ID
                //                                         11     FK                  
                //                                         21     FK
                //                                         31     FK

                //NCC/NSX
                //PK
                //ID     | NAME           | DESC         | COUNTRY
                //11        SAMSUNG                         KOREA
                //21        TOSHIBA                         JAPAN
                //31        DAIKIN                          JAPAN


            }
            else
            {  //new mode
                DetailWindowModeLabel.Content = "Tạo mới sản phẩm đi em";


            }
        }


        private bool CheckVar()
        {
            //đề thi yêu cầu: các field phải đc nhập, ko đc bỏ trống
            //chuỗi phải dài từ min đến max, 5 đến 50 kí tự
            //số thì phải từ đoạn 100 đến 200
            //check chuỗi có nhập hay ko có 2 hàm:
            
            //string.IsNullOrWEmpty(NameTextBox.Text)  strinng.IsNullOrWhiteSpace(NameTextBox.Text)

            //whitespace: gồm kí tự dấu cách, dấu tab
            //mình sẽ coi rằng gõ trắng hay gõ tab cx như chưa gõ, chửi
            //check length của chuỗi thì dùng biến string chấm Length
            
            //NameTextBox.Text.Length -> chiều dài chuỗi đã gõ

            //check số thì khó hơn 1 chút, giống Java
            
            //int.Parse(chuỗi convert thành số) -> ném ra ngoại lệ
            //nếu đưa chuỗi Ahihi, Ngọc Trinh -> convert ko đc
            //code viết có bắt ngoại lệ nó dài...

            //dùng hàm đặc biệt hơn int.TryParse(......)
            //hàm này ko ném ngoại lệ, code dài hơn nhưng gọn hơn

            //THUẬT TOÁN HÀM CHECKVAR, CHECK TỪNG Ô 1, SAI ĐẾN ĐÂU CHỬ ĐẾN ĐÓ, VÀ RETURN HÀM SỚM, NGAY KHI GẶP ERROR

            //CUỐI CÙNG CỦA HÀM, RETURN TRUE, VÌ SỐNG SÓT ĐC TẤT CẢ CÁC CHECK VAR Ở MỖI Ô NHẬP

            //ID TỰ TĂNG THÌ KO CẦN NHẬP ID NỮA!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //if (string.IsNullOrWhiteSpace(AirConditionerIdTextBox.Text))
            //{
            //    MessageBox.Show("Id is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return false;
            //}

            if (string.IsNullOrWhiteSpace(AirConditionerNameTextBox.Text))
            {
                MessageBox.Show("Name is required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            int len = AirConditionerNameTextBox.Text.Length;
            if (len < 5 || len > 50)
            {
                MessageBox.Show("Name must be in 5 to 50 characters length", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //về tự làm nốt...
            //CHECK VAR NGÀY THÁNG: KO ĐC BỎ TRỐNG, KO CHO PHÉP > NGÀY HIỆN TẠI
            //DATETIME TRONG C# VÀ JAVA GIỐNG NHAU, ĐỀU LÀ OBJECT
            //MUỐN SO SÁNH NGÀY VỚI NGÀY PHẢI DÙNG DẤU . GỌI HÀM SO SÁNH!!!
            //hoang == kiet ko đc, vì là object
            //hoang.equals(kiet)  -> trên yob, salary...
            //obj so sánh với nhau thì phải so trên cái gì, tức là chấm bên trong object
            //ngày tháng cũng chấm, chuỗi cũng chấm, chó mèo cũng chấm...
            //TUY NHIÊN, C# NÓ ĐỘ CÁI HÀM SO SÁNH THEO STYLE ĐƠN GIẢN ĐỂ DỄ VIẾT, VIẾT NHANH, TIỆN DỤNG, CHỨ BẢN CHẤT VẪN LÀ CHẤM BÊN TRONG NHƯ JAVA
            //C# CHO PHÉP DÙNG > >= < <= == VỚI DATETIME VÀ STRING LUÔN
            //JAVA KO CHO STYLE NÀY
            //NHƯNG PHÍA HẬU TRƯỜNG 2 THẰNG NHƯ NHAU
            if (ManuDateDatePicker.SelectedDate == null)
            {

                MessageBox.Show("Manu date is required", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (ManuDateDatePicker.SelectedDate >= DateTime.Today)
            { //ngày sx phải bé hơn ngày hiện hành

                MessageBox.Show("Manu date must be less than the current day!!!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //BẮT VALIDATION CHO CON SỐ PHẢI NẰM TRONG ĐOẠN X...Y, VÍ DỤ QUANTITY PHẢI TỪ 100...200
            //CÓ 2 KĨ THUẬT:
            //VÌ Ô NHẬP QUANTITY [___________] LÀ TEXT, NÊN TA PHẢI CONVERT NÓ VỀ SỐ
            //                       100 OK
            //                      NGOC TRINH -> CHỬI
            //                       3.14  -> DO MÌNH CẦN SỐ NGUYÊN
            //CONVERT TỪ CHỮ CHUỖI -> SỐ DÙNG  .Parse()
            //                                 .TryParse()
            //int.Parse(chuỗi cần convert) -> số trả về
            //double.Parse(chuỗi cần convert) -> số trả về
            //nếu convert ko thành công, C# ném re exception, code an toàn phải try-catch
            //nếu ko app sập khi user gõ sai do vô tình, hay cố tình

            //                                khai báo biến inline
            //                                
            //int.TryParse(chuỗi cần convert, out int result) -> true/false convert đc hay ko
            //double.TryParse(chuỗi cân convert, out double result)  -> true/false
            //ko ném về try-catch
            bool convertedResult;
            convertedResult = int.TryParse(QuantityTextBox.Text, out int quantity);
            if (convertedResult == false)
            { //convert quantity đã gõ hok đc, chửi
                MessageBox.Show("Quantity must be an integer", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            //gõ tử tế rồi, check range 100...200
            if (quantity < 100 || quantity > 200)
            { //quantity nằm ngoài range, chửi
                MessageBox.Show("Quantity must be an integer between 100...200", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            //VỀ NHÀ LÀM TƯƠNG TỰ CHO PRICE



            return true;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {

            //CHECK VAR TRƯỚC KHI SAVE XUỐNG DB

            if (!CheckVar()) //pro, vì if cần 1 cái true để chạy, hàm 
               return;      //mình gọi CheckVar() có sẵn true/false
            //if else chỉ có 1 lệnh thì đc quyền bỏ ngoặc { }

            //if (CheckVar() == false)
            //{
            //    return; //quy ước hàm trả false nghĩa là đang vi phạm việc nhập, vượt qua check var - true nghĩa là nhập tử tế thì chạy xuống dưới 
            //}

            //TẠO MỚI OBJECT
            //SET TOÀN BỘ VALUE CHO CÁC CỘT CỦA OBJECT TỪ MÀN HÌNH ĐỔ NGƯỢC VÔ
            //MỞ MÀN HÌNH:  OBJECT ---> ĐỔ VÀO Ô NHẬP
            //SAVE          Ô NHẬP ---> ĐỔ VÀO OBJECT
            //GỬI OBJECT CHO HÀM CREATE() UPDATE() CỦA SERVICE
            //                                                    REPO  -> DBCONTEXT

            AirConditioner obj = new() { }; //tui ko viết object initializer

            if (EditedOne != null) //EDIT MODE THÌ LẤY ID TỪ Ô NHẬP GÁN VÀO OBJECT
            {                      //NEW MODE KO LÀM
                obj.AirConditionerId = int.Parse(AirConditionerIdTextBox.Text);
            }
            //OBJECT CHUẨN BỊ ĐEM XUỐNG TABLE CÓ 2 TÌNH HUỐNG
            //OBJECT TẠO MỚI, TA BỎ TRỐNG ID, CHỈ SETTER NHỮNG FIELD CÒN LẠI
            //OBJECT EDIT, TA FILL ALL FIELD, KỂ CẢ ID, VÌ THIẾU ID SAO UPDATE, HOẶC TOÀN BỘ TABLE GIỐNG NHAU!!!!!!!!!!!!!!!!!!!

            obj.AirConditionerName = AirConditionerNameTextBox.Text ;
            obj.Warranty = WarrantyTextBox.Text;
            obj.SoundPressureLevel = SoundPressureLevelTextBox.Text;
            obj.FeatureFunction = FeatureFunctionTextBox.Text;
            obj.Quantity = int.Parse(QuantityTextBox.Text);
            obj.DollarPrice = double.Parse(DollarPriceTextBox.Text);

            //GÁN NGÀY THÁNG TỪ CUỐN LỊCH LƯU LẠI XUỐNG DB
            obj.ManufacturedDate = ManuDateDatePicker.SelectedDate;

            obj.SupplierId = (string)SupplierIdComboBox.SelectedValue; ;   //khoá ngoại, lấy từ thằng thịt heo đang dự trữ trong combobox

            if (EditedOne == null)
            {  //tạo mới
                _airService.CreateAirCon(obj);
            }
            else
            {
                _airService.UpdateAirCon(obj);
            }

            this.Close();
            //VỀ BÊN MAIN F5 GRID - ĐÃ LÀM ÒI
        }
    }
}
