﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    /// 
    //Mantra:
    //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
    //     !!!

    public partial class LoginWindow : Window
    {

        private AccountService _service = new();
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailAddressTextBox.Text;
            string pass = PasswordTextBox.Text;

            //check var trước, ko tách hàm do nó ngắn
            if(string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(pass)) {
                MessageBox.Show("Both email and password are required!", "Validation", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //có user và pass rồi, Service giúp cái coi
            StaffMember? acc = _service.Authenticate(email);  //CÁCH 1 THEO ĐỀ
            //StaffMember? acc = _service.Authenticate(email, pass);  //CÁCH 2 

            if (acc == null)
            {                  //cách 1: sai gì đó, email or pass
                MessageBox.Show("Email doesn't exist. Please SIGN-UP", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //C1. chạy đến đây là có account rồi
            //đề thi yêu cầu: nếu role = 3 tức là manager cấm vào
            //                    role = 1, 2 tức là admin, staff mời vào
            //AUTHORIZATION
            //C2: CHECK THÊM PASS
            if (acc.Password != pass)
            {
                MessageBox.Show("Invalidated password. Please RESET IT!", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //SỐNG SÓT ĐẾN ĐÂY LÀ XONG AUTHOR (EMAIL, PASS OK), VÀ GIỜI CHECK ROLE - AUTHOR
            if (acc.Role == 3)
            {
                MessageBox.Show("You have no permission to access", "Wrong credentials", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            //ok, mời em vào Main
            MainWindow main = new();

            //giống y chang vụ DetailWindow, truyền user/role sang bên Main để phân quyền nút bấm
            main.LoggedInAccount = acc;
            main.Role = acc.Role;

            main.Show();
            this.Hide();  //ẩn màn hình login vì nó giống hàm main() app chạy từ nó, ko tắt nó khi login thành công để chuyển sang MainWindow
            //tắt màn hình login giống như tắt app, chỉ ẩn hoy


        }
    }
}
