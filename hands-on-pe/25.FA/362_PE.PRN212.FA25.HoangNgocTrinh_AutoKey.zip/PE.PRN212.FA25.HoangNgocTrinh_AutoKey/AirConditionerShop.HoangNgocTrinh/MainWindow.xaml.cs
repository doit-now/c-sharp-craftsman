﻿using AirConditionerShop.BLL.Services;
using AirConditionerShop.DAL.Entities;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AirConditionerShop_HoangNgocTrinh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public int? Role { get; set; }
        public StaffMember LoggedInAccount { get; set; }  //y chang EditedOne

        //                   BLL       DAL     --------DB---------  
        //GUI/CONTROLLER -- SERVICE -- REPO -- DBCONTEXT -- TABLE
        //     !!!

        private AirConService _service = new();  //new luôn ko sợ
        //Dependency Injection!!!!!!!!!!!!!!!!

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //AirConDataGrid.ItemsSource = _service.GetAllAirCons();

            FillDataGrid(_service.GetAllAirCons());

            //if (Role == 2)  //staff đó em, cấm 
            if (LoggedInAccount.Role == 2)
            {
                CreateButton.IsEnabled = false;
                UpdateButton.IsEnabled = false;
                DeleteButton.IsEnabled = false;
            }
         
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            AirConditioner? selected = AirConDataGrid.SelectedItem as AirConditioner;

            if (selected == null)
            {
                MessageBox.Show("Please select a row before deleting", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            MessageBoxResult answer = MessageBox.Show("Are you sure?", "Confirmm", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer == MessageBoxResult.No)
            {
                return;
            }
            //gửi dòng này cho Service xoá giúp
            //MessageBox.Show($"Tớ xoá dòng này nè: {selected.AirConditionerId} {selected.AirConditionerName} {selected.FeatureFunction}");

            //???? xoá dòng thật NHỜ QUA SERVICE, 
            _service.DeleteAirCon(selected);

            //f5 cái grid, đổ lại data của cái grid sau khi mất dòng, đọc lại table
            //AirConDataGrid.ItemsSource = _service.GetAllAirCons();
            FillDataGrid(_service.GetAllAirCons());
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            //1. KIỂM TRA ĐÃ CHỌN 1 DÒNG CHƯA (khai báo biến AirCon selected hứng dòng đã chọn)
            AirConditioner? selected = AirConDataGrid.SelectedItem as AirConditioner;

            if (selected == null)
            {
                MessageBox.Show("Please select a row before updating", "Select one", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            //2. NẾU CÓ CHỌN THÌ GỬI DÒNG ĐÃ CHỌN SANG MÀN HÌNH DETAIL
            DetailWindow detail = new();

            //gửi rồi mới show màn hình
            //detail.SetXXX(seleted); 
            detail.EditedOne = selected;
            detail.ShowDialog();

            //3. Ở MÀN HÌNH DETAIL CẦN LÀM GÌ?
            //TRONG LOADED EVENT TIA CHỚP, CHECK XEM MODE NÀO?
            //EDIT THÌ FILL DATA TỪ EDITED ONE MỚI GỬI VÀO CÁC Ô NHẬP
            //NGƯỢC LẠI BỎ TRỐNG MÀN HÌNH CHỜ GÕ VÀO TẠO MỚI

            //4. BÊN DETAIL XỬ LÍ NÚT [SAVE] -> INSERT HAY UPDATE TUỲ, XUỐNG TABLE

            //5. ĐÓNG MÀN HÌNH DETAIL NHẤN [SAVE]

            //6. F5 CÁI GRID
            //CÁI GRID DC F5 NHIỀU LẦN Ở NHIỀU NƠI: CREATE, UPDATE, DELETE, SEARCH 
            //                                      LOAD MAIN 
            //TA NÊN TÁCH 1 HÀM F5_GRID ĐỂ CODE NÓ RÕ RÀNG NGỮ NGHĨA - VÌ NÓ LÀ 1 TASK
            //TÁCH HÀM PHỤC VỤ CHO CÁC HÀM KHÁC -> HÀM HELPER, THƯỜNG LÀ PRIVATE
            FillDataGrid(_service.GetAllAirCons());
        }

        public void FillDataGrid(List<AirConditioner> data)
        {
            AirConDataGrid.ItemsSource = null; //xoá data đang có
            AirConDataGrid.ItemsSource = data; //fill trở lại với data mới
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            //1. khai báo màn hình detail
            //2. show nó lên
            //3. chờ nó đóng (hy vọng user nhập tạo mới 1 sản phẩm)
            //4. f5 lại cái grid để thấy phần tạo mới đc tải lên lưới


            //gửi rồi mới show màn hình
            //detail.SetXXX(seleted); 
            //  detail.EditedOne = selected;
            //EDIT THÌ PHẢI GỬI
            //TẠO MỚI KO GỬI SANG DETAIL GÌ CẢ!!!!!!!!!!
            DetailWindow detail = new();
            detail.ShowDialog();  //PHẢI ĐÓNG THÌ MỚI F5 ĐC
            FillDataGrid(_service.GetAllAirCons());
        }
    }

    
 }